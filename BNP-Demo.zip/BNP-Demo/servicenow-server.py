from flask import Flask, request, jsonify
from peewee import Model, PostgresqlDatabase, AutoField, CharField, TextField, ForeignKeyField, DateTimeField
from datetime import datetime, timezone
import os


# PostgreSQL database using Peewee
db = PostgresqlDatabase(
    os.getenv("POSTGRES_DB", "mydatabase"),
    user=os.getenv("POSTGRES_USER", "myuser"),
    password=os.getenv("POSTGRES_PASSWORD", "mypass"),
    host=os.getenv("POSTGRES_HOST", "localhost"),
    port=int(os.getenv("POSTGRES_PORT", "5433")),
)


class BaseModel(Model):
    created_at = DateTimeField(default=lambda: datetime.now(timezone.utc))  # Placeholder timestamp
    updated_at = DateTimeField(default=lambda: datetime.now(timezone.utc))  # Placeholder timestamp
    
    class Meta:
        database = db



class Incident(BaseModel):
    id = AutoField()
    short_description = CharField()
    status = CharField(default="NEW")
    description = TextField(null=True)


class Comments(BaseModel):
    id = AutoField()
    comment = TextField()
    incident = ForeignKeyField(Incident, backref='comments')
    
class Test(BaseModel):
    id = AutoField()
    fund = CharField()
    value = CharField(default="Test Value")
    
class Test_Second(BaseModel):
    id = AutoField()
    fund = CharField()
    value = CharField(default="Test Value")
    

db.connect(reuse_if_open=True)
db.drop_tables([Incident, Comments, Test, Test_Second], safe=True)
db.create_tables([Incident, Comments, Test, Test_Second], safe=True)


app = Flask(__name__)

# ============================
#       API Endpoints
# ============================


def _to_utc_iso(value):
    """Return a UTC ISO-8601 string (with Z) or the original value.

    Handles both datetime objects and strings. Strings that cannot be
    parsed are returned unchanged so they don't crash the API.
    """
    if value is None:
        return None

    if isinstance(value, str):
        # Best-effort parse for strings that already look like ISO-8601
        try:
            value = datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return value

    if isinstance(value, datetime):
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        else:
            value = value.astimezone(timezone.utc)
        return value.isoformat().replace("+00:00", "Z")

    # Fallback for unexpected types
    return value

# ============================
#       Incidents
# ============================

@app.route("/incidents", methods=["GET"])
def list_incidents():
    updated_gte = request.args.get("updated_gte")
    created_gte = request.args.get("created_gte")
    
    query = Incident.select()
    
    if created_gte:
        # Allow both plain ISO-8601 and values ending with 'Z'
        created_gte_dt = datetime.fromisoformat(created_gte.replace("Z", "+00:00"))
        created_gte_dt = created_gte_dt.astimezone(timezone.utc)
        query = query.where(Incident.created_at >= created_gte_dt)
    elif updated_gte:
        updated_gte_dt = datetime.fromisoformat(updated_gte.replace("Z", "+00:00"))
        updated_gte_dt = updated_gte_dt.astimezone(timezone.utc)
        query = query.where(Incident.updated_at >= updated_gte_dt)
    
    incidents = [
        {
            "id": inc.id,
            "short_description": inc.short_description,
            "description": inc.description,
            "status": inc.status,
            "comments": [comment.comment for comment in inc.comments],
            "created_at": _to_utc_iso(inc.created_at),
            "updated_at": _to_utc_iso(inc.updated_at),
        }
        for inc in query
    ]
    return jsonify(incidents), 200

@app.route("/incidents", methods=["POST"])
def create_incident():
	data = request.get_json(silent=True) or {}

	short_description = data.get("short_description")
	description = data.get("description")

	if not short_description:
		return (
			jsonify({"error": "'short_description' is required"}),
			400,
		)

	try:
		incident = Incident.create(
			short_description=short_description,
			description=description,
		)
	except Exception as exc:  # keep simple
		return jsonify({"error": str(exc)}), 400

	return (
		jsonify(
			{
				"id": incident.id,
				"short_description": incident.short_description,
				"description": incident.description,
			}
		),
		201,
	)

@app.route("/incident/<int:incident_id>", methods=["PUT"])
def update_incident(incident_id):
    data = request.get_json(silent=True) or {}
    short_description = data.get("short_description")
    description = data.get("description")
    status = data.get("status")

    try:
        incident = Incident.get_by_id(incident_id)
        if short_description:
            incident.short_description = short_description
        if description:
            incident.description = description
        if status:
            incident.status = status
        incident.updated_at = datetime.now(timezone.utc)  # Update timestamp
        incident.save()
        return jsonify({
            "id": incident.id,
            "short_description": incident.short_description,
            "description": incident.description,
            "status": incident.status
        }), 200
    except Incident.DoesNotExist:
        return jsonify({"error": f"Incident with ID {incident_id} does not exist."}), 404
    except Exception as exc:
        return jsonify({"error": str(exc)}), 400

@app.route("/incident", methods=["DELETE"])
def delete_incident():
    incident_id = request.args.get("id")
    if not incident_id:
        return jsonify({"error": "Incident ID is required"}), 400

    try:
        incident = Incident.get_by_id(incident_id)
        incident.delete_instance()
        return jsonify({"message": f"Deleted incident with ID {incident_id}."}), 200
    except Incident.DoesNotExist:
        return jsonify({"error": f"Incident with ID {incident_id} does not exist."}), 404
    except Exception as exc:
        return jsonify({"error": str(exc)}), 400

@app.route("/incidents", methods=["DELETE"])
def delete_incidents():
    try:
        deleted_count = Incident.delete().execute()
        return jsonify({"message": f"Deleted {deleted_count} incidents."}), 200
    except Exception as exc:
        return jsonify({"error": str(exc)}), 400

# ============================
#       Tests
# ============================

@app.route("/tests", methods=["GET"])
def list_tests():
    updated_gte = request.args.get("updated_gte")
    created_gte = request.args.get("created_gte")
    
    query = Test.select()
    
    if created_gte:
        # Allow both plain ISO-8601 and values ending with 'Z'
        created_gte_dt = datetime.fromisoformat(created_gte.replace("Z", "+00:00"))
        created_gte_dt = created_gte_dt.astimezone(timezone.utc)
        query = query.where(Incident.created_at >= created_gte_dt)
    elif updated_gte:
        updated_gte_dt = datetime.fromisoformat(updated_gte.replace("Z", "+00:00"))
        updated_gte_dt = updated_gte_dt.astimezone(timezone.utc)
        query = query.where(Incident.updated_at >= updated_gte_dt)
    
    incidents = [
        {
            "id": inc.id,
            "fund": inc.fund,
            "value": inc.value,
            "created_at": _to_utc_iso(inc.created_at),
            "updated_at": _to_utc_iso(inc.updated_at),
        }
        for inc in query
    ]
    return jsonify(incidents), 200

@app.route("/tests_second", methods=["GET"])
def list_tests_second():
    updated_gte = request.args.get("updated_gte")
    created_gte = request.args.get("created_gte")
    
    query = Test_Second.select()
    
    if created_gte:
        # Allow both plain ISO-8601 and values ending with 'Z'
        created_gte_dt = datetime.fromisoformat(created_gte.replace("Z", "+00:00"))
        created_gte_dt = created_gte_dt.astimezone(timezone.utc)
        query = query.where(Incident.created_at >= created_gte_dt)
    elif updated_gte:
        updated_gte_dt = datetime.fromisoformat(updated_gte.replace("Z", "+00:00"))
        updated_gte_dt = updated_gte_dt.astimezone(timezone.utc)
        query = query.where(Incident.updated_at >= updated_gte_dt)
    
    incidents = [
        {
            "id": inc.id,
            "fund": inc.fund,
            "value": inc.value,
            "created_at": _to_utc_iso(inc.created_at),
            "updated_at": _to_utc_iso(inc.updated_at),
        }
        for inc in query
    ]
    return jsonify(incidents), 200



# ============================
#       Others
# ============================

@app.route("/create-new-delete-request", methods=["POST"])
def create_new_delete_request():
    """Create a new incident via the Flask API and print the response."""
    SHORT_DESCRIPTION = "New Delete Request"
    DESCRIPTION = """
    Fund: XXXXX, YYYYY
    Table: Test, Test_Second
    Dates: 2026-01-01 to 2026-12-31
    """

    incident = Incident.create(
        type="Delete Request",
        application="B-One",
        short_description=SHORT_DESCRIPTION,
        description=DESCRIPTION
    )
    
    test_record = Test.create(
        fund="XXXXX",
        value="Test Value"
    )

    test_record = Test.create(
        fund="YYYYY",
        value="Test Value"
    )
    
    test_second_record = Test_Second.create(
        fund="XXXXX",
        value="Test Value"
    )
    
    test_second_record = Test_Second.create(
        fund="YYYYY",
        value="Test Value"
    )
    
    return jsonify({
        "id": incident.id,
        "short_description": incident.short_description,
        "description": incident.description,
    }), 201

if __name__ == "__main__":
	app.run(host="0.0.0.0", port=5000, debug=True)

