###
# General imports
##

## Default
import os
import asyncio
import json

## URL Parsing
from urllib.parse import parse_qs

## Channels
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from asgiref.sync import async_to_sync
from channels.generic.websocket import JsonWebsocketConsumer
### App-specific imports

## Models
from django.conf import settings

import os
import json
import asyncio
from channels.generic.websocket import AsyncJsonWebsocketConsumer
from asgiref.sync import async_to_sync

import logging

logger = logging.getLogger('django.channels.server')


class BaseLogConsumer(AsyncJsonWebsocketConsumer):
    """
    Base WebSocket consumer for streaming log data with standardized methods.
    
    Attributes:
        log_file_path (str): Path to the log file.
        log_file (file): File object for the log file.
    """
    
    async def send_log_line(self, line):
        """
        Standardized method to send a log line to the client.
        
        Args:
            line (str): The log line to send.
        """
        await self.send_json({
            "type": "log_line",
            "line": line.rstrip('\n\r')  # Remove trailing newlines for consistency
        })
    
    async def send_remaining_logs(self):
        """
        Sends all remaining log content from the current file position to the client.
        This method reads and sends all available lines without waiting.
        """
        if not hasattr(self, 'log_file') or not self.log_file or self.log_file.closed:
            return
            
        try:
            # Read all remaining lines
            remaining_lines = self.log_file.readlines()
            for line in remaining_lines:
                if line.strip():  # Only send non-empty lines
                    await self.send_log_line(line)
        except Exception as e:
            logger.warning(f"Error sending remaining logs: {e}")
    
    async def read_log_line(self):
        """
        Standardized method to read a single line from the log file.
        
        Returns:
            str: The log line if available, None otherwise.
        """
        if not hasattr(self, 'log_file') or not self.log_file or self.log_file.closed:
            return None
            
        try:
            return self.log_file.readline()
        except Exception as e:
            logger.warning(f"Error reading log line: {e}")
            return None
    
    def close_log_file(self):
        """
        Safely closes the log file if it's open.
        """
        if hasattr(self, 'log_file') and self.log_file and not self.log_file.closed:
            try:
                self.log_file.close()
            except Exception as e:
                logger.warning(f"Error closing log file: {e}")


class TaskLogConsumer(BaseLogConsumer):
    """
    WebSocket consumer for streaming log data from a task to a connected client.

    Attributes:
        task_group_name (str): Group name for the WebSocket channel associated with a task.
        task (Task): The task instance being monitored.
    """

    async def get_task(self, task_id):
        """
        Fetches the Task instance with the specified task ID from the database.

        Args:
            task_id (int): The ID of the task to retrieve.

        Returns:
            Task: The Task instance if found, or None if not found.
        """
        
        from apps.task_app.models import Task
        
        try:
            task = await Task.objects.aget(id=task_id)
            return task
        except Task.DoesNotExist:
            return None

    async def celery_task_update(self, event):
        """
        Sends a task update message to the WebSocket client.
        """
        await self.send_json({"type": "task_update",
                             "data": event})

    async def send_task_status(self):
        """
        Sends current task status, steps, and progress to the client.
        """
        if hasattr(self, 'task') and self.task:
            await self.send_json({
                "type": "task_status",
                "status": self.task.status,
            })
            
    async def send_task_progress(self):
        """
        Sends current task status, steps, and progress to the client.
        """
        self.task = await self.get_task(self.task.id)
        if hasattr(self, 'task') and self.task:
            await self.send_json({
                "type": "task_progress",
                "progress": getattr(self.task, 'progress', 59),
            })


    async def connect(self):
        """
        Handles the WebSocket connection by associating the client with a task's log stream.
        """
        task_id = self.scope['url_route']['kwargs']['task_id']
        
        self.task = await self.get_task(task_id)
        if self.task is None:
            await self.close()
            return

        self.task_group_name = f"task_{self.task.id}"
        self.log_file_path = self.task.log_path
        
        await self.channel_layer.group_add(self.task_group_name, self.channel_name)
        await self.accept()
        
        self.task.audit_logs
        if self.log_file_path and os.path.isfile(self.log_file_path):
            if self.task.status in ['WAITING', 'RUNNING']:
                self.log_file = open(self.log_file_path, 'r')
                self.log_file.seek(0, os.SEEK_END)
                asyncio.create_task(self.stream_log_data())
        else:
            logger.warning(f"Log file not found: {self.log_file_path}")

    async def stream_log_data(self):
        """
        Periodically checks for new lines in the log file and sends them to the client.
        Also periodically updates task status and detects completion.
        """
        from apps.task_app.models import Task
        status_update_counter = 0
        try:
            while True:
                if self.log_file.closed:
                    break
                
                line = await self.read_log_line()
                if line:
                    await self.send_log_line(line)
                else:
                    await asyncio.sleep(1)
                    status_update_counter += 2
                    
                # Send status update every 10 iterations (roughly every 10 seconds)
                status_update_counter += 1
                if status_update_counter >= 10:
                    self.task = await self.get_task(self.task.id)
                    
                    await self.send_task_progress()

                    # Check if task is finished (success or failure)
                    if self.task.status not in [Task.Status.WAITING, Task.Status.RUNNING]:
                        await self.send_remaining_logs()
                        await self.send_task_status()
                        break
                            
                    status_update_counter = 0
                    
        except Exception as e:
            logger.warning(f"Error in stream_log_data: {e}")
            await self.close()

    async def disconnect(self, close_code):
        """
        Handles the WebSocket disconnection by closing the log file if open.
        """
        self.close_log_file()

        if hasattr(self, 'task_group_name'):
            await self.channel_layer.group_discard(self.task_group_name, self.channel_name)


class JobLogConsumer(BaseLogConsumer):
    """
    WebSocket consumer for streaming log data from a job to a connected client.

    Attributes:
        job (Job): The job instance being monitored.
    """

    async def get_job(self, job_id):
        """
        Fetches the Job instance with the specified job ID from the database.

        Args:
            job_id (int): The ID of the job to retrieve.

        Returns:
            Job: The Job instance if found, or None if not found.
        """
        from apps.task_app.models import Job
        try:
            job = await Job.objects.aget(id=job_id)
            return job
        except Job.DoesNotExist:
            return None

    async def connect(self):
        """
        Handles the WebSocket connection by associating the client with a job's log stream.
        """
        job_id = self.scope['url_route']['kwargs']['job_id']
        self.job = await self.get_job(job_id)
        if self.job is None:
            await self.close()
            return

        self.log_file_path = self.job.log_path
        
        if self.log_file_path and os.path.isfile(self.log_file_path):
            await self.accept()
            self.log_file = open(self.log_file_path, 'r')
            self.log_file.seek(0, os.SEEK_END)
            asyncio.create_task(self.stream_log_data())
        else:
            await self.close()

    async def stream_log_data(self):
        """
        Periodically checks for new lines in the log file and sends them to the client.
        """
        try:
            while True:
                if self.log_file.closed:
                    break
                
                line = await self.read_log_line()
                if line:
                    await self.send_log_line(line)
                else:
                    await asyncio.sleep(1)
        except Exception as e:
            logger.error(f"Error in stream_log_data: {e}")
            await self.close()

    async def disconnect(self, close_code):
        """
        Handles the WebSocket disconnection by closing the log file if open.
        """
        self.close_log_file()
