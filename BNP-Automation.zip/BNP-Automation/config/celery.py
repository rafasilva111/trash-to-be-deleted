from __future__ import absolute_import, unicode_literals
import os
import logging
from celery import Celery
from celery.signals import setup_logging

# Set the default Django settings module for the 'celery' program.
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')

app = Celery('config', broker_connection_retry_on_startup = True)

# Using a string here means the worker will not have to
# pickle the object when using Windows.
app.config_from_object('django.conf:settings', namespace='CELERY')

# Load task modules from all registered Django app configs.
app.autodiscover_tasks()

@setup_logging.connect
def config_loggers(*args, **kwargs):
    """
    Configure logging for Celery workers to use Django's logging configuration.
    """
    from django.conf import settings
    from logging.config import dictConfig
    
    if hasattr(settings, 'LOGGING'):
        dictConfig(settings.LOGGING)
        
        # Get the celery logger and set it to DEBUG
        celery_logger = logging.getLogger('celery')
        celery_logger.setLevel(logging.DEBUG)
        
        # Also set specific task app logger to DEBUG
        task_logger = logging.getLogger('apps.task_app')
        task_logger.setLevel(logging.DEBUG)
        
        print(f"[CELERY] Logging configured - Celery level: {celery_logger.level}, Task level: {task_logger.level}")

@app.task(bind=True)
def debug_task(self):
    print(f'Request: {self.request!r}')