from django.db import models

# Create your models here.
class BaseModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        abstract = True
        
# This class must be placed here because its used in user_app.models and task_app.models

class ProcessType(models.TextChoices):

    DEFAULT = 'DEFAULT', 'Default'