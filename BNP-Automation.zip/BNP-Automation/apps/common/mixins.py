"""Enhanced error handling and validation mixins for Django models.

This module provides reusable mixins and utilities to improve error handling,
validation, and logging across all Django models in the application.
"""

import logging
from typing import Any, Dict, List, Optional
from django.core.exceptions import ValidationError
from django.db import models, transaction
from django.utils import timezone

logger = logging.getLogger(__name__)


class LoggingMixin:
    """Mixin to add logging capabilities to Django models."""
    
    def log_operation(self, operation: str, details: str = "", level: str = "info"):
        """
        Log model operations with consistent formatting.
        
        Args:
            operation: The operation being performed (create, update, delete, etc.)
            details: Additional details about the operation
            level: Logging level (debug, info, warning, error)
        """
        model_name = self.__class__.__name__
        pk = getattr(self, 'pk', 'new')
        message = f"{model_name}(pk={pk}) {operation}"
        
        if details:
            message += f": {details}"
            
        getattr(logger, level.lower())(message)
    
    def save(self, *args, **kwargs):
        """Enhanced save with logging."""
        is_creation = self.pk is None
        operation = "created" if is_creation else "updated"
        
        try:
            result = super().save(*args, **kwargs)
            self.log_operation(operation, "Successfully saved")
            return result
        except Exception as e:
            self.log_operation(f"{operation} failed", str(e), "error")
            raise
    
    def delete(self, *args, **kwargs):
        """Enhanced delete with logging."""
        try:
            result = super().delete(*args, **kwargs)
            self.log_operation("deleted", "Successfully deleted")
            return result
        except Exception as e:
            self.log_operation("delete failed", str(e), "error")
            raise


class ValidationMixin:
    """Mixin to add enhanced validation capabilities."""
    
    def clean_fields(self, exclude: List[str] = None):
        """Enhanced field cleaning with better error reporting."""
        try:
            super().clean_fields(exclude)
        except ValidationError as e:
            logger.warning(f"Field validation errors in {self.__class__.__name__}: {e.message_dict}")
            raise
    
    def full_clean(self, exclude: List[str] = None, validate_unique: bool = True):
        """Enhanced full clean with logging."""
        try:
            super().full_clean(exclude, validate_unique)
            logger.debug(f"{self.__class__.__name__} validation passed")
        except ValidationError as e:
            error_details = getattr(e, 'message_dict', str(e))
            logger.error(f"{self.__class__.__name__} validation failed: {error_details}")
            raise


class AuditMixin(models.Model):
    """Mixin to add audit trail capabilities."""
    
    created_at = models.DateTimeField(auto_now_add=True, help_text="When this record was created")
    updated_at = models.DateTimeField(auto_now=True, help_text="When this record was last modified")
    created_by = models.ForeignKey(
        'user_app.User', 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True,
        related_name='%(class)s_created',
        help_text="User who created this record"
    )
    updated_by = models.ForeignKey(
        'user_app.User', 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True,
        related_name='%(class)s_updated',
        help_text="User who last modified this record"
    )
    
    class Meta:
        abstract = True
        
    def save(self, *args, **kwargs):
        """Enhanced save with audit trail."""
        user = kwargs.pop('user', None)
        
        if user:
            if self.pk is None:  # Creating
                self.created_by = user
            self.updated_by = user
            
        super().save(*args, **kwargs)


class SafeDeleteMixin:
    """Mixin to provide safe deletion with confirmation."""
    
    def safe_delete(self, confirmation_token: str = None, user: Any = None) -> bool:
        """
        Safely delete object with confirmation and logging.
        
        Args:
            confirmation_token: Token to confirm deletion intent
            user: User performing the deletion
            
        Returns:
            bool: True if deleted successfully
        """
        expected_token = f"DELETE_{self.__class__.__name__}_{self.pk}"
        
        if confirmation_token != expected_token:
            logger.warning(f"Unsafe deletion attempt on {self.__class__.__name__}(pk={self.pk})")
            return False
            
        try:
            with transaction.atomic():
                if user:
                    logger.info(f"User {user} deleting {self.__class__.__name__}(pk={self.pk})")
                else:
                    logger.info(f"System deleting {self.__class__.__name__}(pk={self.pk})")
                    
                self.delete()
                return True
        except Exception as e:
            logger.error(f"Failed to delete {self.__class__.__name__}(pk={self.pk}): {e}")
            return False


class StatusMixin(models.Model):
    """Mixin for models that need status tracking."""
    
    class StatusChoices(models.TextChoices):
        ACTIVE = 'active', 'Active'
        INACTIVE = 'inactive', 'Inactive'
        PENDING = 'pending', 'Pending'
        ARCHIVED = 'archived', 'Archived'
    
    status = models.CharField(
        max_length=20,
        choices=StatusChoices.choices,
        default=StatusChoices.ACTIVE,
        help_text="Current status of this record"
    )
    status_changed_at = models.DateTimeField(auto_now_add=True, help_text="When status was last changed")
    
    class Meta:
        abstract = True
        
    def change_status(self, new_status: str, user: Any = None, reason: str = ""):
        """
        Change status with logging and validation.
        
        Args:
            new_status: New status value
            user: User making the change
            reason: Reason for status change
        """
        if new_status not in [choice[0] for choice in self.StatusChoices.choices]:
            raise ValidationError(f"Invalid status: {new_status}")
            
        old_status = self.status
        self.status = new_status
        self.status_changed_at = timezone.now()
        
        details = f"Status changed from {old_status} to {new_status}"
        if reason:
            details += f" (Reason: {reason})"
        if user:
            details += f" by {user}"
            
        logger.info(f"{self.__class__.__name__}(pk={self.pk}) {details}")
        self.save()


class CacheInvalidationMixin:
    """Mixin to handle cache invalidation on model changes."""
    
    def get_cache_keys(self) -> List[str]:
        """
        Get list of cache keys that should be invalidated.
        Override this method in your models.
        """
        return [
            f"{self.__class__.__name__.lower()}_{self.pk}",
            f"{self.__class__.__name__.lower()}_list",
        ]
    
    def invalidate_cache(self):
        """Invalidate related cache entries."""
        from django.core.cache import cache
        
        cache_keys = self.get_cache_keys()
        if cache_keys:
            cache.delete_many(cache_keys)
            logger.debug(f"Invalidated {len(cache_keys)} cache keys for {self.__class__.__name__}(pk={self.pk})")
    
    def save(self, *args, **kwargs):
        """Enhanced save with cache invalidation."""
        result = super().save(*args, **kwargs)
        self.invalidate_cache()
        return result
        
    def delete(self, *args, **kwargs):
        """Enhanced delete with cache invalidation."""
        self.invalidate_cache()
        return super().delete(*args, **kwargs)


def enhance_model_with_mixins(base_class: type) -> type:
    """
    Factory function to enhance existing models with utility mixins.
    
    Args:
        base_class: The base model class to enhance
        
    Returns:
        Enhanced model class with mixins
    """
    class EnhancedModel(LoggingMixin, ValidationMixin, base_class):
        class Meta:
            proxy = True
            
    return EnhancedModel