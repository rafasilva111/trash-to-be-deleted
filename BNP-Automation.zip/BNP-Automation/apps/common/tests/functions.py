###
#       General imports
##


##
#   Default
#

from django.test import TestCase
from django.contrib.auth.models import Group, Permission
from datetime import datetime

##
#   Extras
#

import inspect


###
#       App specific imports
##


##
#   Models
#

from apps.common.models import ProcessType
from apps.user_app.models import User
from apps.task_app.models import Job, Task, Condition

##
#   Serializers
#


##
#   Forms
#


##
#   Functions
#


##
#   Contants
#

from apps.common.tests.constants import *
from apps.user_app.constants import GROUPS_PERMISSIONS
import random
import string

###
#
#       Functions
#
##

def perm_string(permission):
    """
    Given a Permission object, return the proper 'app_label.codename' string
    """
    return f"{permission.content_type.app_label}.{permission.codename}"

def random_string(length=10):
    characters = string.ascii_letters + string.digits  # A-Z, a-z, 0-9
    return ''.join(random.choice(characters) for _ in range(length))


def print_prologue():

    print("----------------------------------------------------------------------")
    print("\n")
    print(f"Running test: {inspect.currentframe().f_back.f_code.co_name}")
    print("\n")

##
#   User App
#


def create_test_users(test_case: TestCase):
    
    # Create predefined users
    for name, is_staff, is_superuser, password, user_type in [
        (TESTING_ACCOUNT_PLACEHOLDER, False, False,
         TESTING_ACCOUNT_PLACEHOLDER_PASSWORD, User.UserType.PLACEHOLDER),
        (TESTING_ACCOUNT_NORMAL, False, False,
         TESTING_ACCOUNT_NORMAL_PASSWORD, User.UserType.NORMAL),
        (TESTING_ACCOUNT_APP_STAFF, True, False,
         TESTING_ACCOUNT_APP_STAFF_PASSWORD, User.UserType.APP_STAFF),
        (TESTING_ACCOUNT_APP_ADMIN, True, True,
         TESTING_ACCOUNT_APP_ADMIN_PASSWORD, User.UserType.APP_ADMIN),
    ]:
        user, created = User.objects.get_or_create(
            name=name,
            email=f"{name}@{name}.pt",
            is_staff=is_staff,
            is_superuser=is_superuser,
            type=user_type
        )

        if created:
            user.set_password(password)
            user.save()

    # Create groups and assign permissions
    for group_name, perm_codes in GROUPS_PERMISSIONS.items():
        group, created = Group.objects.get_or_create(name=group_name)

        # Assign permissions to the group
        permissions = Permission.objects.filter(codename__in=perm_codes)
        group.permissions.set(permissions)
        group.save()

    # Assign users to groups
    for user in User.objects.all():
        try:
            group = Group.objects.get(name=user.type)
            user.groups.add(group)

        except Group.DoesNotExist:
            print(f"Group '{user.type}' does not exist")

    # Create clients for each user type
    test_case.placeholder_user = User.objects.get(
        email=f"{TESTING_ACCOUNT_PLACEHOLDER}@{TESTING_ACCOUNT_PLACEHOLDER}.pt")
    test_case.normal_user = User.objects.get(
        email=f"{TESTING_ACCOUNT_NORMAL}@{TESTING_ACCOUNT_NORMAL}.pt")
    test_case.app_staff_user = User.objects.get(
        email=f"{TESTING_ACCOUNT_APP_STAFF}@{TESTING_ACCOUNT_APP_STAFF}.pt")
    test_case.app_admin_user = User.objects.get(
        email=f"{TESTING_ACCOUNT_APP_ADMIN}@{TESTING_ACCOUNT_APP_ADMIN}.pt")

    return test_case


##
#   ETL App
#

from django.db import transaction
def create_test_task(process: ProcessType, user: User, starting_condition: Condition = None, stopping_condition: Condition = None, parent_job: Job = None, type: Job.TaskType = Job.TaskType.EMPTY):
    with transaction.atomic():
        if not parent_job:
            parent_job = Job.objects.create(
                type=type,
                process=process,
                name=f'Test Extract Job {datetime.now().timestamp()}',
                created_by=user,
                parent_job=parent_job,
                starting_condition=starting_condition,
                stopping_condition=stopping_condition
            )

        test_task = Task.objects.create(
            type=type,
            process=process,
            owner_job=parent_job,
            debug_mode=True
        )

    return parent_job, test_task


def create_test_invitations(inviter: User, invited: User, group: Group):
    from apps.user_app.models import Invitation
    invitation = Invitation.objects.create(
        inviter=inviter,
        invited=invited,
        group=group
    )
    return invitation