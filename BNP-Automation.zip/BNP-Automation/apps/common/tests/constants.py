##
#   Constant User for testing
#

TESTING_ACCOUNT_PLACEHOLDER = "TestingAccountPlaceholder"
TESTING_ACCOUNT_PLACEHOLDER_PASSWORD = "PlaceholderPassword123!"

TESTING_ACCOUNT_NORMAL = "TestingAccountNormal"
TESTING_ACCOUNT_NORMAL_PASSWORD = "NormalPassword123!"

TESTING_ACCOUNT_APP_STAFF = "TestingAccountAppStaff"
TESTING_ACCOUNT_APP_STAFF_PASSWORD = "AppStaffPassword123!"

TESTING_ACCOUNT_APP_ADMIN = "TestingAccountAppAdmin"
TESTING_ACCOUNT_APP_ADMIN_PASSWORD = "AppAdminPassword123!"


##
#   
#
    
###
#
#       Button IDs for testing
#
##

##
#   Default
#

DROPDOWN_DETAILS_BUTTON_ID = "dropdown-details-button"
DROPDOWN_DELETE_BUTTON_ID = "dropdown-delete-button"
DROPDOWN_EDIT_BUTTON_ID = "dropdown-edit-button"

CREATE_BUTTON_ID = "create-button"
DETAILS_BUTTON_ID = "details-button"
EDIT_BUTTON_ID = "edit-button"
DELETE_BUTTON_ID = "delete-button"
ENABLE_BUTTON_ID = "enable-button"
DISABLE_BUTTON_ID = "disable-button"
RESEND_BUTTON_ID = "resend-button"

##
#   Recipes
#

DROPWON_REVIEW_RECIPE_BUTTON_ID = "dropdown-review-recipe-button"
DROPWON_UNREVIEW_RECIPE_BUTTON_ID = "dropdown-unreview-recipe-button"

##
#   Audit Logs
#

ACCEPT_AUDIT_LOG_BUTTON_ID = "accept-audit-log-button"
UNACCEPT_AUDIT_LOG_BUTTON_ID = "unaccept-audit-log-button"
REVIEW_AUDIT_LOG_BUTTON_ID = "review-audit-log-button"
UNREVIEW_AUDIT_LOG_BUTTON_ID = "unreview-audit-log-button"
DELETE_AUDIT_LOG_BUTTON_ID = "delete-audit-log-button"

DROPWON_ACCEPT_AUDIT_LOG_BUTTON_ID = "dropdown-accept-audit-log-button"
DROPWON_UNACCEPT_AUDIT_LOG_BUTTON_ID = "dropdown-unaccept-audit-log-button"
DROPWON_REVIEW_AUDIT_LOG_BUTTON_ID = "dropdown-review-audit-log-button"
DROPWON_UNREVIEW_AUDIT_LOG_BUTTON_ID = "dropdown-unreview-audit-log-button"
