"""Enhanced performance monitoring and profiling utilities.

This module provides comprehensive performance monitoring, profiling, and
optimization utilities for Django applications with detailed metrics and logging.
"""

import time
import logging
import functools
import threading
import psutil
import gc
from typing import Dict, Any, Optional, List, Callable, Union
from collections import defaultdict, deque
from datetime import datetime, timedelta
from contextlib import contextmanager
from django.conf import settings
from django.core.cache import cache
from django.db import connection
from django.utils import timezone

logger = logging.getLogger(__name__)


class PerformanceMonitor:
    """Advanced performance monitoring with metrics collection and analysis."""
    
    def __init__(self, operation_name: str):
        self.operation_name = operation_name
        self.start_time = None
        self.end_time = None
        self.metrics = {}
        self.memory_before = None
        self.memory_after = None
        self.db_queries_before = None
        self.db_queries_after = None
    
    def __enter__(self):
        """Start monitoring when entering context."""
        self.start_monitoring()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Stop monitoring when exiting context."""
        self.stop_monitoring()
        self._log_results(exc_type is not None)
    
    def start_monitoring(self):
        """Start performance monitoring."""
        self.start_time = time.time()
        self.memory_before = self._get_memory_usage()
        self.db_queries_before = len(connection.queries) if settings.DEBUG else 0
        
        # Clear any pending garbage collection
        gc.collect()
        
        logger.debug(f\"Starting performance monitoring for: {self.operation_name}\")
    
    def stop_monitoring(self):
        \"\"\"Stop performance monitoring and collect final metrics.\"\"\"
        self.end_time = time.time()
        self.memory_after = self._get_memory_usage()
        self.db_queries_after = len(connection.queries) if settings.DEBUG else 0
        
        # Calculate metrics
        self.metrics = {
            'duration': self.end_time - self.start_time,
            'memory_delta': self.memory_after - self.memory_before,
            'memory_peak': self.memory_after,
            'db_queries': self.db_queries_after - self.db_queries_before,
            'timestamp': timezone.now().isoformat(),
            'operation': self.operation_name,
        }
    
    def _get_memory_usage(self) -> float:
        \"\"\"Get current memory usage in MB.\"\"\"
        try:
            process = psutil.Process()
            return process.memory_info().rss / 1024 / 1024  # Convert to MB
        except Exception as e:
            logger.warning(f\"Could not get memory usage: {e}\")
            return 0.0
    
    def _log_results(self, had_exception: bool = False):
        \"\"\"Log monitoring results with appropriate level.\"\"\"
        if not self.metrics:
            return
        
        duration = self.metrics['duration']
        memory_delta = self.metrics['memory_delta']
        db_queries = self.metrics['db_queries']
        
        # Determine log level based on performance
        if had_exception:
            log_level = logging.ERROR
            status = \"FAILED\"
        elif duration > 5.0:  # Slow operation threshold
            log_level = logging.WARNING
            status = \"SLOW\"
        elif duration > 1.0:
            log_level = logging.INFO
            status = \"NORMAL\"
        else:
            log_level = logging.DEBUG
            status = \"FAST\"
        
        message = (
            f\"Performance [{status}] {self.operation_name}: \"\n            f\"{duration:.3f}s, {memory_delta:.1f}MB memory, {db_queries} DB queries\"\n        )\n        \n        logger.log(log_level, message)\n        \n        # Store metrics for analysis if enabled\n        if getattr(settings, 'PERFORMANCE_METRICS_ENABLED', False):\n            self._store_metrics()\n    \n    def _store_metrics(self):\n        \"\"\"Store metrics in cache for analysis.\"\"\"  \n        try:\n            cache_key = f\"perf_metrics_{self.operation_name}\"\n            existing_metrics = cache.get(cache_key, [])\n            \n            # Keep only last 100 entries per operation\n            if len(existing_metrics) >= 100:\n                existing_metrics = existing_metrics[-99:]\n            \n            existing_metrics.append(self.metrics)\n            cache.set(cache_key, existing_metrics, timeout=3600)  # 1 hour\n            \n        except Exception as e:\n            logger.warning(f\"Failed to store performance metrics: {e}\")\n\n\nclass QueryAnalyzer:\n    \"\"\"Analyze database query performance and identify bottlenecks.\"\"\"\n    \n    def __init__(self):\n        self.slow_queries = deque(maxlen=100)\n        self.query_stats = defaultdict(int)\n        self.duplicate_queries = defaultdict(list)\n    \n    def analyze_queries(self) -> Dict[str, Any]:\n        \"\"\"Analyze database queries and return performance insights.\"\"\"  \n        if not settings.DEBUG:\n            logger.warning(\"Query analysis requires DEBUG=True\")\n            return {}\n        \n        queries = connection.queries\n        analysis = {\n            'total_queries': len(queries),\n            'slow_queries': [],\n            'duplicate_queries': [],\n            'total_time': 0,\n            'recommendations': []\n        }\n        \n        for query in queries[-50:]:  # Analyze last 50 queries\n            duration = float(query.get('time', 0))\n            sql = query.get('sql', '')\n            \n            analysis['total_time'] += duration\n            \n            # Identify slow queries (>100ms)\n            if duration > 0.1:\n                analysis['slow_queries'].append({\n                    'sql': sql[:200] + '...' if len(sql) > 200 else sql,\n                    'time': duration,\n                    'recommendation': self._get_query_recommendation(sql)\n                })\n            \n            # Track duplicate queries\n            query_hash = hash(sql)\n            self.duplicate_queries[query_hash].append(duration)\n        \n        # Find duplicate queries\n        for query_hash, times in self.duplicate_queries.items():\n            if len(times) > 1:\n                analysis['duplicate_queries'].append({\n                    'count': len(times),\n                    'total_time': sum(times),\n                    'avg_time': sum(times) / len(times)\n                })\n        \n        # Generate recommendations\n        analysis['recommendations'] = self._generate_recommendations(analysis)\n        \n        return analysis\n    \n    def _get_query_recommendation(self, sql: str) -> str:\n        \"\"\"Generate recommendation for optimizing a specific query.\"\"\"\n        sql_lower = sql.lower()\n        \n        if 'select *' in sql_lower:\n            return \"Avoid SELECT *, specify only needed columns\"\n        elif 'order by' in sql_lower and 'limit' not in sql_lower:\n            return \"Consider adding LIMIT to ORDER BY queries\"\n        elif sql_lower.count('join') > 3:\n            return \"Complex joins detected, consider query optimization\"\n        elif 'where' not in sql_lower and 'select' in sql_lower:\n            return \"Consider adding WHERE clause to filter results\"\n        else:\n            return \"Review query execution plan\"\n    \n    def _generate_recommendations(self, analysis: Dict[str, Any]) -> List[str]:\n        \"\"\"Generate performance recommendations based on analysis.\"\"\"\n        recommendations = []\n        \n        if analysis['total_queries'] > 50:\n            recommendations.append(\"High query count detected, consider query optimization\")\n        \n        if analysis['slow_queries']:\n            recommendations.append(f\"{len(analysis['slow_queries'])} slow queries found, review and optimize\")\n        \n        if analysis['duplicate_queries']:\n            recommendations.append(f\"{len(analysis['duplicate_queries'])} duplicate queries found, consider caching\")\n        \n        if analysis['total_time'] > 1.0:\n            recommendations.append(\"Total query time exceeds 1 second, optimize database operations\")\n        \n        return recommendations\n\n\nclass MemoryProfiler:\n    \"\"\"Monitor and analyze memory usage patterns.\"\"\"\n    \n    def __init__(self):\n        self.snapshots = deque(maxlen=50)\n        self.peak_usage = 0\n    \n    def take_snapshot(self, label: str = \"\") -> Dict[str, Any]:\n        \"\"\"Take a memory usage snapshot.\"\"\"\n        try:\n            process = psutil.Process()\n            memory_info = process.memory_info()\n            \n            snapshot = {\n                'timestamp': timezone.now().isoformat(),\n                'label': label,\n                'rss': memory_info.rss / 1024 / 1024,  # MB\n                'vms': memory_info.vms / 1024 / 1024,  # MB\n                'percent': process.memory_percent(),\n                'available': psutil.virtual_memory().available / 1024 / 1024,  # MB\n            }\n            \n            self.snapshots.append(snapshot)\n            \n            if snapshot['rss'] > self.peak_usage:\n                self.peak_usage = snapshot['rss']\n            \n            logger.debug(f\"Memory snapshot [{label}]: {snapshot['rss']:.1f}MB RSS\")\n            \n            return snapshot\n            \n        except Exception as e:\n            logger.error(f\"Failed to take memory snapshot: {e}\")\n            return {}\n    \n    def get_memory_trend(self) -> Dict[str, Any]:\n        \"\"\"Analyze memory usage trends.\"\"\"\n        if len(self.snapshots) < 2:\n            return {'trend': 'insufficient_data'}\n        \n        recent_snapshots = list(self.snapshots)[-10:]  # Last 10 snapshots\n        first_usage = recent_snapshots[0]['rss']\n        last_usage = recent_snapshots[-1]['rss']\n        \n        trend_data = {\n            'trend': 'stable',\n            'change_mb': last_usage - first_usage,\n            'change_percent': ((last_usage - first_usage) / first_usage) * 100,\n            'peak_usage': self.peak_usage,\n            'current_usage': last_usage,\n            'snapshots_count': len(recent_snapshots),\n        }\n        \n        # Determine trend\n        if abs(trend_data['change_percent']) > 20:\n            trend_data['trend'] = 'increasing' if trend_data['change_mb'] > 0 else 'decreasing'\n        elif abs(trend_data['change_percent']) > 10:\n            trend_data['trend'] = 'rising' if trend_data['change_mb'] > 0 else 'falling'\n        \n        return trend_data\n\n\ndef performance_decorator(operation_name: Optional[str] = None, \n                         include_args: bool = False,\n                         cache_result: bool = False,\n                         cache_timeout: int = 300):\n    \"\"\"Decorator for monitoring function performance with enhanced features.\"\"\"\n    \n    def decorator(func: Callable) -> Callable:\n        @functools.wraps(func)\n        def wrapper(*args, **kwargs):\n            # Generate operation name\n            op_name = operation_name or f\"{func.__module__}.{func.__name__}\"\n            \n            # Check cache if enabled\n            if cache_result:\n                cache_key = f\"perf_cache_{op_name}_{hash(str(args) + str(kwargs))}\"\n                cached_result = cache.get(cache_key)\n                if cached_result is not None:\n                    logger.debug(f\"Cache hit for {op_name}\")\n                    return cached_result\n            \n            # Monitor performance\n            with PerformanceMonitor(op_name) as monitor:\n                try:\n                    result = func(*args, **kwargs)\n                    \n                    # Cache result if enabled\n                    if cache_result:\n                        cache.set(cache_key, result, timeout=cache_timeout)\n                    \n                    # Log arguments if requested\n                    if include_args and args:\n                        logger.debug(f\"{op_name} called with args: {args[:3]}{'...' if len(args) > 3 else ''}\")\n                    \n                    return result\n                    \n                except Exception as e:\n                    logger.error(f\"Exception in {op_name}: {e}\", exc_info=True)\n                    raise\n        \n        return wrapper\n    return decorator\n\n\n@contextmanager\ndef memory_monitor(operation: str, alert_threshold_mb: float = 100):\n    \"\"\"Context manager for monitoring memory usage during operations.\"\"\"\n    profiler = MemoryProfiler()\n    \n    # Take initial snapshot\n    initial_snapshot = profiler.take_snapshot(f\"{operation}_start\")\n    \n    try:\n        yield profiler\n    finally:\n        # Take final snapshot\n        final_snapshot = profiler.take_snapshot(f\"{operation}_end\")\n        \n        if initial_snapshot and final_snapshot:\n            memory_delta = final_snapshot['rss'] - initial_snapshot['rss']\n            \n            if memory_delta > alert_threshold_mb:\n                logger.warning(\n                    f\"High memory usage in {operation}: \"\n                    f\"{memory_delta:.1f}MB increase (threshold: {alert_threshold_mb}MB)\"\n                )\n            else:\n                logger.debug(f\"Memory usage for {operation}: {memory_delta:.1f}MB\")\n\n\nclass SystemMonitor:\n    \"\"\"System-wide performance monitoring.\"\"\"\n    \n    @staticmethod\n    def get_system_stats() -> Dict[str, Any]:\n        \"\"\"Get comprehensive system performance statistics.\"\"\"\n        try:\n            cpu_percent = psutil.cpu_percent(interval=1)\n            memory = psutil.virtual_memory()\n            disk = psutil.disk_usage('/')\n            \n            stats = {\n                'cpu': {\n                    'percent': cpu_percent,\n                    'count': psutil.cpu_count(),\n                    'load_average': psutil.getloadavg() if hasattr(psutil, 'getloadavg') else None,\n                },\n                'memory': {\n                    'total': memory.total / 1024 / 1024 / 1024,  # GB\n                    'available': memory.available / 1024 / 1024 / 1024,  # GB\n                    'percent': memory.percent,\n                    'used': memory.used / 1024 / 1024 / 1024,  # GB\n                },\n                'disk': {\n                    'total': disk.total / 1024 / 1024 / 1024,  # GB\n                    'used': disk.used / 1024 / 1024 / 1024,  # GB\n                    'free': disk.free / 1024 / 1024 / 1024,  # GB\n                    'percent': disk.percent,\n                },\n                'timestamp': timezone.now().isoformat(),\n            }\n            \n            return stats\n            \n        except Exception as e:\n            logger.error(f\"Failed to get system stats: {e}\")\n            return {}\n    \n    @staticmethod\n    def check_system_health() -> Dict[str, Any]:\n        \"\"\"Check system health and return alerts.\"\"\"\n        stats = SystemMonitor.get_system_stats()\n        alerts = []\n        status = 'healthy'\n        \n        if stats:\n            # CPU alerts\n            if stats['cpu']['percent'] > 80:\n                alerts.append(f\"High CPU usage: {stats['cpu']['percent']:.1f}%\")\n                status = 'warning'\n            \n            # Memory alerts\n            if stats['memory']['percent'] > 85:\n                alerts.append(f\"High memory usage: {stats['memory']['percent']:.1f}%\")\n                if stats['memory']['percent'] > 95:\n                    status = 'critical'\n                else:\n                    status = 'warning'\n            \n            # Disk alerts\n            if stats['disk']['percent'] > 90:\n                alerts.append(f\"Low disk space: {stats['disk']['percent']:.1f}% used\")\n                status = 'critical' if stats['disk']['percent'] > 95 else 'warning'\n        \n        return {\n            'status': status,\n            'alerts': alerts,\n            'stats': stats,\n            'checked_at': timezone.now().isoformat(),\n        }\n\n\n# Global instances for easy access\nquery_analyzer = QueryAnalyzer()\nsystem_monitor = SystemMonitor()