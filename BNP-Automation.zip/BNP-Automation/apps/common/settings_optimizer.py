"""Django settings optimization and validation utilities.

This module provides utilities for optimizing Django settings, validating
configuration, and implementing performance improvements across the application.
"""

import logging
import os
import sys
from typing import Dict, Any, List, Optional, Tuple
from pathlib import Path
from django.conf import settings
from django.core.cache import cache
from django.core.management.base import CommandError

logger = logging.getLogger(__name__)


class SettingsOptimizer:
    """Comprehensive Django settings optimization and validation."""
    
    def __init__(self):
        self.optimization_results = {}
        self.validation_errors = []
        self.recommendations = []
    
    def optimize_database_settings(self) -> Dict[str, Any]:
        """
        Optimize database settings for better performance.
        
        Returns:
            Dict with optimization recommendations
        """
        optimizations = {
            'connection_pooling': {},
            'query_optimization': {},
            'index_recommendations': [],
        }
        
        try:
            db_config = settings.DATABASES.get('default', {})
            engine = db_config.get('ENGINE', '')
            
            if 'postgresql' in engine.lower():
                optimizations['connection_pooling'] = {
                    'CONN_MAX_AGE': 600,  # 10 minutes
                    'ATOMIC_REQUESTS': True,
                    'OPTIONS': {
                        'MAX_CONNS': 20,
                        'MIN_CONNS': 5,
                    }
                }
                
            elif 'sqlite' in engine.lower():
                optimizations['query_optimization'] = {
                    'OPTIONS': {
                        'timeout': 20,
                        'check_same_thread': False,
                    }
                }
                
            logger.info(f"Database optimization completed for {engine}")
            
        except Exception as e:
            logger.error(f"Database optimization failed: {e}")
            
        return optimizations
    
    def optimize_cache_settings(self) -> Dict[str, Any]:
        """
        Optimize caching configuration for better performance.
        
        Returns:
            Dict with cache optimization settings
        """
        cache_config = {
            'recommended_backends': {},
            'timeout_settings': {},
            'key_prefixes': {},
        }
        
        try:
            current_cache = getattr(settings, 'CACHES', {})
            
            # Redis optimization (if available)
            cache_config['recommended_backends']['redis'] = {
                'BACKEND': 'django_redis.cache.RedisCache',
                'LOCATION': 'redis://127.0.0.1:6379/1',
                'OPTIONS': {
                    'CLIENT_CLASS': 'django_redis.client.DefaultClient',
                    'CONNECTION_POOL_KWARGS': {
                        'max_connections': 20,
                        'retry_on_timeout': True,
                    },
                    'COMPRESSOR': 'django_redis.compressors.zlib.ZlibCompressor',
                    'SERIALIZER': 'django_redis.serializers.json.JSONSerializer',
                },
                'TIMEOUT': 300,  # 5 minutes default
            }
            
            # Memory cache optimization
            cache_config['recommended_backends']['locmem'] = {
                'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
                'LOCATION': 'unique-snowflake',
                'OPTIONS': {
                    'MAX_ENTRIES': 10000,
                    'CULL_FREQUENCY': 4,
                },
            }
            
            # Timeout recommendations by use case
            cache_config['timeout_settings'] = {
                'user_sessions': 1800,     # 30 minutes
                'api_responses': 300,      # 5 minutes
                'static_content': 86400,   # 24 hours
                'database_queries': 600,   # 10 minutes
                'user_preferences': 3600,  # 1 hour
            }
            
            logger.info("Cache optimization recommendations generated")
            
        except Exception as e:
            logger.error(f"Cache optimization failed: {e}")
            
        return cache_config
    
    def validate_security_settings(self) -> List[str]:
        """
        Validate security-related settings and provide recommendations.
        
        Returns:
            List of security recommendations
        """
        recommendations = []
        
        try:
            # Check DEBUG setting
            if getattr(settings, 'DEBUG', True):
                recommendations.append(
                    "WARNING: DEBUG=True in production is a security risk"
                )
            
            # Check SECRET_KEY
            secret_key = getattr(settings, 'SECRET_KEY', '')
            if not secret_key or len(secret_key) < 50:
                recommendations.append(
                    "SECRET_KEY should be at least 50 characters long"
                )
            
            # Check ALLOWED_HOSTS
            allowed_hosts = getattr(settings, 'ALLOWED_HOSTS', [])
            if '*' in allowed_hosts:
                recommendations.append(
                    "ALLOWED_HOSTS should not include '*' in production"
                )
            
            # Check SECURE_SSL_REDIRECT
            if not getattr(settings, 'SECURE_SSL_REDIRECT', False):
                recommendations.append(
                    "Consider enabling SECURE_SSL_REDIRECT for HTTPS"
                )
            
            # Check SESSION_COOKIE_SECURE
            if not getattr(settings, 'SESSION_COOKIE_SECURE', False):
                recommendations.append(
                    "Enable SESSION_COOKIE_SECURE for HTTPS environments"
                )
            
            # Check CSRF_COOKIE_SECURE
            if not getattr(settings, 'CSRF_COOKIE_SECURE', False):
                recommendations.append(
                    "Enable CSRF_COOKIE_SECURE for HTTPS environments"
                )
            
            # Check SECURE_BROWSER_XSS_FILTER
            if not getattr(settings, 'SECURE_BROWSER_XSS_FILTER', False):
                recommendations.append(
                    "Enable SECURE_BROWSER_XSS_FILTER for XSS protection"
                )
            
            logger.info(f"Security validation completed: {len(recommendations)} recommendations")
            
        except Exception as e:
            logger.error(f"Security validation failed: {e}")
            recommendations.append(f"Error validating security settings: {e}")
            
        return recommendations
    
    def optimize_logging_configuration(self) -> Dict[str, Any]:
        """
        Generate optimized logging configuration.
        
        Returns:
            Dict with logging optimization settings
        """
        logging_config = {
            'version': 1,
            'disable_existing_loggers': False,
            'formatters': {
                'verbose': {
                    'format': '{levelname} {asctime} {module} {process:d} {thread:d} {message}',
                    'style': '{',
                },
                'simple': {
                    'format': '{levelname} {asctime} {message}',
                    'style': '{',
                },
                'json': {
                    '()': 'pythonjsonlogger.jsonlogger.JsonFormatter',
                    'format': '%(asctime)s %(name)s %(levelname)s %(message)s'
                },
            },
            'handlers': {
                'console': {
                    'level': 'INFO',
                    'class': 'logging.StreamHandler',
                    'formatter': 'simple'
                },
                'file': {
                    'level': 'DEBUG',
                    'class': 'logging.handlers.RotatingFileHandler',
                    'filename': 'logs/django.log',
                    'maxBytes': 10485760,  # 10MB
                    'backupCount': 5,
                    'formatter': 'verbose',
                },
                'error_file': {
                    'level': 'ERROR',
                    'class': 'logging.handlers.RotatingFileHandler',
                    'filename': 'logs/django_errors.log',
                    'maxBytes': 10485760,  # 10MB
                    'backupCount': 10,
                    'formatter': 'verbose',
                },
                'security_file': {
                    'level': 'INFO',
                    'class': 'logging.handlers.RotatingFileHandler',
                    'filename': 'logs/security.log',
                    'maxBytes': 10485760,  # 10MB
                    'backupCount': 20,
                    'formatter': 'json',
                },
            },
            'loggers': {
                'django': {
                    'handlers': ['console', 'file'],
                    'level': 'INFO',
                    'propagate': True,
                },
                'django.security': {
                    'handlers': ['security_file', 'console'],
                    'level': 'INFO',
                    'propagate': False,
                },
                'apps': {
                    'handlers': ['console', 'file'],
                    'level': 'DEBUG',
                    'propagate': True,
                },
                'celery': {
                    'handlers': ['console', 'file'],
                    'level': 'INFO',
                    'propagate': True,
                },
            },
            'root': {
                'handlers': ['console', 'error_file'],
                'level': 'WARNING',
            },
        }
        
        logger.info("Logging configuration optimization completed")
        return logging_config
    
    def check_static_files_optimization(self) -> Dict[str, Any]:
        """
        Check and optimize static files configuration.
        
        Returns:
            Dict with static files optimization recommendations
        """
        static_config = {
            'compression': {},
            'cdn_recommendations': {},
            'caching_headers': {},
        }
        
        try:
            # Check if compression is enabled
            static_config['compression'] = {
                'whitenoise_enabled': 'whitenoise' in getattr(settings, 'MIDDLEWARE', []),
                'gzip_enabled': getattr(settings, 'STATICFILES_STORAGE', '').endswith('CompressedManifestStaticFilesStorage'),
                'recommendations': [
                    "Use WhiteNoise for serving static files in production",
                    "Enable gzip compression for static assets",
                    "Consider using a CDN for static file delivery",
                ]
            }
            
            # CDN recommendations
            static_config['cdn_recommendations'] = {
                'cloudflare': 'Consider Cloudflare for global CDN',
                'aws_cloudfront': 'AWS CloudFront for AWS-hosted applications',
                'azure_cdn': 'Azure CDN for Azure-hosted applications',
            }
            
            # Caching headers
            static_config['caching_headers'] = {
                'max_age': 31536000,  # 1 year for static assets
                'immutable': True,
                'public': True,
            }
            
            logger.info("Static files optimization check completed")
            
        except Exception as e:
            logger.error(f"Static files optimization check failed: {e}")
            
        return static_config
    
    def generate_performance_report(self) -> Dict[str, Any]:
        """
        Generate comprehensive performance optimization report.
        
        Returns:
            Dict with complete performance analysis
        """
        report = {
            'database': self.optimize_database_settings(),
            'cache': self.optimize_cache_settings(),
            'security': self.validate_security_settings(),
            'logging': self.optimize_logging_configuration(),
            'static_files': self.check_static_files_optimization(),
            'environment_check': self._check_environment(),
            'middleware_optimization': self._optimize_middleware(),
        }
        
        logger.info("Performance optimization report generated")
        return report
    
    def _check_environment(self) -> Dict[str, Any]:
        """Check environment-specific optimizations."""
        env_info = {
            'python_version': sys.version_info[:3],
            'django_version': getattr(settings, 'DJANGO_VERSION', 'Unknown'),
            'environment': os.getenv('DJANGO_ENVIRONMENT', 'development'),
            'recommendations': []
        }
        
        # Python version check
        if sys.version_info < (3, 8):
            env_info['recommendations'].append(
                "Consider upgrading to Python 3.8+ for better performance"
            )
        
        # Memory recommendations
        env_info['recommendations'].extend([
            "Monitor memory usage with tools like memory_profiler",
            "Use connection pooling for database connections",
            "Implement proper pagination for large datasets",
        ])
        
        return env_info
    
    def _optimize_middleware(self) -> List[str]:
        """Optimize middleware configuration."""
        recommendations = []
        
        middleware = getattr(settings, 'MIDDLEWARE', [])
        
        # Check for security middleware
        security_middleware = [
            'django.middleware.security.SecurityMiddleware',
            'django.contrib.sessions.middleware.SessionMiddleware',
            'django.middleware.csrf.CsrfViewMiddleware',
            'django.contrib.auth.middleware.AuthenticationMiddleware',
        ]
        
        for mw in security_middleware:
            if mw not in middleware:
                recommendations.append(f"Consider adding {mw} for security")
        
        # Performance middleware recommendations
        if 'whitenoise.middleware.WhiteNoiseMiddleware' not in middleware:
            recommendations.append("Add WhiteNoise middleware for static files")
        
        return recommendations


class EnvironmentValidator:
    """Validate environment configuration for optimal performance."""
    
    @staticmethod
    def validate_required_packages() -> List[str]:
        """
        Validate that required packages are installed.
        
        Returns:
            List of missing or outdated packages
        """
        required_packages = [
            'django',
            'celery',
            'redis',
            'psycopg2-binary',
            'whitenoise',
            'gunicorn',
            'django-redis',
        ]
        
        missing_packages = []
        
        for package in required_packages:
            try:
                __import__(package.replace('-', '_'))
            except ImportError:
                missing_packages.append(package)
                logger.warning(f"Recommended package not found: {package}")
        
        return missing_packages
    
    @staticmethod
    def check_environment_variables() -> Dict[str, str]:
        """
        Check for required environment variables.
        
        Returns:
            Dict of missing environment variables
        """
        required_env_vars = [
            'SECRET_KEY',
            'DATABASE_URL',
            'REDIS_URL',
            'EMAIL_HOST',
            'EMAIL_HOST_PASSWORD',
        ]
        
        missing_vars = {}
        
        for var in required_env_vars:
            value = os.getenv(var)
            if not value:
                missing_vars[var] = "Environment variable not set"
                logger.warning(f"Environment variable missing: {var}")
            elif var == 'SECRET_KEY' and len(value) < 50:
                missing_vars[var] = "SECRET_KEY too short"
        
        return missing_vars


# Global optimizer instance
settings_optimizer = SettingsOptimizer()
environment_validator = EnvironmentValidator()