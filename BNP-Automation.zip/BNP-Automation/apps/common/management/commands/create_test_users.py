from django.core.management.base import BaseCommand
from apps.user_app.models import User
from apps.common.tests.constants import *
from django.utils import timezone

class Command(BaseCommand):
    help = 'Create predefined test users for testing purposes.'

    def handle(self, *args, **kwargs):

        # Create predefined users 
        for name, is_staff, is_superuser, password, user_type in [
            (TESTING_ACCOUNT_PLACEHOLDER, False, False, TESTING_ACCOUNT_PLACEHOLDER_PASSWORD, User.UserType.PLACEHOLDER),
            (TESTING_ACCOUNT_NORMAL, False, False, TESTING_ACCOUNT_NORMAL_PASSWORD, User.UserType.NORMAL),
            (TESTING_ACCOUNT_APP_ADMIN, True, True, TESTING_ACCOUNT_APP_ADMIN_PASSWORD, User.UserType.APP_ADMIN),
            (TESTING_ACCOUNT_APP_STAFF, True, False, TESTING_ACCOUNT_APP_STAFF_PASSWORD, User.UserType.APP_STAFF),
        ]:
            user, created = User.objects.get_or_create(
                name = name,
                email=f"{name}@{name}.pt",
                is_staff=is_staff,
                is_superuser=is_superuser,
                type=user_type,
                defaults={'birth_date': timezone.now()}  # Set default birth_date for new users
            )
        
            if created:
                user.set_password(password)
                user.save()
        
                self.stdout.write(self.style.SUCCESS(f'User "{name}" created successfully.'))
            else:
                self.stdout.write(self.style.WARNING(f'User "{name}" already exists.'))
    
    