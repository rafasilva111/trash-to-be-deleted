"""Common utilities for code quality and optimization across the application.

This module provides shared utilities for logging, error handling, performance
monitoring, and code quality improvements that can be used across all apps.
"""

import logging
import time
import functools
from typing import Any, Callable, Dict, List, Optional, Type
from django.conf import settings

# Setup logger
logger = logging.getLogger(__name__)


def log_function_call(include_args: bool = False, include_result: bool = False):
    """
    Decorator to log function calls with optional argument and result logging.
    
    Args:
        include_args: Whether to log function arguments
        include_result: Whether to log function return value
        
    Example:
        @log_function_call(include_args=True)
        def my_function(x, y):
            return x + y
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            func_name = f"{func.__module__}.{func.__name__}"
            
            if include_args:
                logger.debug(f"Calling {func_name} with args={args}, kwargs={kwargs}")
            else:
                logger.debug(f"Calling {func_name}")
            
            try:
                result = func(*args, **kwargs)
                if include_result:
                    logger.debug(f"{func_name} returned: {result}")
                return result
            except Exception as e:
                logger.error(f"{func_name} raised {type(e).__name__}: {e}")
                raise
                
        return wrapper
    return decorator


def safe_operation(default_return: Any = None, log_errors: bool = True):
    """
    Decorator to safely execute operations with error handling.
    
    Args:
        default_return: Value to return if operation fails
        log_errors: Whether to log errors
        
    Example:
        @safe_operation(default_return=[])
        def risky_operation():
            # This operation might fail
            return some_data
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            try:
                return func(*args, **kwargs)
            except Exception as e:
                if log_errors:
                    logger.error(f"Safe operation {func.__name__} failed: {e}")
                return default_return
        return wrapper
    return decorator


def validate_input(validators: Dict[str, Callable[[Any], bool]]):
    """
    Decorator to validate function inputs.
    
    Args:
        validators: Dictionary mapping parameter names to validation functions
        
    Example:
        @validate_input({'x': lambda x: isinstance(x, int), 'y': lambda y: y > 0})
        def divide(x, y):
            return x / y
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            import inspect
            sig = inspect.signature(func)
            bound_args = sig.bind(*args, **kwargs)
            bound_args.apply_defaults()
            
            for param_name, validator in validators.items():
                if param_name in bound_args.arguments:
                    value = bound_args.arguments[param_name]
                    if not validator(value):
                        raise ValueError(f"Invalid value for parameter {param_name}: {value}")
            
            return func(*args, **kwargs)
        return wrapper
    return decorator


class PerformanceMonitor:
    """Context manager for monitoring performance of code blocks."""
    
    def __init__(self, operation_name: str, threshold_seconds: float = 1.0):
        self.operation_name = operation_name
        self.threshold_seconds = threshold_seconds
        self.start_time = None
        
    def __enter__(self):
        self.start_time = time.time()
        logger.debug(f"Starting performance monitoring for: {self.operation_name}")
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.start_time:
            duration = time.time() - self.start_time
            if duration > self.threshold_seconds:
                logger.warning(f"Slow operation detected: {self.operation_name} took {duration:.3f}s")
            else:
                logger.debug(f"Performance: {self.operation_name} completed in {duration:.3f}s")


def get_class_info(cls: Type) -> Dict[str, Any]:
    """
    Get comprehensive information about a class.
    
    Args:
        cls: The class to analyze
        
    Returns:
        Dictionary with class information
    """
    return {
        'name': cls.__name__,
        'module': cls.__module__,
        'bases': [base.__name__ for base in cls.__bases__],
        'methods': [name for name in dir(cls) if not name.startswith('_') and callable(getattr(cls, name))],
        'attributes': [name for name in dir(cls) if not name.startswith('_') and not callable(getattr(cls, name))],
        'doc': cls.__doc__,
    }


def batch_process(items: List[Any], batch_size: int = 100, operation: Callable = None):
    """
    Process items in batches for better memory management.
    
    Args:
        items: List of items to process
        batch_size: Number of items per batch
        operation: Function to apply to each batch
        
    Yields:
        Processed batches
    """
    for i in range(0, len(items), batch_size):
        batch = items[i:i + batch_size]
        logger.debug(f"Processing batch {i//batch_size + 1} with {len(batch)} items")
        
        if operation:
            yield operation(batch)
        else:
            yield batch


def memoize(maxsize: int = 128):
    """
    Simple memoization decorator with size limit.
    
    Args:
        maxsize: Maximum cache size
    """
    def decorator(func: Callable) -> Callable:
        cache = {}
        
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            key = str(args) + str(sorted(kwargs.items()))
            
            if key in cache:
                logger.debug(f"Cache hit for {func.__name__}")
                return cache[key]
            
            result = func(*args, **kwargs)
            
            if len(cache) >= maxsize:
                # Remove oldest entry
                cache.pop(next(iter(cache)))
                
            cache[key] = result
            logger.debug(f"Cached result for {func.__name__}")
            return result
            
        return wrapper
    return decorator