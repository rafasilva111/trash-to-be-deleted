from django.db import models
from apps.common.models import BaseModel
from apps.user_app.models import User
from django.core.exceptions import ValidationError
# Create your models here.

