###
#       General imports
##


##
#   Django
#

from django import forms
from django_filters import FilterSet, DateRangeFilter, BooleanFilter,ChoiceFilter,ModelChoiceFilter
from django.contrib.auth.models import Group
from django_filters import MultipleChoiceFilter, CharFilter
from django.db.models import Q

###
#       App specific imports
##


##
#   Models
#

from apps.user_app.models import User, Invitation
from apps.user_app.models import ProcessType




class UserFilter(FilterSet):
    
    search = CharFilter(
        method='filter_by_search',
        label='Search',
        widget=forms.TextInput(attrs={
            'class': 'form-control form-control',
            'placeholder': 'Search name or email...'
        })
    )
        
    type = ChoiceFilter( 
        choices=User.UserType.choices,
        label='Type:',
        widget=forms.Select(attrs={'class': 'form-control rounded-0'})
    )
    

    is_active = ChoiceFilter(
        field_name='is_active',
        label='Active:',
        choices=[
            (True, 'Yes'),  # Filter active users
            (False, 'No')   # Filter inactive users
        ],
        widget=forms.Select(attrs={'class': 'form-control rounded-0'})
    )
    
    is_staff = ChoiceFilter(
        field_name='is_staff',
        label='Staff:'        ,
        choices=[
            (True, 'Yes'),  # Filter active users
            (False, 'No')   # Filter inactive users
        ],
        widget=forms.Select(attrs={'class': 'form-control rounded-0'})
    )


    class Meta:
        model = User
        fields = {}
    
    def filter_by_search(self, queryset, name, value):
        return queryset.filter(
            Q(name__icontains=value) |
            Q(email__icontains=value) |
            Q(id__icontains=value) |
            Q(title__icontains=value)     
        )
        
class InvitationFilter(FilterSet):
    
    search = CharFilter(
        method='filter_by_search',
        label='Search',
        widget=forms.TextInput(attrs={
            'class': 'form-control form-control',
            'placeholder': 'Search name or email...'
        })
    )
        
    sent_at = DateRangeFilter(
        field_name='sent_at',
        label='Sent At:',
        widget=forms.Select(attrs={'class': 'form-control rounded-0'})
    )
    
    group = ModelChoiceFilter(
        queryset=Group.objects.filter(name__in=[User.UserType.APP_STAFF, User.UserType.APP_ADMIN]),
        label='Group:',
        widget=forms.Select(attrs={'class': 'form-control rounded-0'})
    )
    
    class Meta:
        model = Invitation
        fields = {}
    
    def filter_by_search(self, queryset, name, value):
        return queryset.filter(
            Q(invited__name__icontains=value) |
            Q(inviter__name__icontains=value) |
            Q(id__icontains=value)   
        )
        