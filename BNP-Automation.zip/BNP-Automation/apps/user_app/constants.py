from apps.user_app.models import User

# Define groups and their permissions
GROUPS_PERMISSIONS = {
    User.UserType.PLACEHOLDER: [
    ],
    User.UserType.NORMAL: [
        # User permissions
        "can_view_user","can_view_users",
        # Invite permissions
        "can_view_invites",
        # Task permissions
        "can_view_task","can_view_tasks",
        # Job permissions
        "can_view_job","can_view_jobs",
    ],
    User.UserType.APP_STAFF: [
        # User permissions
        "can_view_user","can_view_users","can_edit_user","can_enable_user",
        # Invite permissions
        "can_view_invites",
        # Task permissions
        "can_view_task","can_view_tasks","can_restart_task", "can_cancel_task", "can_pause_task", "can_resume_task","can_edit_task",
        # Job permissions
        "can_view_job","can_view_jobs", "can_pause_job", "can_resume_job" ,
    ],
    User.UserType.APP_ADMIN: [
        # User permissions
        "can_view_user","can_view_users","can_invite_user","can_edit_user","can_delete_user","can_enable_user","can_disable_user",
        # Invite permissions
        "can_view_invites","can_edit_invite","can_delete_invite",
        # Task permissions
        "can_view_task","can_view_tasks","can_restart_task", "can_cancel_task", "can_create_task","can_edit_task","can_delete_task", "can_pause_task", "can_resume_task",
        # Job permissions
        "can_view_job","can_view_jobs", "can_create_job","can_edit_job","can_delete_job", "can_pause_job", "can_resume_job",
    ],
}

"""

    Constraints

"""

REGISTER_MINIMUM_AGE = 18


"""

    Strings

"""

" User constraints errors "

STRING_USER_BIRTHDATE_PAST_ERROR = "Birth date must be in the past."
STRING_USER_BIRTHDATE_YOUNG_ERROR = "You must be at least 18 years old."





