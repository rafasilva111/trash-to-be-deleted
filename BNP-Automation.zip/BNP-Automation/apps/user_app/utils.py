"""Optimized user management utilities with enhanced logging and error handling.

This module provides utilities for user management operations with comprehensive
logging, error handling, and performance optimizations.
"""

import logging
import time
from typing import Dict, Any, Optional, List
from django.contrib.auth import authenticate
from django.core.cache import cache
from django.core.exceptions import ValidationError
from django.db import transaction
from django.utils import timezone

from apps.common.utils import log_function_call, safe_operation, PerformanceMonitor

logger = logging.getLogger(__name__)


class UserOperationManager:
    """Centralized manager for user operations with enhanced logging and caching."""
    
    def __init__(self):
        self.cache_timeout = 300  # 5 minutes
        self.max_login_attempts = 5
        self.lockout_duration = 900  # 15 minutes
    
    @log_function_call(include_args=False)
    def create_user_with_validation(self, user_data: Dict[str, Any], created_by: Optional[Any] = None) -> Optional[Any]:
        """
        Create a new user with comprehensive validation and logging.
        
        Args:
            user_data: Dictionary containing user information
            created_by: User who is creating this account (for audit trail)
            
        Returns:
            Created user instance or None if failed
        """
        from apps.user_app.models import User
        
        try:
            with PerformanceMonitor("user_creation"):
                # Validate required fields
                required_fields = ['email', 'first_name', 'last_name']
                missing_fields = [field for field in required_fields if not user_data.get(field)]
                
                if missing_fields:
                    logger.error(f"User creation failed: Missing required fields: {missing_fields}")
                    raise ValidationError(f"Missing required fields: {', '.join(missing_fields)}")
                
                # Check for duplicate email
                if User.objects.filter(email=user_data['email']).exists():
                    logger.warning(f"User creation failed: Email {user_data['email']} already exists")
                    raise ValidationError(f"User with email {user_data['email']} already exists")
                
                # Create user with transaction
                with transaction.atomic():
                    user = User.objects.create_user(**user_data)
                    
                    # Set audit trail if provided
                    if created_by:
                        user.created_by = created_by
                        user.save()
                    
                    # Invalidate related caches
                    self.invalidate_user_caches()
                    
                    logger.info(f"Successfully created user: {user.email} (ID: {user.id})")
                    return user
                    
        except ValidationError:
            raise
        except Exception as e:
            logger.error(f"Unexpected error creating user {user_data.get('email', 'unknown')}: {e}")
            return None
    
    @safe_operation(default_return=False)
    def authenticate_user_safely(self, email: str, password: str, request_ip: str = None) -> bool:
        """
        Safely authenticate user with rate limiting and logging.
        
        Args:
            email: User email
            password: User password  
            request_ip: IP address of the request
            
        Returns:
            bool: True if authentication successful
        """
        # Check for account lockout
        lockout_key = f"lockout:{email}"
        if cache.get(lockout_key):
            logger.warning(f"Authentication blocked - account locked: {email} from {request_ip}")
            return False
        
        # Track failed attempts
        attempts_key = f"attempts:{email}"
        failed_attempts = cache.get(attempts_key, 0)
        
        if failed_attempts >= self.max_login_attempts:
            # Lock account
            cache.set(lockout_key, True, self.lockout_duration)
            logger.warning(f"Account locked after {failed_attempts} failed attempts: {email}")
            return False
        
        # Attempt authentication
        user = authenticate(email=email, password=password)
        
        if user:
            # Reset failed attempts on success
            cache.delete(attempts_key)
            logger.info(f"Successful authentication: {email} from {request_ip}")
            return True
        else:
            # Increment failed attempts
            failed_attempts += 1
            cache.set(attempts_key, failed_attempts, self.lockout_duration)
            logger.warning(f"Failed authentication attempt {failed_attempts}/{self.max_login_attempts}: {email} from {request_ip}")
            return False
    
    def get_user_stats_cached(self, user_id: int) -> Dict[str, Any]:
        """
        Get user statistics with caching for performance.
        
        Args:
            user_id: User ID
            
        Returns:
            Dictionary with user statistics
        """
        cache_key = f"user_stats:{user_id}"
        stats = cache.get(cache_key)
        
        if stats is None:
            with PerformanceMonitor("user_stats_calculation"):
                from apps.user_app.models import User
                from apps.task_app.models import Task
                
                try:
                    user = User.objects.get(id=user_id)
                    stats = {
                        'total_tasks': Task.objects.filter(created_by=user).count(),
                        'completed_tasks': Task.objects.filter(created_by=user, status='completed').count(),
                        'failed_tasks': Task.objects.filter(created_by=user, status='failed').count(),
                        'last_login': user.last_login,
                        'is_active': user.is_active,
                        'date_joined': user.date_joined,
                    }
                    
                    # Calculate success rate
                    total = stats['total_tasks']
                    completed = stats['completed_tasks']
                    stats['success_rate'] = (completed / total * 100) if total > 0 else 0
                    
                    cache.set(cache_key, stats, self.cache_timeout)
                    logger.debug(f"Calculated and cached stats for user {user_id}")
                    
                except User.DoesNotExist:
                    logger.error(f"User {user_id} not found for stats calculation")
                    stats = {}
                except Exception as e:
                    logger.error(f"Error calculating stats for user {user_id}: {e}")
                    stats = {}
        
        return stats
    
    def invalidate_user_caches(self, user_id: Optional[int] = None):
        """
        Invalidate user-related caches.
        
        Args:
            user_id: Specific user ID to invalidate, or None for all
        """
        if user_id:
            cache_keys = [
                f"user_stats:{user_id}",
                f"user_permissions:{user_id}",
                f"user_profile:{user_id}",
            ]
        else:
            # Pattern-based cache invalidation would be better with Redis
            cache_keys = [
                "user_list",
                "active_users",
                "user_count",
            ]
        
        cache.delete_many(cache_keys)
        logger.debug(f"Invalidated {len(cache_keys)} user cache keys")
    
    @log_function_call()
    def bulk_update_users(self, user_updates: List[Dict[str, Any]], updated_by: Optional[Any] = None) -> Dict[str, int]:
        """
        Perform bulk user updates with transaction safety.
        
        Args:
            user_updates: List of dictionaries with 'id' and update fields
            updated_by: User performing the updates
            
        Returns:
            Dictionary with success/failure counts
        """
        results = {'updated': 0, 'failed': 0, 'errors': []}
        
        try:
            with transaction.atomic():
                from apps.user_app.models import User
                
                for update_data in user_updates:
                    try:
                        user_id = update_data.pop('id')
                        user = User.objects.get(id=user_id)
                        
                        # Apply updates
                        for field, value in update_data.items():
                            if hasattr(user, field):
                                setattr(user, field, value)
                        
                        if updated_by:
                            user.updated_by = updated_by
                            
                        user.full_clean()  # Validate before saving
                        user.save()
                        
                        results['updated'] += 1
                        logger.debug(f"Updated user {user_id}")
                        
                    except User.DoesNotExist:
                        error_msg = f"User {update_data.get('id')} not found"
                        results['errors'].append(error_msg)
                        results['failed'] += 1
                        logger.warning(error_msg)
                    except ValidationError as e:
                        error_msg = f"Validation error for user {update_data.get('id')}: {e}"
                        results['errors'].append(error_msg)
                        results['failed'] += 1
                        logger.warning(error_msg)
                    except Exception as e:
                        error_msg = f"Error updating user {update_data.get('id')}: {e}"
                        results['errors'].append(error_msg)
                        results['failed'] += 1
                        logger.error(error_msg)
                
                # Invalidate caches after bulk updates
                self.invalidate_user_caches()
                
                logger.info(f"Bulk user update completed: {results['updated']} updated, {results['failed']} failed")
                
        except Exception as e:
            logger.error(f"Bulk user update transaction failed: {e}")
            results['errors'].append(str(e))
        
        return results


class UserSecurityManager:
    """Enhanced security management for user operations."""
    
    @staticmethod
    def validate_password_strength(password: str) -> Dict[str, Any]:
        """
        Validate password strength with detailed feedback.
        
        Args:
            password: Password to validate
            
        Returns:
            Dictionary with validation results
        """
        import re
        
        checks = {
            'length': len(password) >= 8,
            'uppercase': bool(re.search(r'[A-Z]', password)),
            'lowercase': bool(re.search(r'[a-z]', password)),
            'digit': bool(re.search(r'\d', password)),
            'special': bool(re.search(r'[!@#$%^&*(),.?":{}|<>]', password)),
            'no_common': password.lower() not in ['password', '12345678', 'qwerty', 'abc123'],
        }
        
        score = sum(checks.values())
        
        return {
            'valid': score >= 4,
            'score': score,
            'max_score': len(checks),
            'checks': checks,
            'feedback': UserSecurityManager._get_password_feedback(checks)
        }
    
    @staticmethod
    def _get_password_feedback(checks: Dict[str, bool]) -> List[str]:
        """Generate password feedback messages."""
        feedback = []
        
        if not checks['length']:
            feedback.append("Password must be at least 8 characters long")
        if not checks['uppercase']:
            feedback.append("Password must contain at least one uppercase letter")
        if not checks['lowercase']:
            feedback.append("Password must contain at least one lowercase letter")
        if not checks['digit']:
            feedback.append("Password must contain at least one digit")
        if not checks['special']:
            feedback.append("Password must contain at least one special character")
        if not checks['no_common']:
            feedback.append("Password is too common, please choose something more unique")
            
        return feedback


# Global instances for easy access
user_operations = UserOperationManager()
user_security = UserSecurityManager()