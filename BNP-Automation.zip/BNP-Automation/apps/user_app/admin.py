from django.contrib import admin
from apps.user_app.models import User, Invitation,  GroupInvite
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin, GroupAdmin
from django.contrib.auth.models import Group as DjangoGroup
from apps.user_app.forms import GroupInviteForm

###
#
#       User 
#   
##

class UserAdmin(BaseUserAdmin):
    list_display = ('email','is_active', 'last_login', 'created_at', 'updated_at', 'type')
    list_filter = ('is_active', 'type', 'created_at', 'updated_at')
    search_fields = ('email',)
    ordering = ('-created_at',)

    fieldsets = (
        (None, {'fields': ('email', 'password')}),
        ('Personal info', {'fields': ('type','name', 'title', 'birth_date', 'image')}),
        ('Permissions', {
            'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions'),
        }),
        ('Important dates', {'fields': ('last_login', 'created_at', 'updated_at')}),
    )
    
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'password1', 'password2')}
        ),
    )
    
    readonly_fields = ('last_login', 'created_at', 'updated_at')

###
#
#       Invitations
#   
##
  
class InvitationAdmin(admin.ModelAdmin):
    list_display = ('invited', 'token', 'inviter', 'created_at')
    list_filter = ( 'created_at', 'inviter')
    search_fields = ('invited', 'token', 'inviter__email')
    readonly_fields = ('token', 'created_at')



admin.site.register(User, UserAdmin)
admin.site.register(Invitation, InvitationAdmin)


