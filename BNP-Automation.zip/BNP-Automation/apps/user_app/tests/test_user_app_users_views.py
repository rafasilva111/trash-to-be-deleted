"""
================================================================================
USER APP VIEWS TEST SUITE
================================================================================

Description:
    Comprehensive test suite for User application views, focusing on user management
    functionality, permissions, filtering, pagination, and user interactions.

Test Coverage:
    - UserTableView: Permission-based access control, button visibility, search,
      filtering, and pagination functionality
    - UserDetailView: User detail view access and rendering
    - UserEditView: User edit form access and functionality

Dependencies:
    - Django TestCase framework
    - Custom _BaseViewTestCase from common.tests
    - User app models and views
    - Common test utilities and constants

Author: Rafael Silva
Created: 2026
Last Updated: January 2026

AI Regeneration Prompt:
    "Please analyze this Django User app test suite and add comprehensive comments
    following the current structure. Focus on explaining test methodologies,
    permission testing patterns, user role validation, search functionality,
    pagination logic, and assertion patterns. Include comments for test setup,
    data creation, expected behaviors, and edge case handling. Maintain existing
    comment style and improve code organization where possible."

================================================================================
"""

# ================================
# General Django Imports
# ================================
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from django.contrib.auth.models import Group, Permission
from django.test import override_settings
import unittest

# ================================
# Third Party Imports
# ================================
import inspect

# ================================
# User App Specific Imports
# ================================
from apps.user_app.models import User

# ================================
# Common App Imports
# ================================
from apps.common.tests.models import _BaseViewTestCase
from apps.common.tests.functions import print_prologue
from apps.common.tests.constants import *

# ================================
# Module Constants
# ================================
MODULE_NAME = "user_app"


class UserTableViewTest(_BaseViewTestCase):
    """
    Test suite for UserTableView functionality.
    
    Tests cover:
    - Permission-based access control for different user roles
    - Button visibility based on user permissions
    - Search and filtering capabilities (name, email, ID, partial search)
    - Case-insensitive search functionality
    - Pagination functionality with various page sizes
    - Template rendering and context data validation
    """
    
    # ================================
    # Test Configuration
    # ================================
    permission = "can_view_users"
    module = MODULE_NAME
    buttons = [
        CREATE_BUTTON_ID, EDIT_BUTTON_ID, DELETE_BUTTON_ID, 
        DETAILS_BUTTON_ID, DISABLE_BUTTON_ID, ENABLE_BUTTON_ID
    ]
    
    def setUp(self):
        """
        Set up test environment for UserTableView tests.
        
        Initializes:
        - URL for user table view
        - Template name for assertions
        - Calls parent setUp for user creation
        """
        super().setUp()
        self.url = reverse('users')
        self.template_name = 'cerebrus/user_app/user/table.html'
        
    # ================================
    # Permission Testing Methods
    # ================================
    
    def test_view_permissions(self):
        """
        Test view access permissions for different user roles.
        
        Validates that:
        - Normal users can access the view (200 status)
        - Staff users can access the view (200 status)  
        - Admin users can access the view (200 status)
        - All users have the required permission to view users
        """
        test_cases = [
            (self.normal_user, 200, True),      # Normal user with view permission
            (self.app_staff_user, 200, True),   # Staff user with view permission
            (self.app_admin_user, 200, True),   # Admin user with view permission
        ]
        
        for user, expected_status, should_have_permission in test_cases:
            with self.subTest(user=user.email):
                self.check_user_permission_and_response(
                    user, 
                    expected_status, 
                    should_have_permission=should_have_permission
                )
        
    # ================================
    # Button Permission Testing
    # ================================
    
    def test_buttons_permissions(self):
        """
        Test button visibility based on user permissions.
        
        Validates that action buttons are displayed correctly according to:
        - User role (normal, staff, admin)
        - Specific permissions (view, edit, create, delete, disable, enable)
        - Template conditional rendering logic
        - Self-protection mechanisms (users cannot disable/delete themselves)
        
        Creates placeholder users to populate the table for button testing.
        """
        print_prologue()
        
        # Create test data - placeholder users for table population
        users = self._create_placeholder_users(count=3)
        
        users[1].is_active = True
        users[1].save()
        
        # Define permission matrix for different user roles
        permission_test_cases = [
            # Normal user - only view permission
            (self.normal_user, {
                DETAILS_BUTTON_ID: "can_view_user"
            }),
            # Staff user - view, edit, and enable permissions
            (self.app_staff_user, {
                DETAILS_BUTTON_ID: "can_view_user",
                EDIT_BUTTON_ID: "can_edit_user",
                ENABLE_BUTTON_ID: "can_enable_user"
            }),
            # Admin user - full permissions
            (self.app_admin_user, {
                CREATE_BUTTON_ID: "can_invite_user",
                DETAILS_BUTTON_ID: "can_view_user",
                EDIT_BUTTON_ID: "can_edit_user",
                DELETE_BUTTON_ID: "can_delete_user",
                DISABLE_BUTTON_ID: "can_disable_user",
                ENABLE_BUTTON_ID: "can_enable_user"
            }),
        ]
        
        # Test button visibility for each user role
        for user, expected_buttons in permission_test_cases:
            with self.subTest(user=user.email):
                self._test_user_button_permissions(user, expected_buttons)
        
    def _test_user_button_permissions(self, user, expected_buttons):
        """
        Helper method to test button permissions for a specific user.
        
        Args:
            user: User instance to test
            expected_buttons: Dict of button IDs and required permissions
        """
        self.client.force_login(user)
        
        # Use search filter to show placeholder users created for testing
        response = self.client.get(self.url, {'search': 'aa'})
        
        # Verify user has required view permission
        if user.has_perm(self.permission_):
            self.assertEqual(response.status_code, 200)
            # Validate button visibility based on permissions
            self.check_user_button_permission(expected_buttons, response)
        else:
            # User should be denied access (403 Forbidden)
            self.assertEqual(response.status_code, 403)
        
    # ================================
    # Search and Filtering Tests
    # ================================
    
    def test_page_filter_search(self):
        """
        Test comprehensive search functionality in the user table.
        
        Validates:
        - Search by user name (exact and partial matches)
        - Search by user email
        - Search by user ID (numeric search)
        - Case-insensitive search functionality
        - Empty search query handling
        - Non-existent user search
        - Proper response status and context data
        - Template rendering with search results
        """
        print_prologue()
        
        # Get existing user for search testing
        searching_user = User.objects.get(name=TESTING_ACCOUNT_NORMAL)
        
        # Login as admin user for full access
        self._login_as_admin()
        
        # Test Case 1: Search by user name
        self._test_search_by_name(searching_user)
        
        # Test Case 2: Search by user email
        self._test_search_by_email(searching_user)
        
        # Test Case 3: Search by user ID
        self._test_search_by_id(searching_user)
        
        # Test Case 4: Partial search functionality
        self._test_partial_search(searching_user)
        
        # Test Case 5: Empty search query
        self._test_empty_search()
        
        # Test Case 6: Case-insensitive search
        self._test_case_insensitive_search()
        
        # Test Case 7: Non-existent user search
        self._test_nonexistent_user_search()
        
        print("\n")

    def _test_search_by_name(self, user):
        """Test search functionality with user name."""
        response = self.client.get(f"{self.url}?search={user.name}")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, TESTING_ACCOUNT_NORMAL)
        self.assertNotContains(response, TESTING_ACCOUNT_APP_STAFF)
        
    def _test_search_by_email(self, user):
        """Test search functionality with user email."""
        response = self.client.get(f"{self.url}?search={user.email}")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, TESTING_ACCOUNT_NORMAL)
        self.assertNotContains(response, TESTING_ACCOUNT_APP_STAFF)
        
    def _test_search_by_id(self, user):
        """Test search functionality with numeric user ID."""
        response = self.client.get(f"{self.url}?search={user.id}")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, TESTING_ACCOUNT_NORMAL)
        self.assertNotContains(response, TESTING_ACCOUNT_APP_STAFF)
        
    def _test_partial_search(self, user):
        """Test partial search functionality (substring matching)."""
        partial_name = user.name[3:]  # Get substring of user name
        response = self.client.get(f"{self.url}?search={partial_name}")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, TESTING_ACCOUNT_NORMAL)
        self.assertNotContains(response, TESTING_ACCOUNT_APP_STAFF)
        
    def _test_empty_search(self):
        """Test behavior with empty search query."""
        response = self.client.get(self.url, {'search': ''})
        self.assertEqual(response.status_code, 200, "Empty search should return 200 status")
        
    def _test_case_insensitive_search(self):
        """Test case-insensitive search functionality."""
        # Test uppercase search
        response = self.client.get(self.url, {'search': TESTING_ACCOUNT_NORMAL.upper()})
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, TESTING_ACCOUNT_NORMAL)
        self.assertNotContains(response, TESTING_ACCOUNT_APP_STAFF)
        
        # Test lowercase search
        response = self.client.get(self.url, {'search': TESTING_ACCOUNT_NORMAL.lower()})
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, TESTING_ACCOUNT_NORMAL)
        self.assertNotContains(response, TESTING_ACCOUNT_APP_STAFF)
        
    def _test_nonexistent_user_search(self):
        """Test search with non-existent user identifier."""
        response = self.client.get(self.url, {'search': 'nonexistentuser'})
        self.assertEqual(response.status_code, 200)
        
        # Verify empty state message is displayed
        self.assertContains(
            response, 
            'No users found...', 
            msg_prefix="Should display 'no users found' message"
        )
        
    # ================================
    # Pagination Testing Methods
    # ================================
    
    def test_pagination(self):
        """
        Test pagination functionality for user table.
        
        Validates:
        - Correct page navigation and numbering
        - Per-page item limits
        - Behavior when requesting pages beyond available range
        - Page context and template rendering
        - Pagination with large datasets
        """
        print_prologue()
        
        # Create sufficient test data for pagination testing (25 placeholder users)
        self._create_placeholder_users(count=25)
        
        # Login as admin for full access
        self._login_as_admin()
        
        # Test Case 1: Navigate to specific page with per_page limit
        self._test_specific_page_navigation()
        
        # Test Case 2: Request page beyond available range
        self._test_page_beyond_range()
        
        # Test Case 3: Different per_page values
        self._test_different_per_page_values()

    def _test_specific_page_navigation(self):
        """Test navigation to specific page with pagination controls."""
        response = self.client.get(self.url, {'page': 2, 'page_size': 10})
        self.assertEqual(response.status_code, 200)
        
        # Verify correct page is displayed
        self.assertContains(
            response, 
            "Page 2 of 3", 
            msg_prefix="Should display correct page information"
        )
        
    def _test_page_beyond_range(self):
        """Test behavior when requesting page beyond available range."""
        response = self.client.get(self.url, {'page': 10, 'page_size': 10})
        self.assertEqual(response.status_code, 200)
        
        # Should default to last available page
        self.assertContains(
            response, 
            "Page 3 of 3", 
            msg_prefix="Should default to last page when requesting beyond range"
        )
        
    def _test_different_per_page_values(self):
        """Test pagination with different items per page settings."""
        response = self.client.get(self.url, {'page': 1, 'page_size': 15})
        self.assertEqual(response.status_code, 200)
        
        # Verify pagination adjusts to different per_page values
        self.assertContains(
            response, 
            "Page 1 of 2", 
            msg_prefix="Should adjust pagination based on per_page value"
        )
        
    # ================================
    # Helper Methods
    # ================================
    
    def _create_placeholder_users(self, count=2):
        """
        Create placeholder users for testing purposes.
        
        Args:
            count (int): Number of placeholder users to create
            
        Returns:
            list: Created user instances
        
        Note:
            Creates users with UserType.PLACEHOLDER to avoid conflicts
            with existing test users and to ensure clean test data.
        """
        users = []
        for i in range(1, count + 1):
            user, created = User.objects.get_or_create(
                name="a" * i,  # Progressive naming for filtering tests
                email=f"{i}@{i}.pt",
                defaults={
                    'is_staff': False,
                    'is_superuser': False,
                    'is_active': i == 1,  # First user active, others inactive
                    'type': User.UserType.PLACEHOLDER
                }
            )
            users.append(user)
        return users
        
    def _login_as_admin(self):
        """Login as admin user for testing privileged operations."""
        self.client.login(
            email=f"{TESTING_ACCOUNT_APP_ADMIN}@{TESTING_ACCOUNT_APP_ADMIN}.pt", 
            password=TESTING_ACCOUNT_APP_ADMIN_PASSWORD
        )

    # ================================
    # Additional Test Methods
    # ================================
    
    def test_template_context_data(self):
        """
        Test that the view provides correct context data to the template.
        
        Validates:
        - Required context variables are present
        - Filter form is properly initialized
        - Permission flags are correctly set
        - User queryset is properly filtered
        """
        self._create_placeholder_users(count=3)
        self._login_as_admin()
        
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        
        # Verify required context variables
        context_keys = ['page_obj', 'filter', 'template_title']
        for key in context_keys:
            with self.subTest(context_key=key):
                self.assertIn(key, response.context, f"Context should contain '{key}'")
                


class UserDetailViewTest(_BaseViewTestCase):
    """
    Test suite for UserDetailView functionality.
    
    Tests cover:
    - View access and template rendering
    - Context data validation
    - User detail information display
    """
    
    def setUp(self):
        """
        Set up test environment for UserDetailView tests.
        
        Initializes:
        - URL for user detail view using admin user ID
        - Template name for assertions
        - Calls parent setUp for user creation
        """
        super().setUp()
        
        # Get admin user for detail view testing
        user = User.objects.get(
            email=f"{TESTING_ACCOUNT_APP_ADMIN}@{TESTING_ACCOUNT_APP_ADMIN}.pt"
        )
        self.url = reverse('user_detail', kwargs={'id': user.id})
        self.template_name = 'cerebrus/user_app/user/detail.html'

    def test_user_detail_view_access(self):
        """
        Test access to user detail view.
        
        Validates:
        - Authenticated users can access the view
        - Correct template is rendered
        - User information is displayed correctly
        """
        self.client.force_login(self.app_admin_user)
        response = self.client.get(self.url)
        
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, self.template_name)
        self.assertContains(response, TESTING_ACCOUNT_APP_ADMIN)


class UserEditViewTest(_BaseViewTestCase):
    """
    Test suite for UserEditView functionality.
    
    Tests cover:
    - View access and template rendering
    - Edit form initialization
    - Permission-based access control
    """
    
    def setUp(self):
        """
        Set up test environment for UserEditView tests.
        
        Initializes:
        - URL for user edit view using admin user ID
        - Template name for assertions
        - Calls parent setUp for user creation
        """
        super().setUp()
        
        # Get admin user for edit view testing
        user = User.objects.get(
            email=f"{TESTING_ACCOUNT_APP_ADMIN}@{TESTING_ACCOUNT_APP_ADMIN}.pt"
        )
        self.url = reverse('user_edit', kwargs={'id': user.id})
        self.template_name = 'cerebrus/user_app/user/edit.html'

    def test_user_edit_view_access(self):
        """
        Test access to user edit view.
        
        Validates:
        - Authenticated users can access the view
        - Correct template is rendered
        - Edit form is properly initialized
        """
        self.client.force_login(self.app_admin_user)
        response = self.client.get(self.url)
        
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, self.template_name)
        
    def test_user_edit_form_validation(self):
        """
        Test user edit form validation and submission.
        
        Validates:
        - Form accepts valid data
        - Invalid data is properly rejected
        - User information is updated correctly
        """
        self.client.force_login(self.app_admin_user)
        
        # Test valid form submission
        valid_data = {
            'name': 'Updated Admin Name',
            'email': f"{TESTING_ACCOUNT_APP_ADMIN}@{TESTING_ACCOUNT_APP_ADMIN}.pt",
            'is_active': True,
            'type': User.UserType.APP_ADMIN
        }
        
        response = self.client.post(self.url, valid_data)
        # Expecting redirect on successful form submission
        self.assertIn(response.status_code, [200, 302])
