###
#       General imports
##


##
#   Default
#

from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from django.contrib.auth.models import Group, Permission
from django.test import override_settings
import unittest

##
#   Extras
#

import inspect


###
#       App specific imports
##


##
#   Models
#




##
#   Serializers
#


##
#   Forms
#


##
#   Functions
#

from apps.common.tests.functions import print_prologue, create_test_invitations
from apps.common.tests.models import _BaseViewTestCase


##
#   Contants
#

from apps.common.tests.constants import *


# ================================
# Module Constants
# ================================
MODULE_NAME = "user_app"

class InviTationTestCase(_BaseViewTestCase):
        
    def setUp(self):
        super().setUp()
        from apps.user_app.models import User, Invitation
        # Create a test invitation
        self.test_invitation = Invitation.objects.create(
            invited="invite@test.com",
            inviter=User.objects.get(
                email=f"{TESTING_ACCOUNT_APP_ADMIN}@{TESTING_ACCOUNT_APP_ADMIN}.pt")
        )


class InvitationTableViewTest(_BaseViewTestCase):
    """
    Test suite for JobsTableView functionality.
    
    Tests cover:
    - Permission-based access control for job views
    - Button visibility based on user roles
    - Search and filtering capabilities for jobs
    - Pagination functionality for job listings
    - Template rendering and context data for jobs
    """
    
    # ================================
    # Test Configuration
    # ================================
    permission = "can_view_invites"
    module = MODULE_NAME
    buttons = [CREATE_BUTTON_ID, RESEND_BUTTON_ID, EDIT_BUTTON_ID, DELETE_BUTTON_ID]
    
    def setUp(self):
        """
        Set up test environment for JobsTableView tests.
        
        Initializes:
        - URL for jobs table view
        - Template name for assertions
        - Calls parent setUp for user creation
        """
        super().setUp()
        self.url = reverse('invites')
        self.template_name = 'cerebrus/user_app/invitations/table.html'
        
    # ================================
    # Permission Testing Methods
    # ================================
    
    def test_view_permissions(self):
        """
        Test view access permissions for different user roles.
        
        Validates that:
        - Placeholder users cannot access the jobs view (403 status)
        - Normal users can access the jobs view (200 status)
        - Staff users can access the jobs view (200 status)  
        - Admin users can access the jobs view (200 status)
        - All authorized users have the required permission to view jobs
        """
        test_cases = [
            (self.placeholder_user, 403, False),  # Placeholder user without permission
            (self.normal_user, 200, True),      # Normal user with view permission
            (self.app_staff_user, 200, True),   # Staff user with view permission
            (self.app_admin_user, 200, True),   # Admin user with view permission
        ]
        
        for user, expected_status, should_have_permission in test_cases:
            with self.subTest(user=user.email):
                self.check_user_permission_and_response(
                    user, 
                    expected_status, 
                    should_have_permission=should_have_permission
                )
        
    # ================================
    # Button Permission Testing
    # ================================
    
    def test_buttons_permissions(self):
        """
        Test button visibility based on user permissions for job actions.
        
        Validates that action buttons are displayed correctly according to:
        - User role (placeholder, normal, staff, admin)
        - Specific job permissions (view, edit, create, delete)
        - Template conditional rendering logic for job operations
        
        Creates test jobs to populate the table for button testing.
        """
        print_prologue()
        
        # Create test data - ETL jobs for table population
        self._create_test_jobs(count=2)
        from apps.task_app.models import Job
        teste = Job.objects.all()
        # Define permission matrix for different user roles
        permission_test_cases = [
            # Placeholder user - no job permissions
            (self.placeholder_user, {}),
            # Normal user - only job view permission
            (self.normal_user, {
                DETAILS_BUTTON_ID: "can_view_job"
            }),
            # Staff user - job view permissions
            (self.app_staff_user, {
                DETAILS_BUTTON_ID: "can_view_job",
            }),
            # Admin user - full job permissions
            (self.app_admin_user, {
                CREATE_BUTTON_ID: "can_create_job",
                DETAILS_BUTTON_ID: "can_view_job",
                EDIT_BUTTON_ID: "can_edit_job",
                DELETE_BUTTON_ID: "can_delete_job"
            }),
        ]
        
        # Test button visibility for each user role
        for user, expected_buttons in permission_test_cases:
            with self.subTest(user=user.email):
                self._test_user_button_permissions(user, expected_buttons)
        
    def _test_user_button_permissions(self, user, expected_buttons):
        """
        Helper method to test button permissions for a specific user on jobs.
        
        Args:
            user: User instance to test
            expected_buttons: Dict of button IDs and required job permissions
        """
        self.client.force_login(user)
        response = self.client.get(self.url)
        
        # Verify user has required view permission for jobs
        if user.has_perm(self.permission_):
            self.assertEqual(response.status_code, 200)
            # Validate button visibility based on permissions
            self.check_user_button_permission(expected_buttons, response)
        else:
            # User should be denied access (403 Forbidden)
            self.assertEqual(response.status_code, 403)
        
    # ================================
    # Search and Filtering Tests
    # ================================
    
    def test_page_filter_search(self):
        """
        Test search functionality in the ETL task table.
        Validates:
        - Search by task ID (numeric search)
        - Empty search query handling
        - Non-existent task search
        - Proper response status and context data
        - Template rendering with search results
        """
        print_prologue()
        
        # Create test tasks with known IDs for search testing
        test_instances = self._create_test_invitations(count=2)
        
        # Login as admin user for full access
        self._login_as_admin()
        
        # Test Case 1: Search by task ID
        self._test_search_by_id(test_instances[0][1])
        
        # Test Case 2: Empty search query
        self._test_empty_search()
        
        # Test Case 3: Non-existent task search
        self._test_nonexistent_search()
        
        print("\n")

    def _test_search_by_id(self,test_instance):
        """Test search functionality with numeric task ID."""
        response = self.client.get(f"{self.url}?search={test_instance.id}")
        self.assertEqual(response.status_code, 200)
        
        # Verify search results contain exactly one task
        page_obj = response.context.get('page_obj', [])
        self.assertEqual(len(page_obj), 1, "Search by ID should return exactly one result")
        self.assertNotEqual(len(page_obj), 2, "Search should filter results correctly")
        
    def _test_empty_search(self):
        """Test behavior with empty search query."""
        response = self.client.get(self.url, {'search': ''})
        self.assertEqual(response.status_code, 200, "Empty search should return 200 status")
        
    def _test_nonexistent_search(self):
        """Test search with non-existent task identifier."""
        response = self.client.get(self.url, {'search': 'nonexistent_task'})
        self.assertEqual(response.status_code, 200)
        
        # Verify empty state message is displayed
        self.assertContains(
            response, 
            'No ETL tasks found...', 
            msg_prefix="Should display 'no tasks found' message"
        )
        
    # ================================
    # Pagination Testing Methods
    # ================================
    
    def test_pagination(self):
        """
        Test pagination functionality for task table.
        
        Validates:
        - Correct page navigation and numbering
        - Per-page item limits
        - Behavior when requesting pages beyond available range
        - Page context and template rendering
        """
        print_prologue()
        
        # Create sufficient test data for pagination testing (25 tasks)
        self._create_test_jobs(count=25)
        
        # Login as admin for full access
        self._login_as_admin()
        
        # Test Case 1: Navigate to specific page with per_page limit
        self._test_specific_page_navigation()
        
        # Test Case 2: Request page beyond available range
        self._test_page_beyond_range()
        
        # Test Case 3: Different per_page values
        self._test_different_page_size_values()

    def _test_specific_page_navigation(self):
        """Test navigation to specific page with pagination controls."""
        response = self.client.get(self.url, {'page': 2, 'page_size': 10})
        self.assertEqual(response.status_code, 200)
        
        # Verify correct page is displayed
        self.assertContains(
            response, 
            "Page 2 of 3", 
            msg_prefix="Should display correct page information"
        )
        
    def _test_page_beyond_range(self):
        """Test behavior when requesting page beyond available range."""
        response = self.client.get(self.url, {'page': 10, 'page_size': 10})
        self.assertEqual(response.status_code, 200)
        
        # Should default to last available page
        self.assertContains(
            response, 
            "Page 3 of 3", 
            msg_prefix="Should default to last page when requesting beyond range"
        )
        
    def _test_different_page_size_values(self):
        """Test pagination with different items per page settings."""
        response = self.client.get(self.url, {'page': 1, 'page_size': 15})
        self.assertEqual(response.status_code, 200)
        
        # Verify pagination adjusts to different page_size values
        self.assertContains(
            response, 
            "Page 1 of 2", 
            msg_prefix="Should adjust pagination based on page_size value"
        )
        
    # ================================
    # Helper Methods
    # ================================
    
    def _create_test_invitations(self, count=2):
        """
        Create test ETL tasks for testing purposes.
        
        Args:
            count (int): Number of tasks to create
            
        Returns:
            list: Created task instances
        """
        instances = []
        for i in range(count):
            instance = create_test_invitations  (
                process=ProcessType.DEFAULT,
                user=self.app_admin_user
            )
            instances.append(instance)
        return instances
        
    def _login_as_admin(self):
        """Login as admin user for testing privileged operations."""
        self.client.login(
            email=f"{TESTING_ACCOUNT_APP_ADMIN}@{TESTING_ACCOUNT_APP_ADMIN}.pt", 
            password=TESTING_ACCOUNT_APP_ADMIN_PASSWORD
        )

    # ================================
    # Additional Test Methods
    # ================================
    
    def test_template_context_data(self):
        """
        Test that the view provides correct context data to the template.
        
        Validates:
        - Required context variables are present
        - Filter form is properly initialized
        - Permission flags are correctly set
        """
        self._create_test_jobs(count=3)
        self._login_as_admin()
        
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        
        # Verify required context variables
        context_keys = ['page_obj', 'filter', 'template_title', 'parent', 'segment']
        for key in context_keys:
            with self.subTest(context_key=key):
                self.assertIn(key, response.context, f"Context should contain '{key}'")
                
    def test_filter_functionality(self):
        """
        Test filtering functionality with various filter criteria.
        
        Validates:
        - Correct application of filters to task queryset
        - Response status and template rendering
        - Edge cases with no matching tasks
        """
        print_prologue()
        
        # Create test tasks with known attributes for filtering
        test_instances = self._create_test_jobs(count=5)
        self._login_as_admin()
        
        # Test Case 1: Filter by existing task attribute
        self._test_filter_by_existing_attribute(test_instances[0][0])
        
        # Test Case 2: Filter with no matching results
        self._test_filter_no_results()
        
    def _test_filter_by_existing_attribute(self, test_instance):
        """Test filtering by a specific task attribute (e.g., id)."""
        response = self.client.get(self.url, {'search': f'{test_instance.id}'})
        self.assertEqual(response.status_code, 200)
        
        # Verify that the filter is applied correctly
        page_obj = response.context.get('page_obj', [])
        self.assertEqual(len(page_obj), 1, "Filter by name should return the correct task")
        
    def _test_filter_no_results(self):
        """Test filter functionality with criteria that match no tasks."""
        response = self.client.get(self.url, {'search': 'Nonexistent Task'})
        self.assertEqual(response.status_code, 200)
        
        # Verify that no tasks are returned and appropriate message is shown
        page_obj = response.context.get('page_obj', [])
        self.assertEqual(len(page_obj), 0, "Filter with no matches should return empty results")
        self.assertContains(response, 'No Jobs found...', msg_prefix="Should display 'no tasks found' message")

class InvitationDetailViewTest(InviTationTestCase):
    def setUp(self):
        super().setUp()
        self.url = reverse('invite_detail', kwargs={
                           'id': self.test_invitation.id})
        self.template_name = 'user_app/invitation/detail.html'

class InvitationEditViewTest(InviTationTestCase):
    def setUp(self):
        super().setUp()
        self.url = reverse('invite_edit', kwargs={
                           'id': self.test_invitation.id})
        self.template_name = 'user_app/invitation/edit.html'

class InvitationCreateViewTest(InviTationTestCase):
    def setUp(self):
        super().setUp()
        self.url = reverse('user_invite')
        self.template_name = 'user_app/invitation/create.html'

class InvitationSuccessViewTest(InviTationTestCase):
    def setUp(self):
        super().setUp()
        self.url = reverse('invite_success')
        self.template_name = 'common/logged/success_page.html'

###
#
#       User Register Views
#
##


class UserRegisterViewTest(InviTationTestCase):
    """
    Test suite for the user registration view accessed via invitation.

    This class contains tests to ensure that:
    - The registration page for invited users renders correctly.
    - Unauthenticated users are handled appropriately.
    - The correct template is used for rendering the registration page.

    Inheritance:
        InvidationTestCase: Provides setup and utility methods for invitation-based tests.
    """

    def setUp(self):
        """
        Set up the test environment for user registration via invitation.

        Initializes the URL and template name for the registration view using the test invitation token.
        """
        super().setUp()
        self.url = reverse('user_register', kwargs={
                           'token': self.test_invitation.token})
        self.template_name = 'user_app/auth/register_invite.html'

    
    def test_page_renders_correctly_not_authed(self):
        """
        Test that the registration page for invited users renders correctly for unauthenticated users.

        Asserts that the response status code is 200 and the setup is valid.
        """
        self.assertValidSetup()
        
        print_prologue()
        
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        
        print("\n")

class UserRegisterSuccessViewTest(_BaseViewTestCase):
    def setUp(self):
        super().setUp()
        self.url = reverse('user_register_success')
        self.template_name = 'common/unlogged/success_page.html'

    def test_page_renders_correctly_not_authed(self):
        """
        Test that the registration page for invited users renders correctly for unauthenticated users.

        Asserts that the response status code is 200 and the setup is valid.
        """
        self.assertValidSetup()
        
        print_prologue()
        
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        
        print("\n")
        
###
#
#       Password Reset Views
#
##

class PasswordResetDoneViewTest(InviTationTestCase):
    
    def setUp(self):
        super().setUp()
        self.url = reverse('password_reset_done')
        self.template_name = 'common/unlogged/success_page.html'

    def test_page_renders_correctly_not_authed(self):
        """Test that the company create page redirects unauthenticated users."""
        self.assertValidSetup()
        
        print_prologue()
        
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        
        print("\n")
    
class PasswordResetCompleteViewTest(InviTationTestCase):
    
    def setUp(self):
        super().setUp()
        self.url = reverse('password_reset_complete')
        self.template_name = 'common/unlogged/success_page.html'

    def test_page_renders_correctly_not_authed(self):
        """Test that the company create page redirects unauthenticated users."""
        self.assertValidSetup()
        
        print_prologue()
        
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        
        print("\n")
        