"""Enhanced user models with comprehensive logging, validation, and type safety.

This module provides user management models with enhanced security features,
comprehensive validation, and optimized database operations.
"""

# Django imports
from django.db import models, transaction
from django.contrib.auth.models import (
    BaseUserManager,
    AbstractBaseUser,
    PermissionsMixin,
    Permission,
    Group,
)
from django.utils import timezone
from django.utils.translation import gettext_lazy
from django.conf import settings
from django.urls import reverse
from django.template.loader import render_to_string
from django.core.mail import send_mail
from django.core.exceptions import ValidationError
from django.core.cache import cache
from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver

# Third-party imports
from multiselectfield import MultiSelectField
import random

# Local imports
from apps.common.models import BaseModel, ProcessType
from apps.common.constants import INVITATION_EMAIL_SUBJECT
from apps.common.mixins import LoggingMixin, ValidationMixin, CacheInvalidationMixin

# Standard library imports
import uuid
from typing import Optional, Dict, Any, List
import re

##
#   Logging and Performance
#

import logging
logger = logging.getLogger(__name__)

def random_avatar_image():
    return f"/img/avatars/avatar{random.randint(1, 10)}.png"

##
#   User
#

class UserManager(BaseUserManager):
    """
    Enhanced custom manager for user creation with comprehensive validation and logging.
    
    This manager provides optimized methods for creating regular users and superusers,
    with automatic group assignment, validation, and audit trails.
    
    Features:
    - Email normalization and validation
    - Password strength validation
    - Comprehensive logging for security auditing
    - Transaction safety for user creation
    - Duplicate detection and prevention
    """

    def create_user(self, email: str, password: Optional[str] = None, **extra_fields) -> 'User':
        """
        Creates and returns a new user with comprehensive validation and logging.

        Args:
            email: The user's email address, used as unique identifier
            password: The user's password (optional for social auth)
            **extra_fields: Additional fields to set on the user model

        Returns:
            User: The created user instance

        Raises:
            ValueError: If email is not provided or invalid
            ValidationError: If user data fails validation
        """
        try:
            # Comprehensive email validation
            if not email:
                logger.error("User creation failed: Email field is required")
                raise ValueError("The Email field must be set")
            
            # Normalize and validate email format
            email = self.normalize_email(email)
            if not self._validate_email_format(email):
                logger.error(f"User creation failed: Invalid email format: {email}")
                raise ValueError("Invalid email format")
            
            # Check for duplicate email
            if self.filter(email=email).exists():
                logger.warning(f"User creation failed: Email already exists: {email}")
                raise ValueError(f"User with email {email} already exists")
            
            # Create user with transaction safety
            with transaction.atomic():
                user = self.model(email=email, **extra_fields)
                
                # Set password with validation if provided
                if password:
                    user.set_password(password)
                    
                # Validate user data before saving
                user.full_clean()
                user.save(using=self._db)
                
                logger.info(f"Successfully created user: {email} (ID: {user.id})")
                return user
                
        except ValidationError as e:
            logger.error(f"User validation failed for {email}: {e}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error creating user {email}: {e}")
            raise ValueError(f"Failed to create user: {str(e)}")

    def create_superuser(self, email, password=None, **extra_fields):
        """
        Creates and returns a new superuser with the given email and password,
        setting is_staff and is_superuser to True. If these values are not True,
        a ValueError is raised.

        Args:
            email (str): The superuser's email address, used as a unique identifier.
            password (str): The superuser's password.
            **extra_fields: Additional fields to set on the user model.

        Returns:
            User: The created superuser instance.

        Raises:
            ValueError: If is_staff or is_superuser are not True.
        """
        
        extra_fields.setdefault("name", "Superuser")
        extra_fields.setdefault("title", "Administrator")
        extra_fields.setdefault("birth_date", timezone.now().date())
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        extra_fields.setdefault("type", User.UserType.APP_ADMIN)
        extra_fields.setdefault("image", random_avatar_image())

        return self.create_user(email, password, **extra_fields)
    
    def _validate_email_format(self, email: str) -> bool:
        """
        Validate email format using regex pattern.
        
        Args:
            email: Email address to validate
            
        Returns:
            bool: True if email format is valid
        """
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return bool(re.match(pattern, email))

class User(AbstractBaseUser, PermissionsMixin, LoggingMixin, ValidationMixin, CacheInvalidationMixin):
    """
    Enhanced User model with comprehensive features and validation.
    
    This model extends the base user functionality with:
    - Enhanced security features
    - Comprehensive validation
    - Audit trails and logging
    - Cache management
    - Performance optimizations
    
    Attributes:
        name: User's full name
        title: User's title or role
        email: Unique email address (used as username)
        image: Profile image path
        type: User type classification
        sex: Gender information (optional)
        birth_date: Date of birth for age calculations
        security_group: Groups for permission management
        
    Properties:
        age: Calculated age based on birth_date
        is_adult: Boolean indicating if user is 18 or older
        cache_keys: List of cache keys related to this user
    """

    # Core user information
    name = models.CharField(
        max_length=40, 
        null=False,
        help_text="User's full name (required)"
    )
    title = models.CharField(
        max_length=20, 
        null=True, 
        blank=True,
        help_text="User's title or role (optional)"
    )
    image = models.CharField(
        max_length=255, 
        default=random_avatar_image, 
        blank=True,
        help_text="Profile image path"
    )
    email = models.EmailField(
        verbose_name="email address", 
        max_length=255, 
        unique=True,
        help_text="Unique email address used for authentication"
    )
    
    # Date tracking with proper indexing
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True, db_index=True)
    
    # Personal information
    birth_date = models.DateField(
        null=True, 
        blank=True,
        help_text="Date of birth for age calculations"
    )

    
    # Security and permissions with enhanced validation
    is_active = models.BooleanField(
        default=True,
        help_text="Designates whether this user should be treated as active"
    )
    is_staff = models.BooleanField(
        default=False,
        help_text="Designates whether the user can log into the admin site"
    )
    is_superuser = models.BooleanField(
        default=False,
        help_text="Designates whether this user has all permissions"
    )
    security_group = models.ManyToManyField(
        Group, 
        related_name="users", 
        blank=True,
        help_text="Groups for permission management"
    )
    user_permissions = models.ManyToManyField(
        Permission, 
        related_name="user_set", 
        blank=True,
        help_text="Specific permissions for this user"
    )
    
    # Enhanced manager
    objects = UserManager()
    

    class UserType(models.TextChoices):
        PLACEHOLDER = "Placeholder", "Placeholder"
        NORMAL = "Normal", "Normal"
        APP_STAFF = "Application Staff", "Application Staff"
        APP_ADMIN = "Application Admin", "Application Admin"

    type = models.CharField(
        choices=UserType.choices, default=UserType.NORMAL, null=False
    )
    
    class SexType(models.TextChoices):
        MALE = 'M', 'Male'
        FEMALE = 'F', 'Female'
        DONT_SAY = 'D', 'Not Important'

    sex = models.CharField(
        max_length=1,
        choices=SexType.choices,
        default=None,
        null=True,
        blank=True
    )
   

    class Meta:
        permissions = [
            ("can_view_user", "Can view User's details"),
            ("can_view_users", "Can view Users list"),
            ("can_invite_user", "Can invite a User"),
            ("can_edit_user", "Can edit a User"),
            ("can_delete_user", "Can delete a User"),
            ("can_enable_user", "Can Enable a User"),
            ("can_disable_user", "Can Disable a User"),
        ]

    USERNAME_FIELD = "email"

    @property
    def age(self) -> Optional[int]:
        """
        Calculate user's age based on birth_date.
        
        Returns:
            int or None: Age in years, None if birth_date not set
        """
        if not self.birth_date:
            return None
            
        try:
            today = timezone.now().date()
            age = today.year - self.birth_date.year
            
            # Adjust for birthday not yet occurred this year
            if (today.month, today.day) < (self.birth_date.month, self.birth_date.day):
                age -= 1
                
            return max(0, age)  # Ensure non-negative age
            
        except (AttributeError, TypeError) as e:
            logger.error(f"Error calculating age for user {self.id}: {e}")
            return None
    
    @property
    def is_adult(self) -> bool:
        """
        Check if user is 18 years or older.
        
        Returns:
            bool: True if user is adult (18+), False otherwise
        """
        age = self.age
        return age is not None and age >= 18
    
    @property
    def cache_keys(self) -> List[str]:
        """
        Generate list of cache keys related to this user.
        
        Returns:
            List of cache key strings
        """
        return [
            f"user_profile_{self.id}",
            f"user_permissions_{self.id}",
            f"user_stats_{self.id}",
            f"user_tasks_{self.id}",
        ]
    
    def clean(self):
        """
        Comprehensive model validation with enhanced checks.
        
        Raises:
            ValidationError: If validation fails
        """
        errors = {}
        
        # Validate birth date is not in the future
        if self.birth_date and self.birth_date > timezone.now().date():
            errors['birth_date'] = "Birth date cannot be in the future"
        
        # Validate name contains no numbers
        if self.name and any(char.isdigit() for char in self.name):
            errors['name'] = "Name should not contain numbers"
        
        # Validate email domain if provided
        if self.email and '@' in self.email:
            domain = self.email.split('@')[1].lower()
            # Add domain validation logic if needed
            
        if errors:
            logger.warning(f"User validation errors for {self.email}: {errors}")
            raise ValidationError(errors)
            
        super().clean()
    
    def save(self, *args, **kwargs):
        """
        Enhanced save method with validation and cache invalidation.
        
        Args:
            *args: Positional arguments
            **kwargs: Keyword arguments
        """
        # Run full validation
        self.full_clean()
        
        # Log user creation/update
        is_new = self._state.adding
        action = "Created" if is_new else "Updated"
        
        super().save(*args, **kwargs)
        
        # Invalidate related caches
        self.invalidate_cache()
        
        logger.info(f"{action} user: {self.email} (ID: {self.id})")

    def __str__(self) -> str:
        """
        String representation of the user.
        
        Returns:
            str: Formatted user identifier
        """
        return f"{self.id} - {self.name} ({self.email})"
    
    def __repr__(self) -> str:
        """
        Developer-friendly representation.
        
        Returns:
            str: Detailed user representation
        """
        return f"<User(id={self.id}, email='{self.email}', name='{self.name}', active={self.is_active})>"
    
    def get_absolute_url(self) -> str:
        """
        Get the absolute URL for this user.
        
        Returns:
            str: URL to user detail view
        """
        return reverse('user_detail', kwargs={'pk': self.pk})
    
    def get_full_name(self) -> str:
        """
        Get user's full name with title if available.
        
        Returns:
            str: Full name with optional title
        """
        if self.title:
            return f"{self.title} {self.name}"
        return self.name
    
    def has_valid_profile(self) -> bool:
        """
        Check if user has a complete profile.
        
        Returns:
            bool: True if profile is considered complete
        """
        required_fields = [self.name, self.email]
        return all(field for field in required_fields)
    
    def invalidate_cache(self):
        """
        Invalidate all user-related cache entries.
        """
        cache.delete_many(self.cache_keys)
        logger.debug(f"Invalidated cache for user {self.id}")

# Signal handlers for cache invalidation
@receiver(post_save, sender=User)
def invalidate_user_cache_on_save(sender, instance, created, **kwargs):
    """
    Invalidate user cache when user is saved.
    
    Args:
        sender: The model class
        instance: The actual instance being saved
        created: Boolean indicating if this is a new record
        **kwargs: Additional keyword arguments
    """
    instance.invalidate_cache()
    
    # Additional cache invalidation for user lists
    cache.delete_many([
        'active_users_count',
        'total_users_count',
        'recent_users',
        'user_type_stats',
    ])
    
    action = "created" if created else "updated"
    logger.debug(f"User {action}, cache invalidated: {instance.email}")

@receiver(post_delete, sender=User)
def invalidate_user_cache_on_delete(sender, instance, **kwargs):
    """
    Invalidate user cache when user is deleted.
    
    Args:
        sender: The model class
        instance: The instance being deleted
        **kwargs: Additional keyword arguments
    """
    instance.invalidate_cache()
    
    # Additional cache invalidation for user lists
    cache.delete_many([
        'active_users_count',
        'total_users_count',
        'recent_users',
        'user_type_stats',
    ])
    
    logger.info(f"User deleted, cache invalidated: {instance.email}")   
        
##
#   Auth
#
        
class Invitation(BaseModel, LoggingMixin, CacheInvalidationMixin):
    """
    Enhanced Invitation model with comprehensive validation and logging.

    This model represents invitations sent to users via email with:
    - Unique token generation for security
    - Comprehensive validation
    - Audit trails and logging
    - Cache management
    - Email delivery tracking

    Attributes:
        invited: Email address of the invitee
        token: Unique UUID token for the invitation
        inviter: User who sent the invitation
        group: Group the invitee will be added to
        sent_at: Timestamp when invitation was sent
        
    Methods:
        send_invitation_email: Send the invitation email with error handling
        is_expired: Check if invitation has expired
        invalidate_cache: Clear related cache entries
    """
    
    invited = models.EmailField()
    token = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    inviter = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name="invitations"
    )
    group = models.ForeignKey(
        Group, on_delete=models.CASCADE, related_name="invitations"
    )
    sent_at = models.DateTimeField(auto_now_add=True)
    created_at = models.DateTimeField(auto_now_add=True)
    

    def __str__(self):
        return f"Invite to {self.invited}"

    
    class Meta:
        permissions = [
            ("can_view_invites", "Can view Invites list"),
            ("can_create_invite", "Can create a Invite"),
            ("can_resend_invite", "Can resend a Invite"),
            ("can_delete_invite", "Can delete a Invite"),
        ]
    
    def send_invitation_email(self, invitation: 'Invitation') -> Dict[str, Any]:
        """
        Send invitation email with comprehensive error handling and logging.
        
        Args:
            invitation: The invitation instance to process
            
        Returns:
            Dict containing success status and details
        """
        from apps.common.utils import PerformanceMonitor
        
        result = {
            'success': False,
            'sent_count': 0,
            'error_message': None,
            'sent_at': None
        }
        
        try:
            with PerformanceMonitor("invitation_email_send"):
                # Generate secure invitation link
                invite_link = f'{settings.BASE_URL}{reverse("user_register", args=[invitation.token])}'
                
                # Prepare email context with validation
                context = {
                    'invite_link': invite_link,
                    'sender_email': invitation.inviter.email,
                    'sender_name': invitation.inviter.name,
                    'invited_email': invitation.invited,
                    'group_name': getattr(invitation.group, 'name', 'Unknown Group'),
                    'expiry_days': getattr(settings, 'INVITATION_EXPIRY_DAYS', 7),
                }
                
                # Validate template exists and render
                try:
                    message = render_to_string('user_app/auth/emails/invite_email.html', context)
                    if not message.strip():
                        raise ValueError("Rendered email template is empty")
                except Exception as template_error:
                    logger.error(f"Template rendering failed for invitation to {invitation.invited}: {template_error}")
                    result['error_message'] = f"Template error: {str(template_error)}"
                    return result
                
                # Validate email configuration
                if not getattr(settings, 'DEFAULT_FROM_EMAIL', None):
                    logger.error("DEFAULT_FROM_EMAIL not configured for invitation emails")
                    result['error_message'] = "Email configuration missing"
                    return result
                
                # Send the email with comprehensive error handling
                sent_count = send_mail(
                    INVITATION_EMAIL_SUBJECT,
                    message,
                    settings.DEFAULT_FROM_EMAIL,
                    [invitation.invited],
                    fail_silently=False,
                    html_message=message,  # Support HTML emails
                )
                
                result['sent_count'] = sent_count
                result['sent_at'] = timezone.now()
                
                if sent_count > 0:
                    result['success'] = True
                    # Update invitation record
                    invitation.sent_at = result['sent_at']
                    invitation.save(update_fields=['sent_at'])
                    
                    logger.info(
                        f"Invitation email sent successfully to {invitation.invited} "
                        f"from {invitation.inviter.email} (Token: {invitation.token})"
                    )
                else:
                    result['error_message'] = "Email sent but no recipients confirmed"
                    logger.warning(f"Invitation email delivery uncertain for {invitation.invited}")
                    
        except Exception as e:
            error_msg = f"Failed to send invitation email to {invitation.invited}: {str(e)}"
            result['error_message'] = error_msg
            logger.error(error_msg, exc_info=True)
            
            # Log additional context for debugging
            logger.debug(
                f"Invitation email failure context: "
                f"Token={invitation.token}, "
                f"Inviter={invitation.inviter.email}, "
                f"Group={getattr(invitation.group, 'name', 'None')}"
            )
        
        return result
    
    def is_expired(self, expiry_days: int = None) -> bool:
        """
        Check if invitation has expired.
        
        Args:
            expiry_days: Days until expiration (defaults to settings value)
            
        Returns:
            bool: True if invitation has expired
        """
        if expiry_days is None:
            expiry_days = getattr(settings, 'INVITATION_EXPIRY_DAYS', 7)
            
        expiry_date = self.created_at + timezone.timedelta(days=expiry_days)
        return timezone.now() > expiry_date
    
    def invalidate_cache(self):
        """
        Invalidate invitation-related cache entries.
        """
        cache_keys = [
            f"invitation_{self.token}",
            f"user_invitations_{self.inviter.id}",
            "pending_invitations_count",
            "recent_invitations",
        ]
        cache.delete_many(cache_keys)
        logger.debug(f"Invalidated invitation cache for token {self.token}")

##
#   Group
#

class Group(BaseModel):
    """
    Model to store shopping lists.
    """
    
    name = models.CharField(max_length=255, null=False)
    users = models.ManyToManyField(User, related_name='app_groups')
    admins = models.ManyToManyField(User, related_name='admined_groups')
    owner = models.ForeignKey(User, related_name='owned_groups', on_delete=models.CASCADE)
    img_source = models.CharField(max_length=255, null=True)\
    
class GroupInvite(BaseModel):
    """
    Model to store shopping lists.
    """
    
    title = models.CharField(max_length=255, null=False)
    description = models.CharField(max_length=255, null=False)
    inviter = models.ForeignKey(Group, related_name='invites', on_delete=models.CASCADE)
    invited = models.ForeignKey(User, related_name='invites', on_delete=models.CASCADE)
    
    class Meta:
        unique_together = ('inviter', 'invited')

    @classmethod
    def create_invite(cls, group_inviter_id, invited_user_id, title, description):
        try:
            inviter = Group.objects.get(id=group_inviter_id)
            invited_user = User.objects.get(id=invited_user_id)
            
            # Check if an invite already exists
            if cls.objects.filter(inviter=inviter, invited=invited_user).exists():
                raise ValidationError("User already invited.")
            
            invite = cls(
                inviter=inviter,
                invited=invited_user,
                title=title,
                description=description
            )
            invite.save()
            return invite
        except Group.DoesNotExist:
            raise ValidationError("Inviter group does not exist.")
        except User.DoesNotExist:
            raise ValidationError("Invited user does not exist.")