###
#       General imports
##
import math


##
#   Django
#

from django.shortcuts import render, redirect, get_object_or_404
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_GET, require_POST
from django.urls import reverse
from django.core.paginator import Paginator
from django.views.generic import TemplateView
from django.contrib.auth.mixins import PermissionRequiredMixin
from django.core.exceptions import PermissionDenied
from django.utils.safestring import mark_safe
from django.http import JsonResponse
from django.http import HttpResponse
from django.contrib import messages
from django.http import JsonResponse, FileResponse

from django.views.generic import ListView
from django.core.paginator import Paginator
import mimetypes

##
#   Api Swagger
#


##
#   Extras
#

import re
from os import path
from math import floor

###
#       App specific imports
##


##
#   Models
#

from apps.task_app.models import Job, Task, TaskFile, Event

##
#   Serializers
#


##
#   Forms
#

from apps.task_app.forms import  TaskForm, JobForm, TimeConditionForm, ThresholdConditionForm,\
    TaskFileUploadForm, TaskFileFilterForm, TaskFileUploadForm


##
#   Filters
#

from apps.task_app.filters import JobFilter, TaskFilter, EventFilter

##
#   Functions
#

from apps.task_app.tasks import _launch_job
from apps.task_app.functions import tail_colored_log, count_lines


##
#   Contants
#

from apps.common.constants import WEBSOCKET_URL


###
#
#   Jobs
#
##


@method_decorator(login_required, name="dispatch")
class JobTableView(PermissionRequiredMixin, TemplateView):
    """
    A view class that displays a paginated table of jobs with filtering capabilities.
    This view requires user authentication and specific permission to view jobs.
    It extends TemplateView and implements PermissionRequiredMixin for access control.

    Attributes:
        template_name (str): Path to the template used to render the job table.
        page_size (int): Default number of items per page.
        permission_required (str): Permission required to access this view.

    Methods:
        get_context_data(**kwargs): Prepares and returns the context data for template rendering.
            - Initializes template layout.
            - Retrieves and orders all jobs.
            - Applies filtering based on request parameters.
            - Implements pagination.
            - Adds create job permission check.
    """

    template_title = "Jobs Table"
    template_name = "cerebrus/task_app/jobs/table.html"
    
    parent = "jobs"
    segment = "jobs_table"
    
    permission_required = "task_app.can_view_jobs"
    page_size = 10

    def get_context_data(self, **kwargs):
        """
        Prepares and returns the context data for template rendering.
        - Initializes template layout.
        - Retrieves and orders all jobs.
        - Applies filtering based on request parameters.
        - Implements pagination.
        - Adds create job permission check.

        Returns:
            dict: Context containing:
                - filter: Filtered queryset of jobs.
                - page_obj: Paginator object with job records.
                - can_create_job: Boolean indicating if user can create jobs.
                - can_edit_job: Boolean indicating if user can edit jobs.
                - can_view_job: Boolean indicating if user can view jobs.
                - can_delete_job: Boolean indicating if user can delete jobs.
        """
        # Initialize template layout
        context = super().get_context_data(**kwargs)

        # Retrieve and order all Instances
        records = Job.objects.all().order_by("-id")
        
        # Apply filtering based on request parameters
        filter = JobFilter(self.request.GET, queryset=records)
        filtered_records = filter.qs
        
        # Implement pagination
        paginator = Paginator(
            filtered_records, 
            self.request.GET.get("page_size", self.page_size)
        )
        page_obj = paginator.get_page(self.request.GET.get("page"))

        # Created context
        context.update(
            {
                "template_title": self.template_title,
                "parent": self.parent,
                "segment": self.segment,
                "filter": filter,
                "total_count": paginator.count,
                "page_obj": page_obj,
                "can_create_job": self.request.user.has_perm(
                    "task_app.can_create_job"
                ),
                "can_edit_job": self.request.user.has_perm(
                    "task_app.can_edit_job"
                ),
                "can_view_job": self.request.user.has_perm(
                    "task_app.can_view_job"
                ),
                "can_enable_job": self.request.user.has_perm(
                    "task_app.can_enable_job"
                ),
                "can_disable_job": self.request.user.has_perm(
                    "task_app.can_disable_job"
                ),
                "can_delete_job": self.request.user.has_perm(
                    "task_app.can_delete_job"
                ),
            }
        )
        
        return context


@method_decorator(login_required, name='dispatch')
class JobDetailView(PermissionRequiredMixin, TemplateView):
    """
    A view class for displaying job details.

    This class handles the display of job-specific information and associated log files.
    Requires user authentication to access the view.

    Attributes:
        template_name (str): The template used for rendering the job detail view.
        page_size (int): Number of items to display per page.
        permission_required (str): The required permission to access this view.

    Methods:
        get_context_data(**kwargs): Prepares and returns the context data for template rendering.

    Parameters:
        kwargs["id"] (int): The ID of the job to be displayed.

    Returns:
        dict: Context dictionary containing:
            - record: Job object retrieved from database.
            - log: Content of the job's log file (if exists).
            - WEBSOCKET_URL: WebSocket host configuration.
            - Additional template layout context data.
    """
    
    template_title = "Job Detail"
    template_name = "cerebrus/task_app/jobs/detail.html"
    
    parent = "jobs"
    segment = "jobs_detail"
    
    permission_required = "task_app.can_view_job"
    page_size = 10

    def get_context_data(self, **kwargs):
        """
        Prepares and returns the context data for template rendering.
        - Initializes template layout.
        - Retrieves the job by ID.
        - Reads the job's log file if it exists.
        - Adds WebSocket host configuration.

        Returns:
            dict: Context dictionary containing:
                - record: Job object retrieved from database.
                - log: Content of the job's log file (if exists).
                - WEBSOCKET_URL: WebSocket host configuration.
        """
        # Initialize template layout
        context = super().get_context_data(**kwargs)
        
        # Retrieve Instances
        instance = Job.objects.get(id=kwargs["id"])

        # Retrieve the Job's Tasks
        tasks_records = instance.tasks.all().order_by("-started_at")
        trigger_history_records = instance.trigger_history.all().order_by("-created_at")
        
        # Apply filtering based on request parameters
        tasks_filter = TaskFilter(self.request.GET, queryset=tasks_records)
        tasks_filtered_records = tasks_filter.qs
        
        trigger_history_filter = TaskFilter(self.request.GET, queryset=trigger_history_records)
        trigger_history_filtered_records = trigger_history_filter.qs
        
        # Implement Pagination
        paginator = Paginator(
            tasks_filtered_records, 
            self.request.GET.get("page_size", self.page_size)
        )
        tasks_page_obj = paginator.get_page(self.request.GET.get("page"))
        
        
        trigger_history_paginator = Paginator(
            trigger_history_filtered_records, 
            self.request.GET.get("page_size", self.page_size)
        )
        trigger_history_page_obj = trigger_history_paginator.get_page(self.request.GET.get("page"))
        
        # Read the job's log file if it exists
        log_path = instance.log_path
        if log_path and path.isfile(log_path):
            with open(log_path, "r") as log_file:
                log_content = log_file.read()
                
                # Add color coding
                # Add color coding only to the log level, not the date or the rest of the message
                log_content = re.sub(r'(\[(INFO)\])', r'<span style="color: #4A90E2; font-weight: bold;">\1</span>', log_content)
                log_content = re.sub(r'(\[(WARNING)\])', r'<span style="color: #FDD835; font-weight: bold;">\1</span>', log_content)
                log_content = re.sub(r'(\[(ERROR)\])', r'<span style="color: #E57373; font-weight: bold;">\1</span>', log_content)

                context["log"] = mark_safe(log_content)     
        
                
        # Create context
        context.update(
            {   
                "template_title": self.template_title,
                "parent": self.parent,
                "segment": self.segment,
                "instance": instance,
                "WEBSOCKET_URL": WEBSOCKET_URL,
                "task_filter": tasks_filter,
                "tasks_page_obj": tasks_page_obj,
                "can_force_start_job": self.request.user.has_perm(
                    "task_app.can_force_start_job"
                ),
                "can_enable_job": self.request.user.has_perm(
                    "task_app.can_enable_job"
                ),
                "can_disable_job": self.request.user.has_perm(
                    "task_app.can_disable_job"
                ),
                "can_edit_job": self.request.user.has_perm(
                    "task_app.can_edit_job"
                ),
                "can_delete_job": self.request.user.has_perm(
                    "task_app.can_delete_job"
                ),
                "trigger_history_page_obj": trigger_history_page_obj,
                "trigger_history_filter": trigger_history_filter,
                "can_edit_task": self.request.user.has_perm(
                    "task_app.can_edit_task"
                ),
                "can_view_task": self.request.user.has_perm(
                    "task_app.can_view_task"
                ),
                "can_delete_task": self.request.user.has_perm(
                    "task_app.can_delete_task"
                ),
            }
        )

        return context


@method_decorator(login_required, name='dispatch')
class JobCreateView(PermissionRequiredMixin, TemplateView):
    """
    Class-based view for creating a new job.

    This view requires users to be authenticated and have the '.can_create_job' permission.
    It renders a form for job creation and handles both GET and POST requests.

    Attributes:
        template_name (str): Path to the template used for rendering the job creation form.
        permission_required (str): Permission required to access this view.

    Methods:
        get_context_data(**kwargs): Adds form and layout context to template context.
        post(request, *args, **kwargs): Handles form submission, saves job if valid, 
            and redirects to job detail view.

    Returns:
        GET: Rendered template with job creation form.
        POST: Redirects to job detail view on success, or re-renders form with errors.
    """
    
    template_name = "cerebrus/task_app/jobs/create.html"
    permission_required = "task_app.can_create_job"
    form_class = JobForm
        
    def get_context_data(self, **kwargs):
        """
        Prepares and returns the context data for template rendering.
        - Initializes template layout.
        - Adds job form and time condition forms to context.

        Returns:
            dict: Context dictionary containing:
                - form: JobForm instance.
                - starting_condition_time_form: TimeConditionForm instance for starting condition.
                - stopping_condition_time_form: TimeConditionForm instance for stopping condition.
        """
        # Initialize template layout
        context = super().get_context_data(**kwargs)
        
        # Create context
        context.update({
            "form": self.form_class(),
            "starting_condition_time_form": TimeConditionForm(
                prefix="starting_condition_time_form"
            ),
            "stopping_condition_time_form": TimeConditionForm(
                prefix="stopping_condition_time_form"
            ),
            "stopping_condition_threshold_form": ThresholdConditionForm(
                prefix="stopping_condition_threshold_form"
            ),
        })
        
        return context

    def post(self, request, *args, **kwargs):
        """
        Handles form submission for creating a new job.
        - Validates and saves the job form and time condition forms.
        - Redirects to job detail view on success, or re-renders form with errors.

        Args:
            request (HttpRequest): The HTTP request object.

        Returns:
            HttpResponseRedirect: Redirects to job detail view on success.
            HttpResponse: Re-renders form with errors on failure.
        """

        job_form = self.form_class(request.POST)
        
        starting_time_condition_form = TimeConditionForm(
            request.POST, prefix="starting_condition_time_form"
        )
        stopping_time_condition_form = TimeConditionForm(
            request.POST, prefix="stopping_condition_time_form"
        )
        stopping_condition_threshold_form = ThresholdConditionForm(
            request.POST, prefix="stopping_condition_threshold_form"
        )
        
        
        if job_form.is_valid():
            starting_condition_form = None
            stopping_condition_form = None
            
            # Save the starting condition
            if job_form.instance.starting_condition_type:
                if job_form.instance.starting_condition_type.name == "time condition":
                    
                    starting_time_condition_form = TimeConditionForm(
                        request.POST, prefix="starting_condition_time_form"
                    )
                    if starting_time_condition_form.is_valid():
                        starting_condition_form = starting_time_condition_form
                    else:
                        # Collect all errors if any form is invalid
                        context = self.get_context_data()
                        context.update(
                            {
                                "form": job_form,
                                "starting_condition_time_form": starting_time_condition_form,
                                "stopping_condition_time_form": stopping_time_condition_form,
                            }
                        ) 
                        return self.render_to_response(context)

            # Save the stopping time condition
            if job_form.instance.stopping_condition_type:
                if job_form.instance.stopping_condition_type.name == "time condition":
                    if stopping_time_condition_form.is_valid():
                        stopping_condition_form = stopping_time_condition_form
                    else:
                        # Collect all errors if any form is invalid
                        context = self.get_context_data()
                        context.update(
                            {
                                "form": job_form,
                                "starting_condition_time_form": starting_time_condition_form,
                                "stopping_condition_time_form": stopping_time_condition_form,
                                "stopping_condition_threshold_form": stopping_condition_threshold_form,
                            }
                        ) 
                        return self.render_to_response(context)
                
                if job_form.instance.stopping_condition_type.name == "threshold condition":
                    if stopping_condition_threshold_form.is_valid():
                        stopping_condition_form = stopping_condition_threshold_form
                    else:
                        # Collect all errors if any form is invalid
                        context = self.get_context_data()
                        context.update(
                            {
                                "form": job_form,
                                "starting_condition_time_form": starting_time_condition_form,
                                "stopping_condition_time_form": stopping_time_condition_form,
                                "stopping_condition_threshold_form": stopping_condition_threshold_form,
                            }
                        ) 
                        return self.render_to_response(context)

            job = job_form.save(
                starting_condition_form,
                stopping_condition_form,
                created_by = request.user
            )
            return redirect(reverse("job_detail", args=[job.id]))

        # Create context
        context = self.get_context_data()
        context.update(
            {
                "form": job_form,
                "starting_condition_time_form": starting_time_condition_form,
                "stopping_condition_time_form": stopping_time_condition_form,
                "stopping_condition_threshold_form": stopping_condition_threshold_form,
            }
        )        
        return self.render_to_response(context)


@method_decorator(login_required, name='dispatch')
class JobEditView(PermissionRequiredMixin, TemplateView):
    """
    View for editing a user.

    Inherits from:
        PermissionRequiredMixin: Ensures the user has the required permissions.
        TemplateView: Renders a template.

    Attributes:
        template_name (str): The path to the template used for rendering the view.
        permission_required (str): The permission required to access this view.
        form_class (UserEditForm): The form class used for editing the user.

    Methods:
        get_object(): Retrieves the User object or raises a 404 error.
        get_context_data(**kwargs): Adds the UserEditForm to the context.
        post(request, *args, **kwargs): Handles form submission for editing a user.


        Returns:
            User: The user object retrieved by ID.


        Args:
            **kwargs: Additional context data.

        Returns:
            dict: The context data including the form.


        Args:
            request (HttpRequest): The HTTP request object.
            *args: Additional positional arguments.
            **kwargs: Additional keyword arguments.

        Returns:
            HttpResponse: The HTTP response object.
    """
    template_name = '/jobs/edit.html'
    permission_required = 'auth.change_job'
    form_class = JobForm

    
    def get_context_data(self, **kwargs):
        """
        Prepares and returns the context data for template rendering.
        - Initializes template layout.
        - Adds job form and time condition forms to context.
    
        Returns:
            dict: Context dictionary containing:
                - form: JobForm instance.
                - starting_condition_time_form: TimeConditionForm instance for starting condition.
                - stopping_condition_time_form: TimeConditionForm instance for stopping condition.
        """
        # Initialize template layout
        context = super().get_context_data(**kwargs)
        
        return context

    def get(self, request, *args, **kwargs):
        
        # Obtain the context
        context = self.get_context_data(**kwargs)
        
        # Retrieve Instances
        instance = Job.objects.get(id=kwargs["id"])
        
        # Create context
        context.update({
            "form": self.form_class(instance=instance),
            "starting_condition_time_form": TimeConditionForm(
            prefix="starting_condition_time_form",
            instance=instance.starting_condition if instance.starting_condition_type and instance.starting_condition_type.name == "time condition" else None
        ),
            "stopping_condition_time_form": TimeConditionForm(
            prefix="stopping_condition_time_form",
            instance=instance.stopping_condition if instance.stopping_condition_type and instance.stopping_condition_type.name == "time condition" else None
        ), 
            "stopping_condition_threshold_form": ThresholdConditionForm(
                prefix="stopping_condition_threshold_form",
                instance=instance.stopping_condition if instance.stopping_condition_type and instance.stopping_condition_type.name == "threshold condition" else None
            ),
        })
        
        return self.render_to_response(context)
        
    def post(self, request, *args, **kwargs):
        """
        Handles form submission for creating a new job.
        - Validates and saves the job form and time condition forms.
        - Redirects to job detail view on success, or re-renders form with errors.

        Args:
            request (HttpRequest): The HTTP request object.

        Returns:
            HttpResponseRedirect: Redirects to job detail view on success.
            HttpResponse: Re-renders form with errors on failure.
        """
        
        # Retrieve Instances
        instance = Job.objects.get(id=kwargs["id"])
        
        # Create job form
        job_form = self.form_class(request.POST, instance=instance)
        
        # Create Starting forms
        starting_time_condition_form = TimeConditionForm(
            request.POST,
            prefix="starting_condition_time_form",
            instance=instance.starting_condition if instance.starting_condition_type and instance.starting_condition_type.name == "time condition" else None
        )
        
        # Stopping condition forms
        stopping_time_condition_form = TimeConditionForm(
            request.POST,
            prefix="stopping_condition_time_form",
            instance=instance.stopping_condition if instance.stopping_condition_type and instance.stopping_condition_type.name == "time condition" else None
        )
        stopping_condition_threshold_form = ThresholdConditionForm(
            request.POST,
            prefix="stopping_condition_threshold_form",
            instance=instance.stopping_condition if instance.stopping_condition_type and instance.stopping_condition_type.name == "threshold condition" else None
        )
        
        # Validate Job form
        if job_form.is_valid():
            starting_condition_form = None
            stopping_condition_form = None

            # Check if Starting Condition
            if job_form.instance.starting_condition_type:
                # Check if Starting Condition is Time Condition
                if job_form.instance.starting_condition_type.name == "time condition":
                    
                    # Validate Starting Time Condition form
                    if starting_time_condition_form.is_valid():
                        starting_condition_form = starting_time_condition_form
                    else:
                        # Collect all errors if any form is invalid
                        context = self.get_context_data()
                        context.update(
                            {
                                "form": job_form,
                                "starting_condition_time_form": starting_time_condition_form,
                                "stopping_condition_time_form": stopping_time_condition_form,
                            }
                        ) 
                        return self.render_to_response(context)

            # Check if Stopping Condition
            if job_form.instance.stopping_condition_type:
                
                # Check if Stopping Condition is Time Condition
                if job_form.instance.stopping_condition_type.name == "time condition":
                    # Validate Stopping Time Condition form
                    if stopping_time_condition_form.is_valid():
                        stopping_condition_form = stopping_time_condition_form
                    else:
                        # Collect all errors if any form is invalid
                        context = self.get_context_data()
                        context.update(
                            {
                                "form": job_form,
                                "starting_condition_time_form": starting_time_condition_form,
                                "stopping_condition_time_form": stopping_time_condition_form,
                                "stopping_condition_threshold_form": stopping_condition_threshold_form,
                            }
                        ) 
                        return self.render_to_response(context)
                    
                # Check if Stopping Condition is Threshold Condition
                if job_form.instance.stopping_condition_type.name == "threshold condition":
                    # Validate Stopping Threshold Condition form
                    if stopping_condition_threshold_form.is_valid():
                        stopping_condition_form = stopping_condition_threshold_form
                    else:
                        # Collect all errors if any form is invalid
                        context = self.get_context_data()
                        context.update(
                            {
                                "form": job_form,
                                "starting_condition_time_form": starting_time_condition_form,
                                "stopping_condition_time_form": stopping_time_condition_form,
                                "stopping_condition_threshold_form": stopping_condition_threshold_form,
                            }
                        ) 
                        return self.render_to_response(context)
                    
            # Save the Job
            job = job_form.save(
                starting_condition_form,
                stopping_condition_form,
                created_by = request.user
            )
            
            return redirect(reverse("job_detail", args=[job.id]))
        
        # Create context
        context = self.get_context_data()
        context.update(
            {
                "form": job_form,
                "starting_condition_time_form": starting_time_condition_form,
                "stopping_condition_time_form": stopping_time_condition_form,
                "stopping_condition_threshold_form": stopping_condition_threshold_form,
            }
        )        
        return self.render_to_response(context)



###
#
#   Actions
#

@login_required
@require_GET
def job_disable(request, id):
    """
    Resume a job instance and redirect to job detail page.
    This view requires user authentication and 'can_resume_job' permission.
    It retrieves a job by ID, calls its resume method, and redirects to the job detail page.

    Args:
        request: The HTTP request object.
        id (int): The ID of the job to resume.

    Returns:
        HttpResponseRedirect: Redirects to the job detail page.

    Raises:
        PermissionDenied: If user doesn't have 'can_resume_job' permission.
        Http404: If job with given ID is not found.

    Requires:
        - User must be logged in (@login_required).
        - Request method must be GET (@require_GET).
        - User must have '.can_resume_job' permission.
    """
    job = get_object_or_404(Job, id=id)
    job.disable()
    return redirect(request.META.get('HTTP_REFERER', '/'))

@login_required
@require_GET
def job_enable(request, id):
    """
    Pause a job instance and redirect to job detail page.
    This view requires user authentication and 'can_pause_job' permission.
    It retrieves a job by ID, calls its pause method, and redirects to the job detail page.

    Args:
        request: The HTTP request object.
        id (int): The ID of the job to pause.

    Returns:
        HttpResponseRedirect: Redirects to the job detail page.

    Raises:
        PermissionDenied: If user doesn't have 'can_pause_job' permission.
        Http404: If job with given ID is not found.

    Requires:
        - User must be logged in (@login_required).
        - Request method must be GET (@require_GET).
        - User must have '.can_pause_job' permission.
    """
    job = get_object_or_404(Job, id=id)
    job.enable()
    return redirect(request.META.get('HTTP_REFERER', '/'))


@login_required
@require_GET
def job_force_start(request, id):
    instance = get_object_or_404(Job, id=id)  # Assuming you have a Task model

    instance.force_start()   
    
    return redirect(request.META.get('HTTP_REFERER', '/'))


@login_required
@require_GET
def job_delete(request, id):
    """
    Delete a job instance.
    This view function handles the deletion of a Job object. It requires the user to be
    authenticated and to have the 'can_delete_job' permission. If the job with the given ID
    exists, it will be deleted and the user will be redirected to the jobs list page.

    Args:
        request (HttpRequest): The HTTP request object.
        id (int): The ID of the job to be deleted.

    Returns:
        HttpResponseRedirect: Redirects to the jobs list page after successful deletion.

    Raises:
        PermissionDenied: If the user doesn't have the required permission.
        Http404: If the job with the given ID doesn't exist.
    """
    instance = get_object_or_404(Job, id=id)
    instance.delete()
    return redirect("jobs")


@login_required
@require_GET
def job_log_download(request, id):
    job = get_object_or_404(Job, id=id) 

    if path.exists(job.log_path):
        # Open the log file in binary mode
        with open(job.log_path, 'rb') as log_file:
            response = HttpResponse(log_file.read(), content_type='text/plain')
            # Set the Content-Disposition header to indicate a file download
            response['Content-Disposition'] = f'attachment; filename="job_{id}_log.txt"'
            return response
    else:
        return HttpResponse('Log file not found.', status=404)

@login_required
@require_GET
def job_issues_data(request, id):
    job = get_object_or_404(Job, id=id)  
    
    issues={
        "infos": [],
        "warnings": [],
        "errors": [],
    }
    
    completed_tasks = job.tasks.filter(status=Task.Status.FINISHED).order_by("-started_at")
    
    for task in completed_tasks:
        date = floor(task.started_at.timestamp() * 1000)
        
        for level in ["infos","warnings","errors"]:
            issues[level].append([date, getattr(task, level)])
    
    return JsonResponse({"issues": issues})


###
#
#   Tasks
#
##


@method_decorator(login_required, name="dispatch")
class TaskTableView(PermissionRequiredMixin, TemplateView):
    """
    A view class that displays a paginated table of tasks with filtering capabilities.
    This view requires user authentication and specific permission to view tasks.
    It extends TemplateView and implements PermissionRequiredMixin for access control.
    Attributes:
        template_name (str): Path to the template used to render the task table
        page_size (int): Default number of items per page
        permission_required (str): Permission required to access this view
        raise_exception (bool): Whether to raise exception for unauthorized access
    Methods:
        get_context_data(**kwargs): Prepares and returns the context data for template rendering
            - Initializes template layout
            - Retrieves and orders all tasks
            - Applies filtering based on request parameters
            - Implements pagination
            - Adds create task permission check
    Returns:
        dict: Context containing:
            - filter: Filtered queryset of tasks
            - page_obj: Paginator object with task records
            - can_create_task: Boolean indicating if user can create tasks
    """
    template_title = "Tasks"
    template_name = "cerebrus/task_app/tasks/table.html"
    
    parent= 'tasks'
    segment= 'tasks_table'
    
    permission_required = "task_app.can_view_tasks"
    page_size = 10

    def get_context_data(self, **kwargs):
        """
        Prepares and returns the context data for template rendering.
        - Initializes template layout
        - Retrieves and orders all tasks
        - Applies filtering based on request parameters
        - Implements pagination
        - Adds create task permission check

        Returns:
            dict: Context containing:
                - filter: Filtered queryset of tasks
                - page_obj: Paginator object with task records
                - can_create_task: Boolean indicating if user can create tasks
        """
        # Initialize template layout
        context = super().get_context_data(**kwargs)

        # Retrieve and order all tasks
        records = Task.objects.all().order_by('-id')
        
        # Apply filtering based on request parameters
        filter = TaskFilter(self.request.GET, queryset=records)
        filtered_records = filter.qs
        
        # Implement pagination
        paginator = Paginator(
            filtered_records, 
            self.request.GET.get("page_size", self.page_size)
        )
        page_obj = paginator.get_page(self.request.GET.get("page"))
        
        # Create context
        context.update(
            {
                "template_title": self.template_title,
                "parent": self.parent,
                "segment": self.parent,
                "filter": filter,
                "total_count": paginator.count,
                "page_obj": page_obj,
                "can_create_task": self.request.user.has_perm(
                    "task_app.can_create_task"
                ),
                "can_edit_task": self.request.user.has_perm(
                    "task_app.can_edit_task"
                ),
                "can_view_task": self.request.user.has_perm(
                    "task_app.can_view_task"
                ),
                "can_delete_task": self.request.user.has_perm(
                    "task_app.can_delete_task"
                ),
            }
        )
        
        return context


@method_decorator(login_required, name="dispatch")
class TaskDetailView(PermissionRequiredMixin,TemplateView):
    """
    A view class for displaying task details.

    This class handles the display of task-specific information and associated log files.
    Requires user authentication to access the view.

    Attributes:
        template_name (str): The template used for rendering the task detail view.
        page_size (int): Number of items to display per page.
        permission_required (str): The required permission to access this view.

    Methods:
        get_context_data(**kwargs): Prepares and returns the context data for template rendering.

    Parameters:
        kwargs["id"] (int): The ID of the task to be displayed.

    Returns:
        dict: Context dictionary containing:
            - task: Task object retrieved from database
            - log: Content of the task's log file (if exists)
            - WEBSOCKET_URL: WebSocket host configuration
            - Additional template layout context data
    """
    template_title = "Task Detail"
    template_name = "cerebrus/task_app/tasks/detail.html"
    
    parent = "tasks"
    segment= "task_detail"
    
    permission_required = "task_app.can_view_task"
    page_size = 10

    def get_context_data(self, **kwargs):
        """
        Prepares and returns the context data for template rendering.
        - Initializes template layout
        - Retrieves the task by ID
        - Reads the task's log file if it exists
        - Adds WebSocket host configuration

        Returns:
            dict: Context dictionary containing:
                - task: Task object retrieved from database
                - log: Content of the task's log file (if exists)
                - WEBSOCKET_URL: WebSocket host configuration
        """
        # Initialize template layout
        context = super().get_context_data(**kwargs)
        
        # Retrieve the task by ID
        instance = Task.objects.get(id=kwargs["id"])
        
        # Retrive te task's Issues
        issues_records = instance.events.all()
        
        # Apply filtering based on request parameters
        issues_filter = EventFilter(self.request.GET, queryset=issues_records)
        filtered_records = issues_filter.qs
        
        # Implement pagination
        paginator = Paginator(
            filtered_records, 
            self.request.GET.get("page_size", self.page_size)
        )
        issues_page_obj = paginator.get_page(self.request.GET.get("page"))

        # Read the task's log file if it exists
        # Read the task's log file with pagination
        log_path = instance.log_path        
        if log_path and path.isfile(log_path):

            # Count total lines (cached or per request)
            total_lines = count_lines(log_path)

            # Pagination variables for logs
            log_page_size = 5000
            current_page = int(self.request.GET.get("log_page", 1))

            # Calculate offsets
            offset_from_end = (current_page - 1) * log_page_size

            # Extract only needed lines
            log_content = tail_colored_log(
                filepath=log_path,
                offset=offset_from_end,
                limit=log_page_size
            )

            # Add color coding
            context["log"] = log_content #mark_safe(log_content)

            # Add pagination info to context
            context["log_page"] = current_page
            context["log_total_pages"] = math.ceil(total_lines / log_page_size)
        
        ## Audit Log
        
        # Get the 5 most recent audit log records
        audit_log_records = instance.audit_logs.order_by("-created_at")[:7]
        
        # Group audit logs by created_at
        audit_logs_by_date = {}
        for log in audit_log_records:
            date_key = log.created_at.strftime('%-d %b. %Y')
            if date_key not in audit_logs_by_date:
                audit_logs_by_date[date_key] = []
            audit_logs_by_date[date_key].append(log)
        
        # Add to context
        context["audit_logs_by_date"] = audit_logs_by_date
             
        # Create context
        context.update(
            {
                "template_title": self.template_title,
                "parent": self.parent.capitalize(),
                "segment": self.segment,
                "WEBSOCKET_URL": WEBSOCKET_URL,
                "instance": instance,
                "filter": issues_filter,
                "total_count": paginator.count,
                "page_obj": issues_page_obj,
                "task_file_form": TaskFileUploadForm(),   
                "errors_count": instance.events.filter(type=Event.EventType.ERROR).count(),
                "warnings_count": instance.events.filter(type=Event.EventType.WARNING).count(),
                "infos_count": instance.events.filter(type=Event.EventType.INFO).count(),
                "can_cancel_task": self.request.user.has_perm(
                    "task_app.can_cancel_task"
                ),
                "can_restart_task": self.request.user.has_perm(
                    "task_app.can_restart_task"
                ),
                "can_resume_task": self.request.user.has_perm(
                    "task_app.can_resume_task"
                ),
                "can_pause_task": self.request.user.has_perm(
                    "task_app.can_pause_task"
                ),
                "can_edit_task": self.request.user.has_perm(
                    "task_app.can_edit_task"
                ),
                "can_delete_task": self.request.user.has_perm(
                    "task_app.can_delete_task"
                ),
            }
        )
        return context


@method_decorator(login_required, name="dispatch")
class TaskCreateView(PermissionRequiredMixin, TemplateView):
    """
    Class-based view for creating a new task.

    This view requires users to be authenticated and have the '.can_create_task' permission.
    It renders a form for task creation and handles both GET and POST requests.

    Attributes:
        template_name (str): Path to the template used for rendering the task creation form.
        permission_required (str): Permission required to access this view.

    Methods:
        get_context_data(**kwargs): Adds form and layout context to template context.
        post(request, *args, **kwargs): Handles form submission, saves task if valid, 
            and redirects to task detail view.

    Returns:
        GET: Rendered template with task creation form
        POST: Redirects to task detail view on success, or re-renders form with errors
    """
    template_title = "Create Task"
    template_name = "cerebrus/task_app/tasks/create.html"
    
    parent= 'tasks'
    segment= 'task_create'
    
    permission_required = "task_app.can_create_task"

    def get_context_data(self, **kwargs):
        # A function to init the global layout. It is defined in web_project/__init__.py file
        context = super().get_context_data(**kwargs)
        
        # Create the main task form
        task_form = TaskForm()
        
        # Get all available script forms
        script_forms = {}
        for script_name, form_class in task_form.get_available_script_forms().items():
            script_forms[script_name] = form_class()

        # Create context
        context.update({
            "template_title": self.template_title,
            "parent": self.parent.capitalize(),
            "form": task_form,
            "script_forms": script_forms,
        })

        return context

    def post(self, request, *args, **kwargs):

        # Populate the form with POST data
        form = TaskForm(request.POST)

        # Validate the form (this includes script form validation)
        if form.is_valid():
            # Form handles both task and script creation
            instance = form.save(created_by=request.user)
            instance.save()
            return redirect(reverse("task_detail", args=[instance.id]))
        
        # Form validation failed - get the current script to show its form
        script_class_name = request.POST.get('script') if 'script' in request.POST else None
        script_form = None
        
        if script_class_name:
            # Get the script form to display validation errors
            script_form = form.get_script_form(script_class_name, data=request.POST)
        
        context = {
            "template_title": self.template_title,
            "parent": self.parent.capitalize(),
            "form": form,
            "script_form": script_form,
            "selected_script": script_class_name
        }

        return render(request, self.template_name, context)


@method_decorator(login_required, name="dispatch")
class TaskEditView(PermissionRequiredMixin, TemplateView):
    """
    View for editing a user.

    Inherits from:
        PermissionRequiredMixin: Ensures the user has the required permissions.
        TemplateView: Renders a template.

    Attributes:
        template_name (str): The path to the template used for rendering the view.
        permission_required (str): The permission required to access this view.
        form_class (UserEditForm): The form class used for editing the user.

    Methods:
        get_object(): Retrieves the User object or raises a 404 error.
        get_context_data(**kwargs): Adds the UserEditForm to the context.
        post(request, *args, **kwargs): Handles form submission for editing a user.


        Returns:
            User: The user object retrieved by ID.


        Args:
            **kwargs: Additional context data.

        Returns:
            dict: The context data including the form.


        Args:
            request (HttpRequest): The HTTP request object.
            *args: Additional positional arguments.
            **kwargs: Additional keyword arguments.

        Returns:
            HttpResponse: The HTTP response object.
    """
    
    template_title = "Edit Task"
    template_name = '/task/edit.html'
    
    parent= 'tasks'
    segment= 'task_edit'
    
    permission_required = ".change_task"
    form_class = TaskForm
    
    def get_context_data(self, **kwargs):

        # Initialize template layout
        context = super().get_context_data(**kwargs)
        context.update({
            "template_title": self.template_title,
            "parent": self.parent.capitalize(),
            "segment": self.segment,
        })
        
        return context

    def get(self, request, *args, **kwargs):
        
        # Obtain the context
        context = self.get_context_data(**kwargs)
        
        # Retrieve Instances
        instance = Task.objects.get(id=kwargs["id"])
        
        form = self.form_class(instance=instance)
        
        print(form.fields['properties'].initial)
        
        # Create context
        context.update({
            "form": form
        })
        
        return self.render_to_response(context)

    def post(self, request, *args, **kwargs):
        """
        Handle form submission for editing a user.
        """
        
        # Retrieve Instances
        instance = Task.objects.get(id=kwargs["id"])
        
        # Create task form        
        task_form = self.form_class(request.POST, instance=instance)

        # Validate Job form
        if task_form.is_valid():
            task_form.save()
            return redirect(reverse("task_detail", args=[instance.id]))

        # Create context
        context = self.get_context_data()
        context.update(
            {
                "form": task_form
            }
        )  
        return self.render_to_response(context)

###
#
#   Actions
#


@login_required
@require_GET
def task_restart(request, id):
    """
    Restart a task instance and redirect to task detail page.
    This view requires user authentication and 'can_restart_task' permission.
    It retrieves a task by ID, calls its restart method, and redirects to the task detail page.
    Args:
        request: The HTTP request object
        id (int): The ID of the task to restart
    Returns:
        HttpResponseRedirect: Redirects to the task detail page
    Raises:
        PermissionDenied: If user doesn't have 'can_restart_task' permission
        Http404: If task with given ID is not found
    Requires:
        - User must be logged in (@login_required)
        - Request method must be GET (@require_GET)
        - User must have '.can_restart_task' permission
    """

    if not request.user.has_perm("task_app.can_restart_task"):
        raise PermissionDenied

    instance = get_object_or_404(Task, id=id)
    instance.restart(changed_by=request.user)

    
    return redirect(reverse("task_detail", args=[instance.id]))


@login_required
@require_GET
def task_cancel(request, id):
    """
    Cancel a task and redirect to task detail page.
    This view cancels a specific task and redirects to the task detail page. It requires login and GET method.
    Only users with 'can_cancel_task' permission can access this view.
    Args:
        request (HttpRequest): The HTTP request object
        id (int): The ID of the task to be cancelled
    Returns:
        HttpResponseRedirect: Redirects to the task detail page
    Raises:
        PermissionDenied: If user doesn't have required permission
        Http404: If task with given ID doesn't exist
    Required Permissions:
        - .can_cancel_task
    Decorators:
        - @login_required
        - @require_GET
    """
    if not request.user.has_perm("task_app.can_cancel_task"):
        raise PermissionDenied

    instance = get_object_or_404(Task, id=id)
    instance.cancel(changed_by=request.user)
    
    return redirect(reverse("task_detail", args=[instance.id]))


@login_required
@require_GET
def task_delete(request, id):
    """
    Delete a task instance.
    This view function handles the deletion of a Task object. It requires the user to be
    authenticated and to have the 'can_delete_task' permission. If the task with the given ID
    exists, it will be deleted and the user will be redirected to the current page.
    Args:
        request (HttpRequest): The HTTP request object.
        id (int): The ID of the task to be deleted.
    Returns:
        HttpResponseRedirect: Redirects to the current page after successful deletion.
    Raises:
        PermissionDenied: If the user doesn't have the required permission.
        Http404: If the task with the given ID doesn't exist.
    """
    if not request.user.has_perm("task_app.can_delete_task"):
        raise PermissionDenied

    instance = get_object_or_404(Task, id=id)
    instance.delete()
    previous_url = request.META.get('HTTP_REFERER', '/')
    return redirect('tasks' if str(id) in previous_url else previous_url)


@login_required
@require_GET
def task_pause(request, id):

    if not request.user.has_perm("task_app.can_pause_task"):
        raise PermissionDenied

    instance = get_object_or_404(Task, id=id)
    instance.pause(changed_by=request.user)
    return redirect(reverse("task_detail", args=[instance.id]))


@login_required
@require_GET
def task_resume(request, id):

    if not request.user.has_perm("task_app.can_resume_task"):
        raise PermissionDenied

    instance = get_object_or_404(Task, id=id)
    instance.resume(changed_by=request.user)
    return redirect(reverse("task_detail", args=[instance.id]))


@login_required
@require_GET
def download_log(request, id):
    task = get_object_or_404(Task, id=id)  # Assuming you have a Task model

    if task.status in [task.Status.RUNNING, Task.Status.WAITING]:
        messages.error(request, 'Task is still running. Please wait until it finishes.')
        return redirect(request.META.get('HTTP_REFERER', '/'))  # Redirect to previous page

    if path.exists(task.log_path):
        with open(task.log_path, 'rb') as log_file:
            response = HttpResponse(log_file.read(), content_type='text/plain')
            response['Content-Disposition'] = f'attachment; filename="task_{id}_log.txt"'
            return response
    else:
        messages.error(request, 'Log file not found.')
        return redirect(request.META.get('HTTP_REFERER', '/'))


@login_required
@require_GET
def download_db(request, id):
    task = get_object_or_404(Task, id=id)  # Assuming you have a Task model
    
    if task.status == task.Status.RUNNING or task.status == Task.Status.WAITING:
        messages.error(request, 'Task is still running. Please wait until it finishes.')
        return redirect(request.META.get('HTTP_REFERER', '/'))  # Redirect to previous page
    
    if task.sql_path and path.exists(task.sql_path):
        # Open the log file in binary mode
        with open(task.sql_path, 'rb') as sql_file:
            response = HttpResponse(sql_file.read(), content_type='text/plain')
            # Set the Content-Disposition header to indicate a file download
            response['Content-Disposition'] = f'attachment; filename="task_{id}_db.sql"'
            return response
    else:
        messages.error(request, 'Database file not found.')
        return redirect(request.META.get('HTTP_REFERER', '/'))


###
#   Task's Files
#   

class TaskFileListView(ListView):
    """List view for task files with filtering"""
    model = TaskFile
    template_name = 'cerebrus/task_app/task_files_list.html'
    context_object_name = 'files'
    paginate_by = 20
    
    def get_queryset(self):
        task_id = self.kwargs['task_id']
        self.task = get_object_or_404(Task, id=task_id)
        queryset = TaskFile.objects.filter(task=self.task)
        
        # Apply filters
        form = TaskFileFilterForm(self.request.GET)
        if form.is_valid():
            if form.cleaned_data['file_type']:
                queryset = queryset.filter(file_type=form.cleaned_data['file_type'])
            
            if form.cleaned_data['is_public']:
                is_public = form.cleaned_data['is_public'] == 'true'
                queryset = queryset.filter(is_public=is_public)
        
        return queryset
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['task'] = self.task
        context['filter_form'] = TaskFileFilterForm(self.request.GET)
        context['upload_form'] = TaskFileUploadForm()
        return context
    
@login_required
@require_POST
def task_file_upload(request, task_id):
    """Handle file upload for a task"""
    
    if not request.user.has_perm("task_app.can_upload_file_to_task"):
        raise PermissionDenied
    
    task = get_object_or_404(Task, id=task_id)
    
    form = TaskFileUploadForm(request.POST, request.FILES)
    if form.is_valid():
        task_file = form.save(commit=False)
        task_file.task = task
        task_file.uploaded_by = request.user
        
        # Validate file size (50MB limit)
        if task_file.path.size > 50 * 1024 * 1024:
            messages.error(request, "File size must be less than 50MB.")
            return redirect('task_detail', id=task_id)
        
        task_file.save()
        messages.success(request, f"File '{task_file.original_name}' uploaded successfully.")
    else:
        messages.error(request, "Error uploading file. Please check the form.")
    
    return redirect('task_detail', id=task_id)

@login_required
@require_GET
def task_file_download(request, file_id):
    """Handle file download"""
    
    
    if not request.user.has_perm("task_app.can_download_file_from_task"):
        raise PermissionDenied

    task_file = get_object_or_404(TaskFile, id=file_id)
    
    # Check permissions for private files
    if not task_file.is_public:
        # Add your permission logic here
        pass
    
    try:
        # Determine content type
        content_type, _ = mimetypes.guess_type(task_file.file.name)
        if content_type is None:
            content_type = 'application/octet-stream'
        
        response = FileResponse(
            task_file.file.open('rb'),
            content_type=content_type,
            as_attachment=True,
            filename=task_file.original_name
        )
        return response
        
    except FileNotFoundError:
        messages.error(request, "File not found.")
        return redirect(request.META.get('HTTP_REFERER', 'tasks'))

@login_required
@require_GET
def task_file_delete(request, file_id):
    """Delete a task file"""
    
    if not request.user.has_perm("task_app.can_download_file_from_task"):
        raise PermissionDenied
    
    task_file = get_object_or_404(TaskFile, id=file_id)
    
    filename = task_file.original_name
    task_file.delete()
    messages.success(request, f"File '{filename}' deleted successfully.")
    
    return redirect(request.META.get('HTTP_REFERER', 'tasks'))


##
#   Scripts
#
from apps.task_app.scripts import _script_folders

@login_required
@require_GET
def get_scripts_by_type(request, type):
    """Return scripts available for a specific task type as JSON"""
    
    # Get all scripts from _script_folders
    # Task types are uppercase folder names, so we need to map them properly
    scripts = []
    
    # Convert task type to lowercase to match folder structure
    folder_key = type.lower()
    
    # Try to get scripts from the specific folder
    if folder_key in _script_folders:
        scripts = _script_folders[folder_key]
    elif 'root' in _script_folders:
        # Fallback to root folder scripts
        scripts = _script_folders['root']
    else:
        # Get all available scripts from all folders as fallback
        for folder_scripts in _script_folders.values():
            if isinstance(folder_scripts, list):
                scripts.extend(folder_scripts)
            else:
                scripts.append(folder_scripts)
    
    # Convert scripts to a list of dictionaries with name and display name
    script_data = []
    script_list = scripts if isinstance(scripts, list) else [scripts] if scripts else []
    
    for script in script_list:
        if hasattr(script, '__name__'):
            class_name = script.__name__
            # Convert CamelCase to Title Case for display
            display_name = ''.join([' ' + c if c.isupper() and i > 0 else c for i, c in enumerate(class_name)]).strip()
            script_data.append({
                'value': class_name,
                'label': display_name
            })
        
    return JsonResponse({'scripts': script_data})


@login_required
@require_GET
def get_script_form(request, script_class_name):
    """Return the HTML form for a specific script type"""
    
    try:
        from django.template.loader import render_to_string
        from apps.task_app.scripts import _script_classes
        
        # Find the script class
        script_class = None
        for cls in _script_classes:
            if cls.__name__ == script_class_name:
                script_class = cls
                break
        
        if not script_class:
            return JsonResponse({'error': 'Script class not found'}, status=404)
        
        # Create a dummy instance to get the form
        dummy_instance = script_class()
        if hasattr(dummy_instance, 'form_class'):
            form_class = dummy_instance.form_class
            form = form_class()
            
            # Render form using Django template
            form_html = render_to_string('cerebrus/task_app/partials/script_form.html', {
                'form': form,
                'script_class_name': script_class_name,
                'script_class': script_class,
            }, request=request)
            
            return JsonResponse({
                'form_html': form_html,
                'script_class': script_class_name
            })
        else:
            return JsonResponse({'error': 'Script has no associated form'}, status=400)
            
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)