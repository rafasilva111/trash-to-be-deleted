from django.db import models
from django import forms
from apps.task_app.models import BaseScript
from apps.task_app.scripts.forms import BaseScriptForm

import time

SCRIPT_DESCRIPTION = """This is a counting script that simulates a task by counting up to a specified maximum value.
- The `max_count` parameter determines how high the counter will go.
- If `max_count` is set to negative numbers, the script will simulate a failure by raising an exception after counting to a certain point.
"""

class CountingScript(BaseScript):
    """
    Counting script implementation with configurable parameters
    """    
    max_count = models.IntegerField(
        default=10000,
        verbose_name="Max Count",
        help_text="Maximum count for the counting task. Use negative numbers to trigger failure."
    )

    
    class Meta:
        verbose_name = "Counting Script"
        verbose_name_plural = "Counting Scripts"
    
    @property
    def form_class(self):
        """Return the form class for this script"""
        return CountingScriptForm
    
    @property
    def script_function(self):
        """Return the script function to execute"""
        return counting_script
    
    
    def __str__(self):
        return f"Counting Script (max: {self.max_count})"


  

class CountingScriptForm(BaseScriptForm):
    """Form for configuring CountingScript parameters"""
    
    class Meta:
        model = CountingScript
        fields = ['name', 'description', 'max_count']
        widgets = {
            **BaseScriptForm.Meta.widgets,
            'max_count': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': '100',
            }),
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        self.fields['description'].initial = SCRIPT_DESCRIPTION
        self.fields['name'].initial = "Counting Script"
        self.fields['max_count'].initial = 100
        self.fields['max_count'].help_text = "Set the maximum count for the counting task. Use negative numbers to trigger failure."


def counting_script(logger, task, resume=False, max_count=10000):
    """
    A helper function to simulate task processing by counting to a max value.

    - Logs each count increment and the task start/completion.
    - If use of negative numbers, raises an exception to simulate a failure.

    Args:
        logger (logging.Logger): The logger to use for logging task events.
        task (Task): The task instance associated with the counting.
        resume (bool): Whether to resume from the last step.
        max_count (int): The maximum count for the test task. Defaults to 10000.
        sleep_interval (float): Time in seconds to sleep between counts.
    
    Raises:
        Exception: If max_count is less than 0.
    """
    logger.info("")
    logger.info("Executing Counting Script...")
    logger.info("")
    
    trigger_failure = False
    task.max_steps = max_count
    task.save()
    
    if max_count == -1:
        trigger_failure = True

    elif max_count < -1:
        max_count = - max_count
        trigger_failure = True
        

    counter = task.step if resume else 0
    

    while counter < max_count:
        counter += 1
        
        logger.info(f"Counting at: {counter} .")
        
        time.sleep(1)
        
        # Save state to avoid losing the counter value in case of failure or pause
        task.items_processed = counter
        task.step = counter
        task.save()
    
    # Check if a failure was triggered
    if trigger_failure:
        task.increment_errors(logger,"Failure was triggered.")
        raise Exception("Failure was triggered.")
    
    logger.info("")
    logger.info("> Done...")
    logger.info("")
    
    # Update task status to finished
    task.finish()
    print("Task finished successfully.")
    return task
