from django.db import models
from django import forms
from apps.task_app.models import BaseScript
from apps.task_app.scripts.forms import BaseScriptForm
import time
import threading
from concurrent.futures import ThreadPoolExecutor

SCRIPT_DESCRIPTION = """This is a counting script that simulates a task by counting up to a specified maximum value.
- The `max_count` parameter determines how high the counter will go.
- If `max_count` is set to negative numbers, the script will simulate a failure by raising an exception after counting to a certain point.
"""

class DuplicateDocumentScript(BaseScript):
    """
    Default script implementation for basic task execution
    """
    
    input_file = models.FileField(
        upload_to='scripts/inputs/',
        null=True,
        blank=True,
        verbose_name="Input File",
        help_text="Upload a file to be processed by the script."
    )
    
    nr_of_duplicates = models.IntegerField(
        default=1,
        verbose_name="Number of Duplicates",
        help_text="Number of duplicates to create for each document. Default is 1."
    )
    
    thread_count = models.IntegerField(
        default=1,
        verbose_name="Thread Count",
        help_text="Number of threads to use for processing. Default is 1."
    )
    
    class Meta:
        verbose_name = "Duplicate Document Script"
        verbose_name_plural = "Duplicate Document Scripts"
    
    @property
    def form_class(self):
        """Return the form class for this script"""
        return DuplicateDocumentScriptForm
    
    @property
    def script_function(self):
        """Return the script function to execute"""
        return duplicate_document_script
    
    
    def __str__(self):
        return f"Counting Script (max: {self.nr_of_duplicates})"


class DuplicateDocumentScriptForm(BaseScriptForm):
    """Form for configuring Duplicate Document Script parameters"""
    
    class Meta:
        model = DuplicateDocumentScript
        fields = ['name', 'description', 'input_file', 'nr_of_duplicates', 'thread_count']
        widgets = {
            **BaseScriptForm.Meta.widgets,
            'input_file': forms.ClearableFileInput(attrs={
                'accept': '.pdf,.doc,.docx,.txt',
                'id': 'file-input'
            }),
            'nr_of_duplicates': forms.NumberInput(attrs={
            'class': 'form-control',
            }),
            'thread_count': forms.NumberInput(attrs={
            'class': 'form-control form-control-lg',
            }),
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        self.fields['description'].initial = SCRIPT_DESCRIPTION
        self.fields['name'].initial = "Duplicate Document Script"
        self.fields['nr_of_duplicates'].initial = 1
        self.fields['nr_of_duplicates'].help_text = "Number of duplicates to create for each document."
        self.fields['thread_count'].initial = 1
        self.fields['thread_count'].help_text = "Number of threads to use for processing (1-10)."
        self.fields['input_file'].help_text = "Upload a document file to be duplicated (.pdf, .doc, .docx, .txt)."


def duplicate_document_script(logger, task, resume=False, input_file=None, nr_of_duplicates=1, thread_count=1):
    """
    A script to duplicate documents based on the provided parameters.

    Args:
        logger (logging.Logger): The logger to use for logging task events.
        task (Task): The task instance associated with the script.
        resume (bool): Whether to resume from the last step.
        input_file: The uploaded file to be duplicated.
        nr_of_duplicates (int): Number of duplicates to create.
        thread_count (int): Number of threads to use for processing.
    
    Raises:
        Exception: If required parameters are missing or invalid.
    """
    logger.info("")
    logger.info("Executing Duplicate Document Script...")
    logger.info("")
    
    # Option: Use file uploaded via TaskFileUploadForm
    uploaded_file = task.input_file
    if uploaded_file.exists():
        logger.info(f"Found {uploaded_file.count()} uploaded files:")
        for task_file in uploaded_file:
            logger.info(f"  - {task_file.original_name} ({task_file.file_type})")
            # You can access the actual file via task_file.path
            
    # Validate input parameters
    if not input_file and not uploaded_file.exists():
        task.increment_errors(logger, "No input file provided")
        raise Exception("No input file provided")
    
    # Use input_file parameter if provided, otherwise use first uploaded file
    target_file = input_file
    if not target_file and uploaded_file.exists():
        target_file = uploaded_file.first().path
        logger.info(f"Using uploaded file: {uploaded_file.first().original_name}")
    
    logger.info(f"Target file: {target_file}")
    logger.info(f"Number of duplicates: {nr_of_duplicates}")
    logger.info(f"Thread count: {thread_count}")
    
    # Set max steps based on number of duplicates
    task.max_steps = nr_of_duplicates
    task.save()
    
    # Resume from last step or start fresh
    counter = task.step if resume else 0
    
    def create_duplicate(input_file, duplicate_number):
        """Function to create a single duplicate"""
        logger.info(f"Creating duplicate {duplicate_number} of {nr_of_duplicates}")
        
        # Simulate document processing time
        time.sleep(2)
        
        # Read the target file line by line and write to a new duplicate file
        duplicate_filename = f"{target_file}_duplicate_{duplicate_number}"
        
        try:
            with open(target_file, 'r', encoding='utf-8') as source_file:
                with open(duplicate_filename, 'w', encoding='utf-8') as duplicate_file:
                    for line in source_file:
                        duplicate_file.write(line)
            logger.info(f"Successfully created duplicate file: {duplicate_filename}")
        except Exception as e:
            logger.error(f"Error creating duplicate {duplicate_number}: {str(e)}")
            raise
        
        return duplicate_number
    
    # Create list of remaining duplicates to process
    remaining_duplicates = list(range(counter + 1, nr_of_duplicates + 1))
    
    # Use ThreadPoolExecutor with max_workers set to thread_count
    with ThreadPoolExecutor(max_workers=thread_count) as executor:
        # Submit all duplicate creation tasks
        future_to_duplicate = {
            executor.submit(create_duplicate, target_file, dup_num): dup_num 
            for dup_num in remaining_duplicates
        }
        
        # Process completed tasks and update progress
        for future in future_to_duplicate:
            duplicate_number = future.result()
            
            # Update progress (thread-safe)
            with threading.Lock():
                task.items_processed = duplicate_number
                task.step = duplicate_number
                task.save()
                logger.info(f"Completed duplicate {duplicate_number}")
    
    logger.info("")
    logger.info("> Document duplication completed successfully...")
    logger.info("")
    
    # Update task status to finished
    task.finish()
    logger.info("Task finished successfully.")
    return task
