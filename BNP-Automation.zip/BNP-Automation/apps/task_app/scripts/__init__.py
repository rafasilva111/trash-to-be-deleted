# Scripts module - Recursive discovery of all script classes across all folders
import os
import importlib
import pkgutil
import logging
from typing import Dict, List, Tuple, Type, Optional
from functools import lru_cache

logger = logging.getLogger(__name__)


def _discover_script_classes_recursive() -> Tuple[List[Type], Dict[str, List[Type]]]:
    """
    Recursively discover and import all script classes in this package and subpackages.
    This function walks through the scripts directory and all its subdirectories to find
    Python modules containing classes that inherit from BaseScript. It dynamically imports
    these modules and identifies script classes, making them available for use.
    The function uses pkgutil.walk_packages to traverse the package hierarchy, starting
    from the current package directory. For each non-package module found, it:
    1. Imports the module
    2. Examines all attributes to find classes
    3. Filters for classes that inherit from BaseScript (excluding BaseScript itself)
    4. Adds discovered classes to the global namespace
    5. Organizes classes by their folder structure
    Returns:
        tuple: A tuple containing two elements:
            - script_classes (list): List of all discovered BaseScript subclasses
            - script_folders (dict): Dictionary mapping folder paths to lists of script classes
                                   found in those folders. Folder paths are relative to the
                                   scripts directory, with 'root' used for classes in the
                                   top-level scripts directory.
    Note:
        - The 'finder' parameter from pkgutil.walk_packages is not used in this implementation
        - Modules that cannot be imported are silently skipped
        - Classes that don't inherit from BaseScript or where BaseScript cannot be imported
          are silently skipped
        - Discovered classes are added to the global namespace using globals()
    """
    logger.debug("Starting script class discovery...")
    script_classes: List[Type] = []
    script_folders: Dict[str, List[Type]] = {}  
    package_dir = os.path.dirname(__file__)
    package_name = __package__ if __package__ else __name__
    
    if not package_name:
        logger.error("Package name is None, cannot discover scripts")
        return script_classes, script_folders
    
    # Walk through all packages and subpackages
    modules_processed = 0
    modules_with_scripts = 0
    
    try:
        for finder, modname, ispkg in pkgutil.walk_packages([package_dir], package_name + '.'):
            modules_processed += 1
            
            # Skip package modules
            if ispkg:
                continue
                
            try:
                # Import the module
                module = importlib.import_module(modname)
                
                # Get the folder path relative to the scripts directory
                module_parts = modname.split('.')[3:]  # Remove 'apps.task_app.scripts'
                folder_path = module_parts[0] if len(module_parts) > 1 else 'default'
                
                # Find all classes in the module that inherit from BaseScript
                module_script_count = 0
                for attr_name in dir(module):
                    if attr_name.startswith('_'):  # Skip private attributes
                        continue
                        
                    try:
                        attr = getattr(module, attr_name)
                    except AttributeError:
                        continue
                    
                    if (isinstance(attr, type) and 
                        hasattr(attr, '__module__') and 
                        attr.__module__ == module.__name__ and
                        attr.__name__ != 'BaseScript'):  # Exclude the base class itself
                        
                        # Check if it's a BaseScript subclass
                        try:
                            # Import BaseScript here to avoid circular imports
                            from apps.task_app.models import BaseScript
                            
                            if issubclass(attr, BaseScript):
                                logger.debug(f"Discovered script class: {attr.__name__} in {folder_path}")
                                script_classes.append(attr)
                                globals()[attr.__name__] = attr  # Make it available for import
                                module_script_count += 1
                                
                                # Add to folder mapping
                                if folder_path not in script_folders:
                                    script_folders[folder_path] = []
                                script_folders[folder_path].append(attr)
                        except (ImportError, TypeError) as e:
                            # Skip if BaseScript not available or not a class
                            logger.warning(f"Error checking BaseScript inheritance for {attr.__name__}: {e}")
                            continue
                            
                if module_script_count > 0:
                    modules_with_scripts += 1
                        
            except ImportError as e:
                # Log import errors but don't fail the entire discovery
                logger.warning(f"Failed to import {modname}: {e}")
                continue
            except Exception as e:
                # Catch any other unexpected errors
                logger.error(f"Unexpected error processing module {modname}: {e}")
                continue
                
    except Exception as e:
        logger.error(f"Critical error in script discovery: {e}")
        return script_classes, script_folders
    
    logger.info(f"Script discovery completed: {len(script_classes)} classes found in {len(script_folders)} folders from {modules_with_scripts}/{modules_processed} modules")
    return script_classes, script_folders

# Dynamically discover and import all script classes recursively
_script_classes, _script_folders = _discover_script_classes_recursive()

# Build script forms mapping and choices at import time (optimization)
def _build_script_forms_and_choices() -> Tuple[Dict[str, Dict[str, Type]], Dict[str, List[Tuple[str, str]]]]:
    """
    Build script forms mapping and choices at import time to avoid 
    creating dummy instances repeatedly in forms.
    
    Returns:
        Tuple of (script_forms_cache, script_choices_cache)
    """
    script_forms: Dict[str, Dict[str, Type]] = {}
    script_choices_cache: Dict[str, List[Tuple[str, str]]] = {}
    
    for folder_name, classes_list in _script_folders.items():
        # Build choices for this folder
        choices: List[Tuple[str, str]] = [('', 'Select a script type (optional)')]
        folder_script_forms: Dict[str, Type] = {}
        
        for script_class in classes_list:
            class_name = script_class.__name__
            # Convert CamelCase to Title Case (e.g., TestingScript -> Testing Script)  
            display_name = ''.join([' ' + c if c.isupper() and i > 0 else c for i, c in enumerate(class_name)]).strip()
            choices.append((class_name, display_name))
            
            # Get form class without creating instances
            try:
                # Check if class has form_class as a property or attribute
                if hasattr(script_class, 'form_class'):
                    form_class = getattr(script_class, 'form_class')
                    if form_class and hasattr(form_class, '_meta'):  # Verify it's a form class
                        folder_script_forms[class_name] = form_class
                        continue
                        
                # Fallback: create instance safely
                try:
                    dummy_instance = script_class()
                    if hasattr(dummy_instance, 'form_class'):
                        form_class = dummy_instance.form_class
                        if form_class and hasattr(form_class, '_meta'):
                            folder_script_forms[class_name] = form_class
                except Exception as e:
                    logger.warning(f"Could not get form class for {class_name}: {e}")
                    continue
                        
            except Exception as e:
                logger.error(f"Error processing script class {class_name}: {e}")
                continue
        
        script_choices_cache[folder_name] = choices
        script_forms[folder_name] = folder_script_forms
    
    return script_forms, script_choices_cache

# Cache script forms and choices at import time
_script_forms_cache, _script_choices_cache = _build_script_forms_and_choices()

# Utility functions for external use
@lru_cache(maxsize=128)
def get_script_class_by_name(class_name: str) -> Optional[Type]:
    """Get a script class by its name with caching."""
    for script_class in _script_classes:
        if script_class.__name__ == class_name:
            return script_class
    return None

def get_scripts_by_folder(folder_name: str) -> List[Type]:
    """Get all script classes in a specific folder."""
    return _script_folders.get(folder_name, [])

def get_all_script_info() -> Dict[str, Dict]:
    """Get comprehensive information about all discovered scripts."""
    info = {}
    for folder_name, classes in _script_folders.items():
        info[folder_name] = {
            'count': len(classes),
            'classes': [cls.__name__ for cls in classes],
            'has_forms': folder_name in _script_forms_cache and bool(_script_forms_cache[folder_name])
        }
    return info

__all__ = [cls.__name__ for cls in _script_classes] + [
    'get_script_class_by_name', 'get_scripts_by_folder', 'get_all_script_info'
]