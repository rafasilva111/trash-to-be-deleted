from django.db import models
from django import forms
from apps.task_app.models import BaseScript





class BaseScriptForm(forms.ModelForm):
    """Base form class for all script forms"""
    
    class Meta:
        model = BaseScript
        fields = ['name', 'description']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter script name'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 5,
                'placeholder': 'Enter description',
            }),
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['name'].help_text = "Enter a name for this script."
        self.fields['description'].help_text = "Provide a description for the script."