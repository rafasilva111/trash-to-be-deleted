from django import template

register = template.Library()

@register.filter
def get_item(obj, key):
    """Get an attribute from an object dynamically"""
    try:
        return getattr(obj, key, None)
    except (AttributeError, KeyError):
        return None

@register.filter  
def get_field_display(obj, field_name):
    """Get the display value for a field with choices"""
    try:
        method_name = f"get_{field_name}_display"
        if hasattr(obj, method_name):
            return getattr(obj, method_name)()
        return getattr(obj, field_name, None)
    except (AttributeError, KeyError):
        return None