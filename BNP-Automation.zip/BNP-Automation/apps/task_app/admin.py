###
# General imports
##

## Django Admin
from django.contrib import admin

### App-specific imports

## Models
from apps.task_app.models import Task, TaskFile, Job, TimeCondition, TaskStatusConditionAwaiter, Event, TaskAuditLog

# Register your models here.

@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    """
    Admin configuration for the Task model.

    - Displays task type, status, and timing information.
    - Provides an action to duplicate selected tasks.

    Attributes:
        list_display (tuple): Fields to display in the list view.
        actions (list): List of custom actions for TaskAdmin.
    """
    list_display = ('category', 'status', 'started_at', 'finished_at')
    actions = ['duplicate_tasks']

    def duplicate_tasks(self, request, queryset):
        """
        Duplicates selected Task instances.

        - For each task in the queryset, sets the primary key to None,
          saving it as a new instance.
          
        Args:
            request (HttpRequest): The current request object.
            queryset (QuerySet): The selected tasks to duplicate.
        """
        for task in queryset:
            task.pk = None  # Set primary key to None to create a new instance
            task.save()
    duplicate_tasks.short_description = 'Duplicate selected tasks'


@admin.register(Job)
class JobAdmin(admin.ModelAdmin):
    """
    Admin configuration for the Job model.

    - Displays the last run time and allows filtering by it.
    - Sets last_run as a read-only field.

    Attributes:
        list_display (tuple): Fields to display in the list view.
        list_filter (tuple): Fields to filter by in the list view.
        readonly_fields (tuple): Fields to set as read-only.
    """
    list_display = ('name', 'category', 'enabled',  'log_path')
    search_fields = ('name', 'category','enabled')
    list_filter = ( 'category',)
    



@admin.register(TimeCondition)
class TimeConditionAdmin(admin.ModelAdmin):
    """
    Admin configuration for the TimeCondition model.

    - Displays crontab and periodic task information.
    - Allows searching by crontab schedule.

    Attributes:
        list_display (tuple): Fields to display in the list view.
        search_fields (tuple): Fields to search by in the list view.
    """
    list_display = ('id', 'periodic_task')

@admin.register(TaskStatusConditionAwaiter)
class TaskStatusConditionAwaiterAdmin(admin.ModelAdmin):
    """
    Admin configuration for the TaskStatusConditionAwaiter model.

    - Displays task status and related information.
    - Allows searching by task status or related fields.

    Attributes:
        list_display (tuple): Fields to display in the list view.
        search_fields (tuple): Fields to search by in the list view.
    """
    list_display = ('id', 'dependent_task','owner_task', 'triggered', 'created_at', 'updated_at')


@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    """
    Admin configuration for the Issue model.

    - Displays issue type, status, and related task information.
    - Allows searching by issue type and related fields.

    Attributes:
        list_display (tuple): Fields to display in the list view.
        search_fields (tuple): Fields to search by in the list view.
    """
    list_display = ('id', 'type', 'message')

@admin.register(TaskAuditLog)
class TaskAuditLogAdmin(admin.ModelAdmin):
    """
    Admin configuration for the TaskAuditLog model.

    - Displays audit log details including task, action, and timestamp.
    - Allows searching by action and related fields.

    Attributes:
        list_display (tuple): Fields to display in the list view.
        search_fields (tuple): Fields to search by in the list view.
    """
    list_display = ('id', 'task',  'old_status', 'new_status')
    search_fields = ('action', 'task__id')
    
@admin.register(TaskFile)
class TaskFilesAdmin(admin.ModelAdmin):
    """
    Admin configuration for the TaskFiles model.

    - Displays file information including task, file path, and creation details.
    - Allows searching by file path and related fields.

    Attributes:
        list_display (tuple): Fields to display in the list view.
        search_fields (tuple): Fields to search by in the list view.
    """
    list_display = ('id', 'task', 'path', 'created_at')
    search_fields = ('path', 'task__id')
    list_filter = ('created_at',)
    