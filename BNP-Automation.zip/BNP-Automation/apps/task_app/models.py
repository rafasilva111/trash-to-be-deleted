###
# General imports
##

import os
import shutil
import uuid
from asgiref.sync import sync_to_async



## Django
from django.db import models
from django.utils import timezone
from django.contrib.contenttypes.models import ContentType
from django.contrib.contenttypes.fields import GenericForeignKey
from django.utils.timesince import timesince
from django.core.files.storage import default_storage

## Celery
from celery.result import AsyncResult
from celery.app.control import Control

## Django Celery Beat
from django_celery_beat.models import CrontabSchedule, PeriodicTask, IntervalSchedule
from django.conf import settings

### App-specific imports

## Models
from apps.common.models import BaseModel
from apps.user_app.models import User
from apps.task_app.worker_signals import stop_thread_event

## Tasks and Functions
from apps.common.models import ProcessType
from apps.task_app.tasks import _launch_task, _launch_job
from config.celery import app
from apps.task_app.functions import task_file_upload_path    

# Third-party imports
from multiselectfield import MultiSelectField

### Models

import logging
from functools import lru_cache
from typing import List, Dict, Any

logger = logging.getLogger('django')

@lru_cache(maxsize=1)
def get_script_folder_choices():
    """
    Dynamically get folder names from the scripts directory to use as task type choices.
    Results are cached using LRU cache for better performance.
    """
    scripts_dir = os.path.join(os.path.dirname(__file__), 'scripts')
    choices = []
    
    try:
        if os.path.exists(scripts_dir):
            for item in os.listdir(scripts_dir):
                folder_path = os.path.join(scripts_dir, item)
                if os.path.isdir(folder_path) and not item.startswith('__'):
                    # Convert folder name to uppercase for value, keep original case for display
                    choices.append((item.upper(), item.title()))
        
        # Fallback if no folders found
        if not choices:
            choices = [('DEFAULT', 'Default')]
            logger.warning("No script folders found, using default fallback")
        
        logger.debug(f"Loaded {len(choices)} script folder choices")
        return choices
        
    except Exception as e:
        logger.error(f"Error loading script folder choices: {e}")
        return [('DEFAULT', 'Default')]

###
#
#   Exceptions
#
##

class StoppingConditionTriggered(Exception):
    """Raised to trigger a rollback when stopping condition is met."""
    pass

###
#
#   Base Models
#
##

def default_properties():
    return {
        "Threads":1,
    }

class LoadType(models.TextChoices):
        CREATED = 'Create', 'Create'
        CHANGED = 'Change', 'Change'
        UNCHANGED = 'Unchange', 'Unchange'
        DELETED = 'Delete', 'Delete'
        NONE = 'None', 'None'

class BaseTask(BaseModel):
    """
    Abstract base model for tasks with a specific task type.

    Attributes:
        type (str): The type of task, chosen from 'EMPTY', 'SMALL', 'MEDIUM', or 'LARGE'.
    """
    
    
    category = models.CharField(
        max_length=20,  # Increased to accommodate folder names
        choices=get_script_folder_choices(),
        default='DEFAULT',  # Default to 'DEFAULT' folder
        null=False
    )

    def get_default_max_steps(self):
        """Get default max_steps based on task type"""
        # Default step count for all script types
        return 10
    
    
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_tasks')
    

    class Meta:
        abstract = True

class BaseScript(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField(max_length=1000)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Script"
        verbose_name_plural = "Scripts"
    
    def get_custom_fields(self):
        """
        Returns all model fields excluding the common base fields.
        Useful for displaying script-specific properties in templates.
        """
        excluded_fields = {'id', 'description', 'created_at', 'basescript_ptr'}
        custom_fields = []
        
        for field in self._meta.fields:
            if field.name not in excluded_fields:
                field_value = getattr(self, field.name, None)
                
                # Get display value for choice fields
                display_value = field_value
                if hasattr(field, 'choices') and field.choices:
                    display_method = f"get_{field.name}_display"
                    if hasattr(self, display_method):
                        display_value = getattr(self, display_method)()
                
                custom_fields.append({
                    'name': field.name,
                    'verbose_name': field.verbose_name or field.name.replace('_', ' ').title(),
                    'value': field_value,
                    'display_value': display_value,
                    'field_type': field.get_internal_type(),
                    'has_choices': bool(getattr(field, 'choices', None)),
                })
        
        return custom_fields


###
#
#   Conditions Models
#
##

class Condition(models.Model):
    """
    Abstract base class for conditions used to control job/task execution.

    This is meant to be inherited by specific condition types like
    `TimeCondition` and `MaxRecordsCondition`.
    """
    
    class Meta:
        abstract = True 

class TimeCondition(Condition):
    """
    Condition based on a time schedule, using `CrontabSchedule` for scheduling.

    Attributes:
        crontab (models.ForeignKey): Foreign key to a `CrontabSchedule` instance.
        periodic_task (models.OneToOneField): One-to-one relationship with a `PeriodicTask` instance, can be null or blank.
    """

    periodic_task = models.OneToOneField(PeriodicTask, on_delete=models.CASCADE, null=True, blank=True)

    
    def __str__(self):
        return f"{self.id} - Time Condition: {self.periodic_task.crontab}"
    
    def delete(self,*args, **kwargs):
        
        # Delete the periodic task associated with this condition
        if self.periodic_task:
            self.periodic_task.delete()
        
        return super().delete(*args, **kwargs)

class ThresholdCondition(Condition):
    """
    Condition based on a threshold value.

    Attributes:
        threshold_value (int): The threshold value for the condition.
    """
    threshold_value = models.IntegerField()
    
    def __str__(self):
        return f"{self.id} - Threshold Condition: {self.threshold_value}"

class TaskStatusConditionAwaiter(BaseModel):
    
    dependent_task = models.ForeignKey('Task', on_delete=models.CASCADE)
    owner_task = models.ForeignKey('Task', related_name="dependent_tasks_awaiter", on_delete=models.CASCADE)
    triggered = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

###
#
#   Jobs Model
#
##

class JobTriggerHistory(BaseModel):
    """
    Represents the history of job triggers.

    Attributes:
        job (ForeignKey): The job associated with this trigger.
        triggered_at (DateTime): The time when the job was triggered.
        status (str): The status of the job at the time of triggering.
    """
    job = models.ForeignKey('Job', on_delete=models.CASCADE, related_name='trigger_history')
    
    class Type(models.TextChoices):
        """
        Enumeration for different types of ETL tasks.

        Attributes:
            EXTRACT (str): Represents an extraction task.
            TRANSFORM (str): Represents a transformation task.
            LOAD (str): Represents a loading task.
            FULL_PROCESS (str): Represents a full ETL process task.
        """
        STOPPING_CONDITION = 'STOPPING_CONDITION', 'Stopping Condition'
        STARTING_CONDITION = 'STARTING_CONDITION', 'Starting Condition'
        FORCE_START = 'FORCE_START', 'Force Start'
    
    type = models.CharField(
        max_length=18,
        choices=Type.choices,
        default=None,
        null=True
    )
    
    
    class Action(models.TextChoices):
        """
        Enumeration for different types of ETL tasks.

        Attributes:
            EXTRACT (str): Represents an extraction task.
            TRANSFORM (str): Represents a transformation task.
            LOAD (str): Represents a loading task.
            FULL_PROCESS (str): Represents a full ETL process task.
        """
        CREATE_TASK = 'CREATED_TASK', 'Created New Task'
        RESUME_TASK = 'RESUMED_TASK', 'Resumed Task'
        REST = 'REST', 'Rest'
    
    action = models.CharField(
        max_length=12,
        choices=Action.choices,
        default=None,
        null=True
    )
    
    triggered_at = models.DateTimeField(auto_now_add=True)

class Job(BaseTask):
    """
    Represents a job within the system, inheriting from `BaseTask`.

    Attributes:
        name (str): The name of the job, must be unique.
        company (ForeignKey): The associated company user.
        log_path (str): Path for log storage.
        enabled (bool): Whether the job is enabled.
        parent_task (ForeignKey): The task related to this job.
        parent_job (ForeignKey): Reference to a parent job.
        starting_condition (GenericForeignKey): Condition to start the job.
        stopping_condition (GenericForeignKey): Condition to stop the job.
        debug_mode (bool): Whether the job is in debug mode.
        last_run (DateTime): Last run time of the job.
    """
    name = models.CharField(max_length=255, verbose_name="Job Name", unique=True)
    log_path = models.CharField(max_length=255, null=True, blank=True)
    
    starting_condition_type = models.ForeignKey(ContentType, on_delete=models.CASCADE, related_name='start_condition_type', null=True,blank=True)
    starting_condition_id = models.PositiveIntegerField(null=True, blank=True)
    starting_condition = GenericForeignKey('starting_condition_type', 'starting_condition_id')
    
    stopping_condition_type = models.ForeignKey(ContentType, on_delete=models.CASCADE, related_name='stop_condition_type', null=True, blank=True)
    stopping_condition_id = models.PositiveIntegerField(null=True, blank=True)
    stopping_condition = GenericForeignKey('stopping_condition_type', 'stopping_condition_id')
    
    parent_task = models.ForeignKey('Task', on_delete=models.SET_NULL, blank=True, null=True, related_name='jobs')
    parent_job = models.ForeignKey('Job', on_delete=models.SET_NULL, blank=True, null=True, related_name='child_jobs')
    
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='jobs')
    enabled = models.BooleanField(default=True)
    
    
    @property
    def last_run(self):
        """
        Returns the last finished date of the tasks associated with this job.
        """
        last_task = self.tasks.order_by('-finished_at').first()
        return last_task.finished_at if last_task else None

    @property
    def started_run_humanized(self):
        """
        Returns the last finished date of the tasks associated with this job in a human-readable format.
        """
        

        return timesince(self.created_at) + " ago"

    @property
    def current_task(self):
        """
        Returns the current task associated with this job.
        """
        return self.tasks.last()

    class Meta:
        permissions = [
            ("can_view_job", "Can view Job's details"),
            ("can_view_jobs", "Can view Jobs list"),
            ("can_create_job", "Can create Job"),
            ("can_edit_job", "Can edit Job"),
            
            ("can_force_start_job", "Can force start Job"),
            ("can_enable_job", "Can pause Job"),
            ("can_disable_job", "Can resume Job"),
            ("can_delete_job", "Can delete Job"),
        ]
    
    def is_current_task_running(self):
        """
        Checks if the current task associated with this job is running.
        """

        if self.current_task:
            return self.current_task.status == Task.Status.RUNNING
        return False
    
    def force_start(self):
        _launch_job(self.id, force_start=True)
    
    def delete(self, *args, **kwargs):
        """
        Deletes the job and its associated periodic task and conditions if they exist.
        """
        # Delete the stopping condition if it exists
        if self.stopping_condition:
            self.stopping_condition.delete()
        
        # Similarly, delete the starting condition if needed
        if self.starting_condition:
            self.starting_condition.delete()
        
        # Call the superclass's delete method to handle the deletion of the Job instance
        super().delete(*args, **kwargs)

    def disable(self):
        """
        Pauses the periodic task and the task associated with this job.
        """

        self.enabled = False
        
        " Disable the periodic task if it exists ( aka CrontabSchedule ) "
        if self.starting_condition and isinstance(self.starting_condition, TimeCondition):
            self.starting_condition.periodic_task.enabled = False
            self.starting_condition.periodic_task.save()
            
        self.save()

    def enable(self):
        """
        Resumes the periodic task associated with this job.
        """
        
        self.enabled = True
        
        " Enable the periodic task if it exists ( aka CrontabSchedule ) "
        if self.starting_condition and isinstance(self.starting_condition, TimeCondition):
            self.starting_condition.periodic_task.enabled = True
            self.starting_condition.periodic_task.save()
            
        self.save()

    def create_job_trigger_history(self, type, action):
        
        """
        Creates a new job trigger history entry.
        """
        job_trigger_history = JobTriggerHistory.objects.create(
            job=self,
            type=type,
            action=action
        )
        return job_trigger_history
    
    def __str__(self):
        return f"Job: {self.id} - {self.name}"

###
#
#   Tasks Model
#
##

class Event(BaseModel):
    """
    Represents an issue (error or warning) associated with a Task.
    """
    class EventType(models.TextChoices):
        ERROR = 'ERROR', 'Error'
        WARNING = 'WARNING', 'Warning'
        INFO = 'INFO', 'Info'

    task = models.ManyToManyField('Task', related_name='events')
    type = models.CharField(max_length=7, choices=EventType.choices)
    message = models.TextField()
    stack_trace = models.TextField(null=True, blank=True)

    def __str__(self):
        return f"{self.type}: {self.message[:50]}"

    @property
    def is_warning(self):
        return self.type == self.EventType.WARNING

    @property
    def is_error(self):
        return self.type == self.EventType.ERROR
    
    @staticmethod
    def create_event( type, task, message, stack_trace):
        """
        Creates an issue (error or warning) for the task.
        """
        event, created = Event.objects.get_or_create(type=type, message=message, stack_trace=stack_trace)
        event.task.add(task)
        event.save()
        
    @staticmethod
    def create_error( task, message, stack_trace=None):
        """
        Shortcut to create an error issue for the task.
        """
        Event.create_event(Event.EventType.ERROR, task, message, stack_trace)

    @staticmethod
    def create_warning(task, message, stack_trace=None):
        """
        Shortcut to create a warning issue for the task.
        """
        Event.create_event(Event.EventType.WARNING, task, message, stack_trace)
        
    @staticmethod
    def create_info(task, message, stack_trace=None):
        """
        Shortcut to create a warning issue for the task.
        """
        Event.create_event(Event.EventType.INFO, task, message, stack_trace)

class TaskManager(models.Manager):
    """
    Custom manager for Task model that handles status tracking automatically.
    """
    
    def create_with_tracking(self, changed_by, **kwargs):
        """
        Creates a new task and tracks the initial status.
        """
        changed_by = kwargs.pop('changed_by', None)
        
        task = self.create(**kwargs)
        self._track_status_change(
            task=task,
            old_status=None,
            new_status=task.status,
            changed_by=changed_by,
        )
        return task
    
    def update_status(self, task, new_status, action_type, changed_by=None):
        """
        Updates a task's status and tracks the change.
        
        Args:
            task (Task): The task instance to update
            new_status (str): The new status value
            changed_by (User, optional): User who triggered the change
            
        Returns:
            Task: The updated task instance
        """
        old_status = task.status
        
        if old_status != new_status:
            task.status = new_status
            task.save()
            
            self._track_status_change(
                task=task,
                old_status=old_status,
                new_status=new_status,
                action_type=action_type,
                changed_by=changed_by,
            )
        
        return task
    
    def _track_status_change(self, task, old_status, new_status, action_type, changed_by=None):
        """
        Internal method to create a status history entry.
        
        Args:
            task (Task): The task instance
            old_status (str): The previous status
            new_status (str): The new status
            changed_by (User, optional): User who triggered the change
        """
        TaskAuditLog.objects.create(
            task=task,
            old_status=old_status,
            new_status=new_status,
            action_type=action_type,
            changed_by=changed_by,
            celery_task_id=task.celery_task_id,
            step=task.step,
        )

class Task(BaseTask):
    """
    Represents an individual task within a job, inheriting from `BaseTask`.

    Attributes:
        started_at (DateTime): The start time of the task.
        stopped_at (DateTime): The time when the task was paused/stopped.
        resumed_at (DateTime): The time when the task was resumed.
        finished_at (DateTime): The time when the task was finished.
        log_path (str): Path for log storage.
        celery_task_id (str): Celery task ID.
        job (ForeignKey): The job associated with this task.
        debug_mode (bool): Whether the task is in debug mode.
        status (str): Status of the task, e.g., STARTING, RUNNING, CANCELED.
    """
    celery_task_id = models.CharField(max_length=255, null=True, blank=True)
    
    started_at = models.DateTimeField(auto_now_add=True)
    finished_at = models.DateTimeField(null=True,blank=True)
    paused_at = models.DateTimeField(null=True,blank=True)
    resumed_at = models.DateTimeField(null=True,blank=True)
    duration = models.DurationField(null=True, blank=True)
    
    log_path = models.CharField(max_length=255, null=True, blank=True)
    sql_path = models.CharField(max_length=255, null=True, blank=True)
    
    master_job = models.ForeignKey(Job, on_delete=models.CASCADE, blank=True, null=True, related_name='subtasks')
    
    script = models.ForeignKey(
        'BaseScript', 
        on_delete=models.SET_NULL, 
        blank=True, 
        null=True,
        help_text="Associated script to execute with this task"
    )
    
    debug_mode = models.BooleanField(default=False)
    step = models.IntegerField(default=0)
    max_steps = models.IntegerField(default=0)
    
    
    # Statistics

    links = models.IntegerField(default=0, null=True, blank=True)
        
    items_processed = models.IntegerField(default=0, null=True, blank=True)
    items_expected = models.IntegerField(default=0, null=True, blank=True)
    
    
    class Status(models.TextChoices):
        WAITING = 'WAITING', 'Waiting'
        PAUSED = 'PAUSED', 'Paused'
        RUNNING = 'RUNNING', 'Running'
        CANCELED = 'CANCELED', 'Canceled'
        STOPPED = 'STOPPED', 'Stopped' # Stop is used when the task is stopped by as Stopping condition
        FAILED = 'FAILED', 'Failed'
        FINISHED = 'FINISHED', 'Finished'

    status = models.CharField(
        max_length=10,
        choices=Status.choices,
        default=Status.WAITING,
    )
    
    objects = TaskManager()
    
    @property
    def actual_script(self):
        """
        Returns the actual script subclass instance with all its specialized attributes.
        This handles Django's model inheritance automatically.
        """
        if not self.script:
            return None
        
        # Django creates reverse relationships for inherited models
        # Check if this script has any subclass instances
        for field in self.script._meta.get_fields(include_hidden=True):
            if (hasattr(field, 'related_model') and 
                field.related_model and 
                issubclass(field.related_model, BaseScript) and
                field.related_model != BaseScript):
                try:
                    # Get the lowercase model name (e.g., 'countingscript')
                    accessor_name = field.related_model._meta.model_name
                    return getattr(self.script, accessor_name)
                except AttributeError:
                    continue
        
        # If no subclass found, return the base script
        return self.script
    

    def save(self, *args, **kwargs):
        # Check if this is a new instance
        is_new = not self.pk
        
        # Set default max_steps for new instances
        if is_new and self.max_steps == 0:
            self.max_steps = self.get_default_max_steps()
        
        super().save(*args, **kwargs)
        
    
    
    @property
    def started_run_humanized(self):
        """
        Returns the last finished date of the tasks associated with this job in a human-readable format.
        """

        if self.started_at:
            return timesince(self.started_at) + " ago"
        
        return "Never"
    
    @property
    def runs(self):
        """
        Returns the count of audit log entries for this task.
        """
        return self.audit_logs.filter(action_type=self.Status.FINISHED).count()
    
    @property
    def errors(self):
        """
        Returns the count of errors associated with this task.
        """
        return self.events.filter(type=Event.EventType.ERROR).count()
    
    @property
    def warnings(self):
        """
        Returns the count of warnings associated with this task.
        """
        return self.events.filter(type=Event.EventType.WARNING).count()
    
    @property
    def infos(self):
        """
        Returns the count of warnings associated with this task.
        """
        return self.events.filter(type=Event.EventType.INFO).count()
    
    @property
    def _errors(self):
        """
        Returns the count of errors associated with this task.
        """
        return self.events.filter(type=Event.EventType.ERROR).all()
    
    @property
    def _warnings(self):
        """
        Returns the count of warnings associated with this task.
        """
        return self.events.filter(type=Event.EventType.WARNING).all()
    
    @property
    def _infos(self):
        """
        Returns the count of warnings associated with this task.
        """
        return self.events.filter(type=Event.EventType.INFO).all()
    
    @property
    def progress(self):
        """
        Returns the progress of the task as a percentage.
        """        
        if self.max_steps > 0:
            return int((self.step / self.max_steps) * 100)
        else:
            return 100
    
    
    
    class Meta:
        permissions = [
            ("can_view_task", "Can view Task's details"),
            ("can_view_tasks", "Can view Tasks list"),
            ("can_create_task", "Can create Task"),
            ("can_edit_task", "Can edit Task"),
            
            ("can_restart_task", "Can restart Task"),
            ("can_pause_task", "Can pause Task"),
            ("can_resume_task", "Can resume Task"),
            ("can_cancel_task", "Can cancel Task"),
            ("can_delete_task", "Can delete Task"),
        ]
    
    def __str__(self):
        """
        Override the default string representation of the task.
        """
        return f"Task: {self.id} - {self.category}"
    
    def get_log_path(self):
        
        """
        Returns the log path for the task.
        """
        
            
        if self.log_path:
            return f"{settings.BASE_DIR}/{self.log_path}"
        else:
            return None
    
    
    def launch(self, resume = False, changed_by=None):
        """
        Launches the task by setting its status and initiating a Celery task.
        """
        if not resume:
            self.started_at = timezone.now()
        
        self.save()
        
        if self.debug_mode:
            return _launch_task(self.id, resume)
            # We dont save here otherwise we rollback the task
        else:
            self.celery_task_id = _launch_task.delay(self.id, resume).id
            self.save()


            
    def restart(self, changed_by=None):
        """
        Restarts the task by resetting and relaunching it.
        """

        self.__kill_current_celery_task()
        
        # reset milestones
        self.links = 0
        self.items_processed = 0
        self.items_expected = 0
        self.step = 0 
        self.finished_at = None
        
        self.save()
        self.purge()
        
        # Update status with tracking
        Task.objects.update_status(
            task=self,
            new_status=Task.Status.WAITING,
            action_type=TaskAuditLog.TaskAuditLogAction.RESTARTED,
            changed_by=changed_by
        )
        
        self.launch()
                
    def cancel(self, changed_by=None):
        """
        Cancels the task by revoking the Celery task and updating the status.
        """
        # stop celery task
        self.__kill_current_celery_task()
        # Additionally, kill any orphaned Firefox instances for Selenium tasks
        from apps.task_app.tasks import kill_orphaned_firefox
        kill_orphaned_firefox.delay()
        
        self.finished_at = timezone.now()
        self.save()
        
        # Update status with tracking
        Task.objects.update_status(
            task=self,
            new_status=Task.Status.CANCELED,
            action_type=TaskAuditLog.TaskAuditLogAction.CANCELED,
            changed_by=changed_by
        )

    def pause(self, changed_by=None):
        if self.status == Task.Status.RUNNING:
            # stop celery task
            self.paused_at = timezone.now()
            self.save()
            self.__die_gracefully()
            
            # Update status with tracking
            Task.objects.update_status(
                task=self,
                new_status=Task.Status.PAUSED,
                action_type=TaskAuditLog.TaskAuditLogAction.PAUSED,
                changed_by=changed_by
            )
        else:
            logger.warning(f"Task {self.id} is not running. Cannot pause.")

    def resume(self, changed_by=None):
        if self.status == Task.Status.PAUSED:
            self.resumed_at = timezone.now()
            self.save()
            
            # Update status with tracking  
            Task.objects.update_status(
                task=self,
                new_status=Task.Status.WAITING,
                action_type=TaskAuditLog.TaskAuditLogAction.RESUMED,
                changed_by=changed_by
            )
            
            self.launch(resume=True)
        
    def finish(self, kill_celery_task=False, changed_by=None):
        self.finished_at = timezone.now()
        self.__calculate_duration()
        
        self.save()
        
        # Update status with tracking
        Task.objects.update_status(
            task=self,
            new_status=Task.Status.FINISHED,
            action_type=TaskAuditLog.TaskAuditLogAction.FINISHED,
            changed_by=changed_by
        )
        
        self.__die_gracefully()
    
    def fail(self, changed_by=None):
        self.finished_at = timezone.now()
        self.__calculate_duration()
        self.__die_gracefully()
        self.save()
        
        # Update status with tracking
        Task.objects.update_status(
            task=self,
            new_status=Task.Status.FAILED,
            action_type=TaskAuditLog.TaskAuditLogAction.FAILED,
            changed_by=changed_by
        )
    
    def get_type_process_display(self):
        return f"{self.type} - {self.process}"
    
    
    def increment_step(self):
        """
        Increments the step of the task.
        """
        self.step += 1
        self.save()
    
    def increment_errors(self, logger=None, message="", stack_trace=None):
        """
        Increments the error count of the task.
        """
        Event.create_error(
            task=self,
            message=message,
            stack_trace=stack_trace
        )
        if logger:
            logger.error(message)
            if stack_trace:
                logger.error(stack_trace)
            
    def increment_warnings(self, logger=None, message="", stack_trace=None):
        """
        Increments the warning count of the task.
        """
        Event.create_warning(
            task=self,
            message=message,
            stack_trace=stack_trace
        )
        if logger:
            logger.warning(message)
            if stack_trace:
                logger.warning(stack_trace)
    
    def increment_infos(self, logger=None, message="", stack_trace=None):
        """
        Increments the info count of the task.
        """
        Event.create_info(
            task=self,
            message=message
        )
        
        if logger:
            logger.info(message)
            if stack_trace:
                logger.info(stack_trace)
    
    def delete_issues(self):
        """
        Deletes issues associated with this task.
        """
        
        self._errors.delete()
        self._warnings.delete()
        self._infos.delete()
        
    def purge(self):
        """
        Deletes task logs associated with this task.
        """
        
        # Use safe deletion method for multi-process environments
        if not self.safe_delete_task_logs():
            logger.warning(f"Could not delete logs for task {self.id}, may need manual cleanup")
            
        self.delete_sql_file()
        self.delete_issues()
        
    def delete_task_logs(self):
        if self.log_path:
            try:
                # Debug logging for multi-process file access
                import pwd
                import grp
                import stat
                
                full_path = self.get_log_path()
                logger.debug(f"Attempting to delete log file: {full_path}")
                logger.debug(f"Current process user: {os.getenv('USER', 'unknown')}")
                logger.debug(f"Current process PID: {os.getpid()}")
                
                if os.path.exists(full_path):
                    file_stat = os.stat(full_path)
                    file_owner = pwd.getpwuid(file_stat.st_uid).pw_name
                    file_group = grp.getgrgid(file_stat.st_gid).gr_name
                    file_perms = stat.filemode(file_stat.st_mode)
                    
                    logger.debug(f"File exists - Owner: {file_owner}, Group: {file_group}, Permissions: {file_perms}")
                    logger.debug(f"File size: {file_stat.st_size} bytes")
                    
                    # Check if we can write to the parent directory
                    parent_dir = os.path.dirname(full_path)
                    if os.access(parent_dir, os.W_OK):
                        logger.debug(f"Parent directory {parent_dir} is writable")
                    else:
                        logger.warning(f"Parent directory {parent_dir} is NOT writable")
                    
                    # Try to remove the file
                    os.remove(full_path)
                    logger.info(f"Successfully deleted log file: {full_path}")
                else:
                    logger.warning(f"Log file does not exist: {full_path}")
                    
            except PermissionError as e:
                logger.error(f"Permission denied deleting log file: {self.log_path}")
                logger.error(f"This is likely because the file was created by Celery worker (different user)")
                logger.error(f"Error details: {str(e)}")
            except Exception as e:
                logger.error(f"Error deleting Log file: {self.log_path}, error: {str(e)}")
    
    def safe_delete_task_logs(self):
        """
        Safely delete task logs with fallback options for multi-process environments.
        Useful when Django server and Celery worker run as different users.
        """
        if not self.log_path:
            return True
            
        full_path = self.get_log_path()
        
        # Try direct deletion first
        try:
            if os.path.exists(full_path):
                os.remove(full_path)
                logger.info(f"Successfully deleted log file: {full_path}")
                return True
            else:
                logger.info(f"Log file already removed: {full_path}")
                return True
        except PermissionError:
            logger.warning(f"Permission denied for direct deletion of: {full_path}")
            
            # Fallback 1: Try to change permissions first
            try:
                os.chmod(full_path, 0o666)  # Make it writable for all
                os.remove(full_path)
                logger.info(f"Successfully deleted log file after chmod: {full_path}")
                return True
            except Exception as e:
                logger.warning(f"chmod fallback failed: {e}")
            
            # Fallback 2: Mark for cleanup by Celery worker
            # You could implement a cleanup task that runs with higher privileges
            logger.warning(f"Marking log file for background cleanup: {full_path}")
            # TODO: Implement background cleanup task
            return False
            
        except Exception as e:
            logger.error(f"Unexpected error deleting log file: {e}")
            return False
            
    def delete_sql_file(self):
        if self.sql_path:
            try:
                os.remove(self.sql_path)
            except Exception:
             logger.error(f"Error deleting SQL file: {self.sql_path}")
             
            # Remove SQLite auxiliary files if they exist
            for suffix in ["-shm", "-wal"]:
                aux_file = f"{self.sql_path}{suffix}"
                if os.path.exists(aux_file):
                    try:
                        os.remove(aux_file)
                    except Exception:
                        logger.error(f"Error deleting SQL auxiliary file: {aux_file}")
            
    
    def __die_gracefully(self):
        """
        Kills the task gracefully by revoking the Celery task and stopping threads.
        """
        self.__kill_current_celery_task()
    
    def __kill_current_celery_task(self):
        """
        Kills the task by revoking the Celery task
        """
        
        if self.celery_task_id and not self.debug_mode:
            result = AsyncResult(self.celery_task_id, app=app)
            result.revoke(terminate=True, signal='SIGTERM')
        else:
            logger.warning(f"Task {self.id} does not have a Celery task ID. Cannot kill Celery task.")
        
    
    def __calculate_duration(self):
        """
        Calculate the duration of the task.
        """
        
        if self.finished_at:
            self.duration = self.finished_at - self.started_at
        else:
            self.duration = None
            
    def kill_orphaned_firefox_instances(self):
        """
        Kills any orphaned Firefox instances for Selenium tasks.
        """
        from apps.task_app.tasks import kill_orphaned_firefox
        kill_orphaned_firefox.delay()
        
    def __kill_threads(self):
        """ 
        Kills any threads associated with this task.
        """
        stop_thread_event.set()
        
        print(f"stop_thread_event: {stop_thread_event.is_set()}")

##
#   Task Files Models
#

class TaskFile(BaseModel):
    """
    Model for storing files associated with tasks.
    
    Attributes:
        task (ForeignKey): The task this file is associated with.
        file (FileField): The uploaded file.
        original_name (str): Original filename when uploaded.
        description (str): Optional description of the file.
        file_type (str): Type/category of the file.
        file_size (int): Size of the file in bytes.
        uploaded_by (ForeignKey): User who uploaded the file.
        is_public (bool): Whether the file can be accessed publicly.
        download_count (int): Number of times the file has been downloaded.
    """
    
    class FileType(models.TextChoices):
        DOCUMENT = 'DOCUMENT', 'Document'
        IMAGE = 'IMAGE', 'Image'
        VIDEO = 'VIDEO', 'Video'
        AUDIO = 'AUDIO', 'Audio'
        SPREADSHEET = 'SPREADSHEET', 'Spreadsheet'
        PRESENTATION = 'PRESENTATION', 'Presentation'
        ARCHIVE = 'ARCHIVE', 'Archive'
        CODE = 'CODE', 'Code'
        OTHER = 'OTHER', 'Other'
    
    task = models.ForeignKey('Task', on_delete=models.CASCADE, related_name='task_files')
    path = models.FileField(upload_to=task_file_upload_path, max_length=500)
    original_name = models.CharField(max_length=255)
    file_type = models.CharField(max_length=12, choices=FileType.choices, default=FileType.OTHER)
    file_size = models.BigIntegerField(default=0)  # Size in bytes
    uploaded_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='uploaded_task_files')
    
    
    class Meta:
        ordering = ['-created_at']
        verbose_name = "Task File"
        verbose_name_plural = "Task Files"
        
        permissions = [
            ("can_view_task_files", "Can view Task's files"),
            ("can_upload_file_to_task", "Can upload file to Task"),
            ("can_download_file_from_task", "Can download file from Task"),
            ("can_delete_file_from_task", "Can delete file from Task"),
        ]
        
    @property
    def download_url(self):
        """Generate download URL for the file"""
        return f"/task/{self.task.id}/file/{self.id}/download/"


    @property
    def files_count(self):
        """
        Returns the count of files associated with this task.
        """
        return self.task_files.count()

    
    def __str__(self):
        return f"{self.original_name} - Task {self.task.id}"
    
    def save(self, *args, **kwargs):
        if self.path and not self.file_size:
            self.file_size = self.path.size
        if self.path and not self.original_name:
            self.original_name = os.path.basename(self.path.name)
        if not self.file_type:
            self.file_type = self.detect_file_type()
        super().save(*args, **kwargs)
    
    def detect_file_type(self):
        """Auto-detect file type based on extension"""
        if not self.original_name:
            return self.FileType.OTHER
            
        ext = os.path.splitext(self.original_name)[1].lower()
        
        document_exts = ['.pdf', '.doc', '.docx', '.txt', '.rtf', '.odt']
        image_exts = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.svg', '.webp']
        video_exts = ['.mp4', '.avi', '.mov', '.wmv', '.flv', '.webm']
        audio_exts = ['.mp3', '.wav', '.flac', '.aac', '.ogg']
        spreadsheet_exts = ['.xls', '.xlsx', '.csv', '.ods']
        presentation_exts = ['.ppt', '.pptx', '.odp']
        archive_exts = ['.zip', '.rar', '.7z', '.tar', '.gz']
        code_exts = ['.py', '.js', '.html', '.css', '.sql', '.json', '.xml']
        
        if ext in document_exts:
            return self.FileType.DOCUMENT
        elif ext in image_exts:
            return self.FileType.IMAGE
        elif ext in video_exts:
            return self.FileType.VIDEO
        elif ext in audio_exts:
            return self.FileType.AUDIO
        elif ext in spreadsheet_exts:
            return self.FileType.SPREADSHEET
        elif ext in presentation_exts:
            return self.FileType.PRESENTATION
        elif ext in archive_exts:
            return self.FileType.ARCHIVE
        elif ext in code_exts:
            return self.FileType.CODE
        else:
            return self.FileType.OTHER
    
    def get_file_icon(self):
        """Return appropriate FontAwesome icon for file type"""
        icons = {
            self.FileType.DOCUMENT: 'fa-file-pdf',
            self.FileType.IMAGE: 'fa-image',
            self.FileType.VIDEO: 'fa-video',
            self.FileType.AUDIO: 'fa-music',
            self.FileType.SPREADSHEET: 'fa-file-excel',
            self.FileType.PRESENTATION: 'fa-file-powerpoint',
            self.FileType.ARCHIVE: 'fa-file-archive',
            self.FileType.CODE: 'fa-code',
            self.FileType.OTHER: 'fa-file',
        }
        return icons.get(self.file_type, 'fa-file')
    
    def get_file_size_display(self):
        """Return human-readable file size"""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if self.file_size < 1024.0:
                return f"{self.file_size:.1f} {unit}"
            self.file_size /= 1024.0
        return f"{self.file_size:.1f} TB"
    
    def delete(self, *args, **kwargs):
        """Delete the file from storage when model is deleted"""
        if self.path:
            if default_storage.exists(self.path.name):
                default_storage.delete(self.path.name)
        super().delete(*args, **kwargs)

    

    def attach_file(self, path, uploaded_by):
        """
        Attach a file to this task.
        """
        return TaskFile.objects.create(
            task=self,
            path=path,
            uploaded_by=uploaded_by,
        )

##
#
#   Task Tracking Models

class TaskAuditLog(BaseModel):
    """
    Tracks the history of task status changes for auditing and monitoring purposes.
    
    Attributes:
        task (ForeignKey): The task whose status is being tracked.
        old_status (str): The previous status of the task.
        new_status (str): The new status of the task.
        changed_at (DateTime): When the status change occurred.
        changed_by (ForeignKey): User who triggered the change (optional).
        reason (str): Reason for the status change (optional).
        celery_task_id (str): Celery task ID at the time of change.
        step (int): Current step when status changed.
        progress (int): Current progress when status changed.
        duration_at_change (Duration): How long the task had been running when status changed.
    """
    
    task = models.ForeignKey('Task', on_delete=models.CASCADE, related_name='audit_logs')
    old_status = models.CharField(
        max_length=10,
        choices=None,  # Will be set to Task.Status.choices when Task is defined
        null=True,
        blank=True
    )
    new_status = models.CharField(
        max_length=10,
        choices=None,  # Will be set to Task.Status.choices when Task is defined
    )
    changed_at = models.DateTimeField(auto_now_add=True)
    changed_by = models.ForeignKey(
        User, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True,
        help_text="User who triggered the status change"
    )
    celery_task_id = models.CharField(
        max_length=255, 
        null=True, 
        blank=True,
        help_text="Celery task ID at the time of status change"
    )
    step = models.IntegerField(
        null=True, 
        blank=True,
        help_text="Step when status changed"
    )
    
    class TaskAuditLogAction(models.TextChoices):
        """
        Enumeration for different types of ETL tasks.

        Attributes:
            EXTRACT (str): Represents an extraction task.
            TRANSFORM (str): Represents a transformation task.
            LOAD (str): Represents a loading task.
            FULL_PROCESS (str): Represents a full ETL process task.
        """
        FINISHED = 'FINISHED', 'Finished'
        FAILED = 'FAILED', 'Failed'
        CANCELED = 'CANCELED', 'Canceled'
        PAUSED = 'PAUSED', 'Paused'
        RESTARTED = 'RESTARTED', 'Restarted'
        STARTED = 'STARTED', 'Started'
        RESUMED = 'RESUMED', 'Resumed'
    
    action_type = models.CharField(
        max_length=12,
        choices=TaskAuditLogAction.choices,
        default=None,
        null=True
    )
    
    class Meta:
        verbose_name = "Task Status History"
        verbose_name_plural = "Task Status Histories"
    
    def __str__(self):
        return f"Task {self.task.id}: {self.old_status} → {self.new_status} at {self.changed_at}"

##
#
#   Example of a Script Model
#
