"""
Performance monitoring utilities for the task app.
"""
import time
import logging
from functools import wraps
from typing import Callable, Any
from django.conf import settings

logger = logging.getLogger(__name__)

def monitor_performance(func_name: str = None):
    """
    Decorator to monitor function performance.
    
    Args:
        func_name: Optional custom name for the function
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            if not settings.DEBUG:
                # Only monitor performance in debug mode
                return func(*args, **kwargs)
                
            start_time = time.time()
            function_name = func_name or f"{func.__module__}.{func.__name__}"
            
            try:
                result = func(*args, **kwargs)
                execution_time = time.time() - start_time
                
                if execution_time > 0.1:  # Log slow operations (> 100ms)
                    logger.warning(f"Slow operation detected: {function_name} took {execution_time:.3f}s")
                else:
                    logger.debug(f"Performance: {function_name} completed in {execution_time:.3f}s")
                    
                return result
            except Exception as e:
                execution_time = time.time() - start_time
                logger.error(f"Function {function_name} failed after {execution_time:.3f}s: {e}")
                raise
                
        return wrapper
    return decorator

def log_cache_stats(cache_name: str, hit_count: int, total_count: int):
    """Log cache performance statistics."""
    if total_count > 0:
        hit_rate = (hit_count / total_count) * 100
        logger.info(f"Cache {cache_name}: {hit_rate:.1f}% hit rate ({hit_count}/{total_count})")
    else:
        logger.info(f"Cache {cache_name}: No requests yet")