import signal
import threading
import logging

logger = logging.getLogger(__name__)
stop_thread_event = threading.Event()