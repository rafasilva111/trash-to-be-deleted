from django.core.management.base import BaseCommand

from apps.task_app.models import Task
from apps.task_app.tasks import _reap_zombie_tasks

class Command(BaseCommand):
    
    def handle(self, *args, **kwargs):
        
        _reap_zombie_tasks()


