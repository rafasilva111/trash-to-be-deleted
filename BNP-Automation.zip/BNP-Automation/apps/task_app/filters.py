
###
#       General imports
##


##
#   Django
#

from django import forms
from django_filters import FilterSet, DateRangeFilter, DateFilter,ChoiceFilter,ModelChoiceFilter, CharFilter
from django.db.models import Q

###
#       App specific imports
##


##
#   Models
#

from apps.task_app.models import Task, TaskFile, Job, JobTriggerHistory, Event, get_script_folder_choices
from apps.user_app.models import User
from apps.task_app.models import ProcessType




class TaskFilter(FilterSet):
    search = CharFilter(
        method='filter_by_search',
        label='Search',
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Search for id...'
        })
    )
    started_at = DateRangeFilter(field_name='started_at', label='Started At',widget=forms.Select(attrs={'class': 'form-control rounded-0'}))
    finished_at = DateRangeFilter(field_name='finished_at', label='Finished At',widget=forms.Select(attrs={'class': 'form-control rounded-0'}))
    category = ChoiceFilter( choices=get_script_folder_choices(),label='Category', widget=forms.Select(attrs={'class': 'form-control rounded-0'}))
    status = ChoiceFilter( choices=Task.Status.choices,label='Status', widget=forms.Select(attrs={'class': 'form-control rounded-0'}))
    
    class Meta:
        model = Task
        fields = {}
        
    def filter_by_search(self, queryset, name, value):
        return queryset.filter(
            Q(id__icontains=value) 
        )


class JobFilter(FilterSet):
    
    search = CharFilter(
        method='filter_by_search',
        label='Search',
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Search for id...'
        })
    )
    category = ChoiceFilter( choices=get_script_folder_choices(),label='Type', widget=forms.Select(attrs={'class': 'form-control rounded-0'}))
    
    class Meta:
        model = Job
        fields = {}
        
    def filter_by_search(self, queryset, name, value):
        return queryset.filter(
            Q(id__icontains=value) |
            Q(created_by__name__icontains=value) 
        )
        
class JobTriggerHistoryFilter(FilterSet):
    type = ChoiceFilter( choices=JobTriggerHistory.Type.choices,label='Type', widget=forms.Select(attrs={'class': 'form-control rounded-0'}))
    created_at = DateRangeFilter(field_name='created_at', label='Created At',widget=forms.Select(attrs={'class': 'form-control rounded-0'}))

    class Meta:
        model = JobTriggerHistory
        fields = {}

class EventFilter(FilterSet):
    type = ChoiceFilter(choices=Event.EventType.choices, label='Event Type', widget=forms.Select(attrs={'class': 'form-control rounded-0'}))
    
    class Meta:
        model = Event
        fields = {}
        

class TaskFileUploadForm(forms.ModelForm):
    """Form for uploading files to tasks"""
    
    class Meta:
        model = TaskFile
        fields = ['path',]
        widgets = {
            'path': forms.FileInput(attrs={
                'class': 'form-control',
                'accept': '*/*',
                'multiple': False
            }),
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['path'].required = True
        
        # Add help text
        self.fields['path'].help_text = "Maximum file size: 50MB"
        
class TaskFileFilterForm(forms.Form):
    """Form for filtering task files"""
    
    file_type = forms.ChoiceField(
        choices=[('', 'All Types')] + list(TaskFile.FileType.choices),
        required=False,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    