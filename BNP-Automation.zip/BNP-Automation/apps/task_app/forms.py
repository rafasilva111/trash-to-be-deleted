"""Django forms for the task management system.

This module contains form definitions for tasks, jobs, scripts, and related components.
Provides form validation, dynamic field generation, and integration with the script discovery system.
"""

# =============================================================================
# IMPORTS
# =============================================================================

# Standard library imports
import json
import logging
from typing import Dict, List, Optional, Tuple, Type, Any

# Django imports
from django import forms
from django.db.models import Q
from django.core.exceptions import ValidationError
from django_celery_beat.models import CrontabSchedule, PeriodicTask
from django.db import transaction

# Local application imports
from apps.task_app.models import (
    Task, TaskFile, Job, ContentType, TimeCondition, ThresholdCondition, 
    BaseScript
)
from apps.user_app.models import User

# Import the scripts package to trigger recursive discovery of all script classes
import apps.task_app.scripts

# =============================================================================
# CONSTANTS & CHOICES
# =============================================================================

# Predefined cron field options for better UX and validation
MINUTES_CHOICES = [('*', '*')] + [(str(i), str(i)) for i in range(60)]
HOURS_CHOICES = [('*', '*')] + [(str(i), str(i)) for i in range(24)]
DAY_OF_WEEK_CHOICES = [('*', '*')] + [(str(i), str(i)) for i in range(7)]
DAY_OF_MONTH_CHOICES = [('*', '*')] + [(str(i), str(i)) for i in range(1, 32)]
MONTH_OF_YEAR_CHOICES = [('*', '*')] + [(str(i), str(i)) for i in range(1, 13)]

# Logger setup
logger = logging.getLogger(__name__)

# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

logger = logging.getLogger('django')

def get_script_subclasses(type_name: str = 'default', include_empty: bool = True) -> Tuple[List[Tuple[str, str]], Dict[str, Type]]:
    """
    Get all script classes from the scripts module discovery system.
    Uses cached data to avoid recreating instances every time.
    
    Args:
        type_name: Script folder type (default: 'default')
        include_empty: Whether to include the empty option (default: True)
        
    Returns:
        Tuple of (choices, script_classes_dict)
    """
    try:
        # Use the cached script choices and classes from the scripts module
        from apps.task_app.scripts import _script_folders, _script_choices_cache
        
        # Get choices from cache
        if type_name in _script_choices_cache:
            choices = _script_choices_cache[type_name].copy()  # Create a copy to avoid modifying cache
        else:
            choices = [('', 'Select a script type (optional)')]
            logger.warning(f"No cached choices found for script type: {type_name}")
        
        # Remove empty option if not wanted
        if not include_empty:
            choices = [choice for choice in choices if choice[0] != '']
        
        # Build script classes mapping  
        script_classes = {}
        if type_name in _script_folders:
            for script_class in _script_folders[type_name]:
                class_name = script_class.__name__
                script_classes[class_name] = script_class
        else:
            logger.warning(f"No script classes found for type: {type_name}")
        
        return choices, script_classes
        
    except ImportError as e:
        logger.error(f"Failed to import script discovery system: {e}")
        return [('', 'Select a script type (optional)')], {}
    except Exception as e:
        logger.error(f"Unexpected error in get_script_subclasses: {e}")
        return [('', 'Select a script type (optional)')], {}


###
#
#   Conditions
#
##

class TimeConditionForm(forms.ModelForm):
    
    minute = forms.ChoiceField(
        choices=MINUTES_CHOICES, 
        initial='*', 
        required=False,
        help_text='Cron minute field', 
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    hour = forms.ChoiceField(
        choices=HOURS_CHOICES, 
        initial='*', 
        required=False,
        help_text='Cron hour field', 
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    day_of_week = forms.ChoiceField(
        choices=DAY_OF_WEEK_CHOICES, 
        initial='*', 
        required=False,
        help_text='Cron day of week field', 
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    day_of_month = forms.ChoiceField(
        choices=DAY_OF_MONTH_CHOICES, 
        initial='*', 
        required=False,
        help_text='Cron day of month field', 
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    month_of_year = forms.ChoiceField(
        choices=MONTH_OF_YEAR_CHOICES, 
        initial='*', 
        required=False,
        help_text='Cron month of year field', 
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    
    
    class Meta:
        model = TimeCondition
        fields = ['minute', 'hour', 'day_of_week', 'day_of_month', 'month_of_year']
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Map instance crontab fields to form fields
        if self.instance and self.instance.periodic_task and self.instance.periodic_task.crontab:
            self.fields['minute'].initial = self.instance.periodic_task.crontab.minute
            self.fields['hour'].initial = self.instance.periodic_task.crontab.hour
            self.fields['day_of_week'].initial = self.instance.periodic_task.crontab.day_of_week
            self.fields['day_of_month'].initial = self.instance.periodic_task.crontab.day_of_month
            self.fields['month_of_year'].initial = self.instance.periodic_task.crontab.month_of_year


    def clean(self):
        cleaned_data = super().clean()
        minute = cleaned_data.get('minute')

        if minute == '*':
            self.add_error('minute', 'Minute cannot be "*"')

        return cleaned_data
    
        
    def save(self,job_id, starting_condition, name, *args, **kwargs):
        
        instance = super().save(commit=False)

        # Create or get the crontab schedule
        crontab, created = CrontabSchedule.objects.get_or_create(
            minute=self.cleaned_data['minute'],
            hour=self.cleaned_data['hour'],
            day_of_week=self.cleaned_data['day_of_week'],
            day_of_month=self.cleaned_data['day_of_month'],
            month_of_year=self.cleaned_data['month_of_year'],
        )
        
        if starting_condition:
            task= 'apps..tasks._launch_job'
        else:
            task= 'apps..tasks._stop_job'
            
        
        instance.periodic_task, created = PeriodicTask.objects.update_or_create(
            name=name,
            defaults={
            'task': task,
            'crontab': crontab,
            'args': json.dumps([str(job_id)]),
            'enabled': True,
            }
        )

        instance.save()
        
        return instance

class ThresholdConditionForm(forms.ModelForm):
    
    threshold_value = forms.IntegerField(
        required=True,
        initial=0,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'The Job will stop after this number of records are processed'
        })
    )
    class Meta:
        model = ThresholdCondition
        fields = ['threshold_value']
    
    def clean(self):
        cleaned_data = super().clean()
        threshold_value = cleaned_data.get('threshold_value')

        if threshold_value == 0:
            self.add_error('threshold_value', 'Maximum records cannot be 0')


        return cleaned_data

###
#
#   Jobs
#
##

class JobForm(forms.ModelForm):
    
    starting_condition_type = forms.ModelChoiceField(
        queryset=ContentType.objects.filter(
            Q(app_label='', model='timecondition') | Q(app_label='', model='taskstatuscondition')
        ),
        required=False,
        label='Starting Condition Type',
        help_text='Select the type of condition for starting.',
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    
    stopping_condition_type = forms.ModelChoiceField(
        queryset = ContentType.objects.filter(
            Q(app_label='', model='timecondition') | Q(app_label='', model='thresholdcondition')
        ),
        required=False,
        label='Stopping Condition Type',
        help_text='Select the type of condition for stopping.',
        widget=forms.Select(attrs={'class': 'form-control'})
    )

    
    class Meta:
        model = Job
        fields = [
            'name', 'category',
            'starting_condition_type', 'stopping_condition_type'
        ]
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter the name of the job'}),
            'category': forms.Select(attrs={'class': 'form-control'}),
        }
    
    def __init__(self, *args, **kwargs):
        instance = kwargs.get('instance', None)
        super().__init__(*args, **kwargs)

        if instance:
            # Indent the JSON properties for better readability
            self.initial['properties'] = json.dumps(instance.properties, indent=4)
        
    
    def save(self,starting_condition_form = None,stopping_condition_form = None, created_by = None, *args, **kwargs):
                
        try:
            # Create or update the Job instance
            with transaction.atomic():
                
                # Save the job instance
                job = super().save(commit=False)
                

                job.created_by = created_by
                
                job.save()
                
                if starting_condition_form:
                    job.starting_condition = starting_condition_form.save(
                        job_id = job.id,
                        name = f"Job Starting Condition: {job.name}",
                        starting_condition = True
                    )
                    
                if stopping_condition_form:
                    if stopping_condition_form.prefix == 'stopping_condition_time_form':
                        job.stopping_condition = stopping_condition_form.save(
                            job_id = job.id,
                            name = f"Job Stopping Condition: {job.name}",
                            starting_condition = False
                        )
                    elif stopping_condition_form.prefix == 'stopping_condition_threshold_form':
                        job.stopping_condition = stopping_condition_form.save()
                
                # Call the original save method
                job.save()
            
                return job
        except Exception as e:
            # Handle any exceptions (rollback will occur automatically)
            logger.error(f"An error occurred: {e}")
            raise

        # Create or update the Job instance
        job = super().save(commit=False)
        
        
        if starting_condition_form:
            job.starting_condition = starting_condition_form.save(job_id = job.id, name = f"Job Starting Condition: {job.name}")
            
        if stopping_condition_form:
            job.stopping_condition = stopping_condition_form.save(job_id = job.id, name = f"Job Stopping Condition: {job.name}")
        
        # Call the original save method
        job.save()
    
        return job
    
###
#
#   Tasks
#
##

class TaskForm(forms.ModelForm):    
    
    
    script = forms.ChoiceField(
        choices=[],  # Will be populated in __init__
        required=True,
        widget=forms.Select(attrs={'class': 'form-control'}),
        label='Script:',
        help_text='Select the script for this task.'
    )

    
    class Meta:
        model = Task
        fields = [
            'category', 'debug_mode',
        ]
        widgets = {
            'category': forms.Select(attrs={'class': 'form-control'}),
            'debug_mode': forms.CheckboxInput(attrs={'class': 'custom-control-input', 'id': 'debug_mode'}),
        }

    def __init__(self, *args, **kwargs):
        instance = kwargs.get('instance', None)
        super().__init__(*args, **kwargs)
        
        # Get script choices and populate the script field
        script_choices, script_classes = get_script_subclasses()
        self.fields['script'].choices = script_choices
        
        # Use cached script forms instead of creating dummy instances
        from apps.task_app.scripts import _script_forms_cache
        self.script_forms = _script_forms_cache.get('default', {})
        
        # Store current script form for validation
        self.current_script_form = None
        
        # Set help_text for category field
        self.fields['category'].help_text = 'Select the category for this task.'
        
        # Set help_text for category field
        self.fields['debug_mode'].help_text = 'Select debug mode, skip detached execution and run the task in the foreground for easier debugging and log access.'

        # Set the initial values for the parent task or job fields based on the instance type
        if instance and instance.script:
            self.initial['script'] = instance.script.__class__.__name__
    
    def get_script_form(self, script_class_name, data=None, instance=None):
        """Get the form class for a specific script type"""
        if script_class_name in self.script_forms:
            form_class = self.script_forms[script_class_name]
            return form_class(data=data, instance=instance)
        return None
    
    def get_available_script_forms(self):
        """Get all available script forms"""
        return self.script_forms

        
    def clean(self):
        cleaned_data = super().clean()
            
        # Prevent from saving a RUNNING task
        if hasattr(self.instance, 'status') and self.instance.status in [Task.Status.RUNNING]:
            self.add_error(None, f'You cannot save a task with status {self.instance.status}.')
        
        # Validate that script is selected (redundant but explicit)
        script = cleaned_data.get('script')
        if not script:
            self.add_error('script', 'Script selection is required.')
        else:
            # Validate the script form
            self.current_script_form = self.get_script_form(
                script, 
                data=self.data if self.is_bound else None
            )
            
            if self.current_script_form:
                if not self.current_script_form.is_valid():
                    # Add script form errors to the main form
                    for field, errors in self.current_script_form.errors.items():
                        for error in errors:
                            self.add_error(None, f"Script {field}: {error}")
            
        return cleaned_data
    
    def save(self, created_by = None, *args, **kwargs):
        
        try:
            # Create or update the Task instance
            with transaction.atomic():
                
                # Save the task instance
                instance = super().save(commit=False)
                
                if created_by:
                    instance.created_by = created_by
                
                # Handle script creation from integrated script form
                if hasattr(self, 'current_script_form') and self.current_script_form and self.current_script_form.is_valid():
                    # Create and save the script instance with user's configuration
                    script_instance = self.current_script_form.save(commit=False)
                    script_instance.save()
                    
                    # Associate script with task
                    instance.script = script_instance
                
                instance.save()
                if instance.status == Task.Status.WAITING:
                    instance.launch()
                
            
                return instance
        except Exception as e:
            logger.error(f"An error occurred: {e}")
            raise

##
#   Script
#

class BaseScriptForm(forms.ModelForm):
    """Base form class for all script forms"""
    
    class Meta:
        model = BaseScript
        fields = ['name', 'description']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter script name'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 5,
                'placeholder': 'Enter description',
            }),
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['name'].help_text = "Enter a name for this script."
        self.fields['description'].help_text = "Provide a description for the script."
  
##
#   Task Files 
#

class TaskFileUploadForm(forms.ModelForm):
    """Form for uploading files to tasks"""
    
    class Meta:
        model = TaskFile
        fields = ['path',]
        widgets = {
            'path': forms.FileInput(attrs={
                'class': 'form-control',
                'accept': '*/*',
                'multiple': False
            })
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['path'].required = True
        
        # Add help text
        self.fields['path'].help_text = "Maximum file size: 50MB"
        
class TaskFileFilterForm(forms.Form):
    """Form for filtering task files"""
    
    file_type = forms.ChoiceField(
        choices=[('', 'All Types')] + list(TaskFile.FileType.choices),
        required=False,
        widget=forms.Select(attrs={'class': 'form-control'})
    )