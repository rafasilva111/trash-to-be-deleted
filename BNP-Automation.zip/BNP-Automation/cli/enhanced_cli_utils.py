"""Enhanced CLI utilities with comprehensive logging and optimization.

This module provides optimized CLI utilities with enhanced error handling,
performance monitoring, and comprehensive logging for development operations.
"""

import logging
import subprocess
import shlex
import os
import sys
import time
from typing import Dict, Any, Optional, List, Union, Tuple
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from datetime import datetime

from apps.common.performance_monitor import PerformanceMonitor, performance_decorator
from apps.common.utils import safe_operation

logger = logging.getLogger(__name__)


@dataclass
class CommandResult:
    """Enhanced command result with comprehensive information."""
    command: str
    returncode: int
    stdout: str
    stderr: str
    execution_time: float
    success: bool
    timestamp: str
    working_directory: str
    environment_vars: Dict[str, str] = None

    def __post_init__(self):
        if self.environment_vars is None:
            self.environment_vars = {}

    @property
    def output(self) -> str:
        """Get combined output (stdout + stderr)."""
        return f"{self.stdout}\n{self.stderr}".strip()

    def to_dict(self) -> Dict[str, Any]:
        """Convert result to dictionary."""
        return {
            'command': self.command,
            'returncode': self.returncode,
            'stdout': self.stdout,
            'stderr': self.stderr,
            'execution_time': self.execution_time,
            'success': self.success,
            'timestamp': self.timestamp,
            'working_directory': self.working_directory,
            'environment_vars': self.environment_vars,
        }


class EnhancedCommandExecutor:
    """Enhanced command executor with comprehensive logging and error handling."""
    
    def __init__(self, timeout: int = 300, max_workers: int = 4):
        self.timeout = timeout
        self.max_workers = max_workers
        self.command_history = []
        self.max_history_size = 100
    
    @performance_decorator("command_execution", include_args=False)
    def execute_command(self, 
                       command: Union[str, List[str]], 
                       working_dir: Optional[str] = None,
                       env_vars: Optional[Dict[str, str]] = None,
                       capture_output: bool = True,
                       shell: bool = False,
                       timeout: Optional[int] = None) -> CommandResult:
        """
        Execute a command with comprehensive logging and error handling.
        
        Args:
            command: Command to execute (string or list)
            working_dir: Working directory for command execution
            env_vars: Additional environment variables
            capture_output: Whether to capture stdout/stderr
            shell: Whether to use shell for execution
            timeout: Command timeout (uses instance timeout if None)
            
        Returns:
            CommandResult with execution details
        """
        start_time = time.time()
        cmd_timeout = timeout or self.timeout
        
        # Prepare command
        if isinstance(command, str):
            if not shell:
                command = shlex.split(command)
            cmd_str = command
        else:
            cmd_str = ' '.join(shlex.quote(arg) for arg in command)
        
        # Prepare environment
        env = os.environ.copy()
        if env_vars:
            env.update(env_vars)
        
        # Set working directory
        if working_dir:
            working_dir = str(Path(working_dir).resolve())
        else:
            working_dir = os.getcwd()
        
        logger.info(f"Executing command: {cmd_str}")
        logger.debug(f"Working directory: {working_dir}")
        
        try:
            with PerformanceMonitor(f"subprocess_execution"):
                # Execute command
                process = subprocess.Popen(
                    command,
                    stdout=subprocess.PIPE if capture_output else None,
                    stderr=subprocess.PIPE if capture_output else None,
                    cwd=working_dir,
                    env=env,
                    shell=shell,
                    text=True,
                    bufsize=1,
                    universal_newlines=True
                )
                
                try:
                    stdout, stderr = process.communicate(timeout=cmd_timeout)
                except subprocess.TimeoutExpired:
                    process.kill()
                    stdout, stderr = process.communicate()
                    logger.error(f"Command timed out after {cmd_timeout} seconds: {cmd_str}")
                    
                    return CommandResult(
                        command=cmd_str,
                        returncode=-1,
                        stdout=stdout or "",
                        stderr=f"Command timed out after {cmd_timeout} seconds\n{stderr or ''}",
                        execution_time=time.time() - start_time,
                        success=False,
                        timestamp=datetime.now().isoformat(),
                        working_directory=working_dir,
                        environment_vars=env_vars or {}
                    )
        
        except Exception as e:
            execution_time = time.time() - start_time
            error_msg = f"Command execution failed: {str(e)}"
            logger.error(f"{error_msg} - Command: {cmd_str}")
            
            return CommandResult(
                command=cmd_str,
                returncode=-1,
                stdout="",
                stderr=error_msg,
                execution_time=execution_time,
                success=False,
                timestamp=datetime.now().isoformat(),
                working_directory=working_dir,
                environment_vars=env_vars or {}
            )
        
        # Create result
        execution_time = time.time() - start_time
        success = process.returncode == 0
        
        result = CommandResult(
            command=cmd_str,
            returncode=process.returncode,
            stdout=stdout or "",
            stderr=stderr or "",
            execution_time=execution_time,
            success=success,
            timestamp=datetime.now().isoformat(),
            working_directory=working_dir,
            environment_vars=env_vars or {}
        )
        
        # Log result
        if success:
            logger.info(f"Command completed successfully in {execution_time:.2f}s: {cmd_str}")
            if stdout and len(stdout.strip()) > 0:
                logger.debug(f"Command output: {stdout[:500]}{'...' if len(stdout) > 500 else ''}")
        else:
            logger.error(f"Command failed (exit code {process.returncode}) in {execution_time:.2f}s: {cmd_str}")
            if stderr:
                logger.error(f"Command stderr: {stderr}")
        
        # Store in history
        self._add_to_history(result)
        
        return result
    
    def execute_parallel_commands(self, 
                                commands: List[Dict[str, Any]], 
                                max_workers: Optional[int] = None) -> List[CommandResult]:
        """
        Execute multiple commands in parallel.
        
        Args:
            commands: List of command dictionaries with execution parameters
            max_workers: Maximum number of parallel workers
            
        Returns:
            List of CommandResult objects
        """
        max_workers = max_workers or self.max_workers
        results = []
        
        logger.info(f"Executing {len(commands)} commands in parallel with {max_workers} workers")
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submit all commands
            future_to_cmd = {}
            for cmd_config in commands:
                cmd = cmd_config.get('command')
                if not cmd:
                    continue
                
                future = executor.submit(
                    self.execute_command,
                    command=cmd,
                    working_dir=cmd_config.get('working_dir'),
                    env_vars=cmd_config.get('env_vars'),
                    capture_output=cmd_config.get('capture_output', True),
                    shell=cmd_config.get('shell', False),
                    timeout=cmd_config.get('timeout')
                )
                future_to_cmd[future] = cmd_config
            
            # Collect results as they complete
            for future in as_completed(future_to_cmd):
                try:
                    result = future.result()
                    results.append(result)
                except Exception as e:
                    cmd_config = future_to_cmd[future]
                    logger.error(f"Parallel command execution failed: {e}")
                    
                    # Create error result
                    error_result = CommandResult(
                        command=str(cmd_config.get('command', 'unknown')),
                        returncode=-1,
                        stdout="",
                        stderr=f"Parallel execution error: {str(e)}",
                        execution_time=0.0,
                        success=False,
                        timestamp=datetime.now().isoformat(),
                        working_directory=cmd_config.get('working_dir', os.getcwd())
                    )
                    results.append(error_result)
        
        successful = sum(1 for r in results if r.success)
        logger.info(f"Parallel execution completed: {successful}/{len(results)} commands successful")
        
        return results
    
    @safe_operation(default_return=[])\n    def get_command_history(self, limit: int = 50) -> List[Dict[str, Any]]:\n        \"\"\"        Get command execution history.\n        \n        Args:\n            limit: Maximum number of history entries to return\n            \n        Returns:\n            List of command history entries\n        \"\"\"        \n        return [result.to_dict() for result in self.command_history[-limit:]]\n    \n    def _add_to_history(self, result: CommandResult):\n        \"\"\"Add command result to history with size management.\"\"\"        \n        self.command_history.append(result)\n        \n        # Maintain history size\n        if len(self.command_history) > self.max_history_size:\n            self.command_history = self.command_history[-self.max_history_size:]\n\n\nclass GitOperationsManager:\n    \"\"\"Enhanced Git operations with comprehensive logging and error handling.\"\"\"    \n    \n    def __init__(self, repo_path: Optional[str] = None):\n        self.repo_path = Path(repo_path) if repo_path else Path.cwd()\n        self.executor = EnhancedCommandExecutor()\n    \n    @performance_decorator(\"git_status_check\")\n    def get_repository_status(self) -> Dict[str, Any]:\n        \"\"\"        Get comprehensive Git repository status.\n        \n        Returns:\n            Dictionary with repository status information\n        \"\"\"        \n        status_info = {\n            'is_git_repo': False,\n            'current_branch': None,\n            'has_uncommitted_changes': False,\n            'staged_files': [],\n            'modified_files': [],\n            'untracked_files': [],\n            'ahead_behind': {'ahead': 0, 'behind': 0},\n            'last_commit': {},\n            'remote_url': None,\n        }\n        \n        # Check if it's a Git repository\n        result = self.executor.execute_command(\n            \"git rev-parse --is-inside-work-tree\",\n            working_dir=str(self.repo_path)\n        )\n        \n        if not result.success:\n            logger.warning(f\"Not a Git repository: {self.repo_path}\")\n            return status_info\n        \n        status_info['is_git_repo'] = True\n        \n        # Get current branch\n        result = self.executor.execute_command(\n            \"git branch --show-current\",\n            working_dir=str(self.repo_path)\n        )\n        if result.success:\n            status_info['current_branch'] = result.stdout.strip()\n        \n        # Get status\n        result = self.executor.execute_command(\n            \"git status --porcelain\",\n            working_dir=str(self.repo_path)\n        )\n        if result.success:\n            for line in result.stdout.strip().split('\\n'):\n                if not line:\n                    continue\n                    \n                status_code = line[:2]\n                filename = line[3:]\n                \n                if status_code[0] in ['A', 'M', 'D', 'R', 'C']:\n                    status_info['staged_files'].append(filename)\n                if status_code[1] in ['M', 'D']:\n                    status_info['modified_files'].append(filename)\n                if status_code == '??':\n                    status_info['untracked_files'].append(filename)\n        \n        status_info['has_uncommitted_changes'] = bool(\n            status_info['staged_files'] or \n            status_info['modified_files'] or \n            status_info['untracked_files']\n        )\n        \n        # Get remote information\n        result = self.executor.execute_command(\n            \"git remote get-url origin\",\n            working_dir=str(self.repo_path)\n        )\n        if result.success:\n            status_info['remote_url'] = result.stdout.strip()\n        \n        # Get last commit information\n        result = self.executor.execute_command(\n            'git log -1 --pretty=format:\"{\\\"hash\\\":\\\"%H\\\",\\\"author\\\":\\\"%an\\\",\\\"date\\\":\\\"%ai\\\",\\\"message\\\":\\\"%s\\\"}\"',\n            working_dir=str(self.repo_path)\n        )\n        if result.success and result.stdout.strip():\n            try:\n                import json\n                status_info['last_commit'] = json.loads(result.stdout.strip())\n            except json.JSONDecodeError:\n                logger.warning(\"Failed to parse last commit information\")\n        \n        logger.debug(f\"Repository status retrieved for {self.repo_path}\")\n        return status_info\n    \n    @safe_operation(default_return=False)\n    def create_commit(self, message: str, files: Optional[List[str]] = None, \n                     add_all: bool = False) -> bool:\n        \"\"\"        Create a Git commit with specified files or all changes.\n        \n        Args:\n            message: Commit message\n            files: Specific files to commit (optional)\n            add_all: Whether to add all changes before committing\n            \n        Returns:\n            bool: True if commit was successful\n        \"\"\"        \n        if not message.strip():\n            logger.error(\"Commit message cannot be empty\")\n            return False\n        \n        commands_to_execute = []\n        \n        # Add files to staging area\n        if add_all:\n            commands_to_execute.append({\n                'command': 'git add .',\n                'working_dir': str(self.repo_path)\n            })\n        elif files:\n            for file_path in files:\n                commands_to_execute.append({\n                    'command': f'git add {shlex.quote(file_path)}',\n                    'working_dir': str(self.repo_path)\n                })\n        \n        # Create commit\n        commands_to_execute.append({\n            'command': f'git commit -m {shlex.quote(message)}',\n            'working_dir': str(self.repo_path)\n        })\n        \n        # Execute commands\n        results = self.executor.execute_parallel_commands(commands_to_execute, max_workers=1)\n        \n        # Check if commit was successful (last command)\n        commit_result = results[-1] if results else None\n        success = commit_result and commit_result.success\n        \n        if success:\n            logger.info(f\"Successfully created commit: {message}\")\n        else:\n            error_msg = commit_result.stderr if commit_result else \"Unknown error\"\n            logger.error(f\"Failed to create commit: {error_msg}\")\n        \n        return success\n    \n    def get_commit_history(self, limit: int = 10, branch: Optional[str] = None) -> List[Dict[str, Any]]:\n        \"\"\"        Get Git commit history with enhanced information.\n        \n        Args:\n            limit: Number of commits to retrieve\n            branch: Specific branch to get history from\n            \n        Returns:\n            List of commit information dictionaries\n        \"\"\"        \n        branch_arg = f\" {shlex.quote(branch)}\" if branch else \"\"\n        \n        result = self.executor.execute_command(\n            f'git log{branch_arg} -n {limit} --pretty=format:\"{{\\\"hash\\\":\\\"%H\\\",\\\"short_hash\\\":\\\"%h\\\",\\\"author\\\":\\\"%an\\\",\\\"author_email\\\":\\\"%ae\\\",\\\"date\\\":\\\"%ai\\\",\\\"relative_date\\\":\\\"%ar\\\",\\\"message\\\":\\\"%s\\\",\\\"body\\\":\\\"%b\\\"}}\"',\n            working_dir=str(self.repo_path)\n        )\n        \n        commits = []\n        if result.success:\n            for line in result.stdout.strip().split('\\n'):\n                if line.strip():\n                    try:\n                        import json\n                        commit = json.loads(line)\n                        commits.append(commit)\n                    except json.JSONDecodeError as e:\n                        logger.warning(f\"Failed to parse commit line: {e}\")\n        \n        logger.debug(f\"Retrieved {len(commits)} commits from history\")\n        return commits\n\n\nclass FileOperationsManager:\n    \"\"\"Enhanced file operations with comprehensive logging and validation.\"\"\"    \n    \n    def __init__(self):\n        self.executor = EnhancedCommandExecutor()\n    \n    @safe_operation(default_return={})\n    def analyze_directory(self, directory_path: str, \n                         include_hidden: bool = False) -> Dict[str, Any]:\n        \"\"\"        Analyze directory structure and contents.\n        \n        Args:\n            directory_path: Path to directory to analyze\n            include_hidden: Whether to include hidden files/directories\n            \n        Returns:\n            Dictionary with directory analysis\n        \"\"\"        \n        dir_path = Path(directory_path)\n        \n        if not dir_path.exists():\n            logger.error(f\"Directory does not exist: {directory_path}\")\n            return {'error': 'Directory does not exist'}\n        \n        if not dir_path.is_dir():\n            logger.error(f\"Path is not a directory: {directory_path}\")\n            return {'error': 'Path is not a directory'}\n        \n        analysis = {\n            'path': str(dir_path.resolve()),\n            'total_files': 0,\n            'total_directories': 0,\n            'total_size_bytes': 0,\n            'file_types': {},\n            'largest_files': [],\n            'directory_tree': {},\n            'permissions': {},\n        }\n        \n        try:\n            with PerformanceMonitor(\"directory_analysis\"):\n                # Get directory permissions\n                analysis['permissions'] = {\n                    'readable': os.access(dir_path, os.R_OK),\n                    'writable': os.access(dir_path, os.W_OK),\n                    'executable': os.access(dir_path, os.X_OK),\n                }\n                \n                # Analyze contents\n                for item in dir_path.rglob('*'):\n                    if not include_hidden and any(part.startswith('.') for part in item.parts):\n                        continue\n                    \n                    if item.is_file():\n                        analysis['total_files'] += 1\n                        \n                        # File size\n                        try:\n                            size = item.stat().st_size\n                            analysis['total_size_bytes'] += size\n                            \n                            # Track largest files\n                            if len(analysis['largest_files']) < 10:\n                                analysis['largest_files'].append({\n                                    'path': str(item.relative_to(dir_path)),\n                                    'size_bytes': size\n                                })\n                            else:\n                                # Replace smallest if current is larger\n                                smallest_idx = min(range(len(analysis['largest_files'])), \n                                                  key=lambda i: analysis['largest_files'][i]['size_bytes'])\n                                if size > analysis['largest_files'][smallest_idx]['size_bytes']:\n                                    analysis['largest_files'][smallest_idx] = {\n                                        'path': str(item.relative_to(dir_path)),\n                                        'size_bytes': size\n                                    }\n                            \n                            # File type analysis\n                            suffix = item.suffix.lower()\n                            analysis['file_types'][suffix] = analysis['file_types'].get(suffix, 0) + 1\n                            \n                        except (OSError, PermissionError) as e:\n                            logger.warning(f\"Could not analyze file {item}: {e}\")\n                    \n                    elif item.is_dir():\n                        analysis['total_directories'] += 1\n                \n                # Sort largest files by size\n                analysis['largest_files'].sort(key=lambda x: x['size_bytes'], reverse=True)\n                \n                logger.info(f\"Directory analysis completed: {directory_path}\")\n                \n        except Exception as e:\n            logger.error(f\"Directory analysis failed: {e}\")\n            analysis['error'] = str(e)\n        \n        return analysis\n\n\n# Global instances for easy access\ncommand_executor = EnhancedCommandExecutor()\ngit_operations = GitOperationsManager()\nfile_operations = FileOperationsManager()