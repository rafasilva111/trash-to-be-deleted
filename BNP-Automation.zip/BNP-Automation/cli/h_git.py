# -*- encoding: utf-8 -*-
"""
Copyright (c) App-Generator.dev | AppSeed.us
"""

import os
from .common   import *
from .h_files  import *
from .h_util   import *
    
"""Git operations helper module.

Provides convenient wrapper functions for common Git operations with proper
error handling and logging.
"""

import logging
from typing import  Optional
from .h_shell import exec_process

# Setup logging
logger = logging.getLogger(__name__)

def git_changes() -> Optional[bool]:
    """
    Check if there are uncommitted changes in the Git repository.
    
    Returns:
        bool: True if there are changes, False if clean
        None: If an error occurred
        
    Example:
        >>> has_changes = git_changes()
        >>> if has_changes:
        ...     print("Repository has uncommitted changes")
    """
    try:
        logger.debug("Checking for Git changes...")
        result = exec_process('git diff --name-only')
        
        if result == 0:
            logger.info("Git repository has uncommitted changes")
            return True
        else:
            logger.info("Git repository is clean")
            return False
            
    except Exception as e:
        logger.error(f"Error checking Git changes: {e}")
        return None

def git_log() -> Optional[bool]:
    """
    Display Git log in a formatted view.
    
    Returns:
        bool: True if successful, False otherwise
        None: If an error occurred
    """
    try:
        logger.debug("Displaying Git log...")
        result = exec_process('git log --oneline --graph --all')
        
        if result == 0:
            logger.info("Successfully displayed Git log")
            return True
        else:
            logger.warning("Git log command failed")
            return False
            
    except Exception as e:
        logger.error(f"Error displaying Git log: {e}")
        return None
    
def git_commit() -> Optional[bool]:
    """
    Commit all changes with user-provided comment and push to remote.
    
    Interactive function that prompts user for commit message,
    commits all changes, and pushes to remote repository.
    
    Returns:
        bool: True if commit and push successful, False otherwise
        None: If an error occurred
    """
    try:
        logger.info("Starting Git commit process...")
        
        # Get commit message from user
        git_comment = input(' Add Comment: ').strip()
        
        # Use default message if empty
        if not git_comment:
            git_comment = 'Auto-commit: updates'
            logger.info(f"Using default commit message: {git_comment}")
        else:
            logger.info(f"Using commit message: {git_comment}")

        # Commit changes
        commit_result = exec_process(f'git commit -am "{git_comment}"')
        if commit_result != 0:
            logger.error("Git commit failed")
            return False
            
        logger.info("Git commit successful, pushing to remote...")
        
        # Push to remote
        push_result = exec_process('git push')
        if push_result != 0:
            logger.error("Git push failed")
            return False
            
        logger.info("Git commit and push completed successfully")
        return True
        
    except KeyboardInterrupt:
        logger.info("Git commit cancelled by user")
        return False
    except Exception as e:
        logger.error(f"Error in Git commit process: {e}")
        return None
        
def git_tag():
    try:
        
        git_tag     = input(' TAG Name: ')
        git_comment = input(' TAG Comment: ')

        if 0 == exec_process( f"git tag -a {git_tag} -m '{git_comment}'" ):
            return True 
        
        return False

    except Exception as e:
        print(' > ERR: ' + str(e) )
        return -1

def git_list_tags():
    try:
        
        if 0 == exec_process('git describe --tags --abbrev=0'):
            return True 
        
        return False

    except Exception as e:
        print(' > ERR: ' + str(e) )
        return -1

def git_revert():
    try:
        
        confirm = input('DANGER: This command reverts the latest commit. Confirm y/N: ')
        if 'y' != confirm.strip().lower():
            # nothing is done
            return False    

        if 0 == exec_process('git reset --hard HEAD~1'):
            if 0 == exec_process('git push origin HEAD --force'):
                return True 
        
        return False

    except Exception as e:
        print(' > ERR: ' + str(e) )
        return -1
