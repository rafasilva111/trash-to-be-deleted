/**
 * JavaScript functions for fetching scripts by type from the Django backend
 */

console.log('get-scripts.js loaded');

/**
 * Get CSRF token from cookies or DOM
 * @returns {string} CSRF token
 */
function getCSRFToken() {
    // Try to get from cookie first
    const cookies = document.cookie.split(';');
    for (let cookie of cookies) {
        const [name, value] = cookie.trim().split('=');
        if (name === 'csrftoken') {
            return decodeURIComponent(value);
        }
    }
    
    // Try to get from hidden input in form
    const csrfInput = document.querySelector('[name=csrfmiddlewaretoken]');
    if (csrfInput) {
        return csrfInput.value;
    }
    
    // Try to get from meta tag
    const csrfMeta = document.querySelector('meta[name=csrf-token]');
    if (csrfMeta) {
        return csrfMeta.getAttribute('content');
    }
    
    return null;
}

/**
 * Fetch scripts by task type using fetch API
 * @param {string} taskType - The type of task to get scripts for
 * @returns {Promise<Array>} - Promise that resolves to an array of script objects
 */
async function getScriptsByType(taskType) {
    try {
        const url = `/scripts/${taskType}/`;
        console.log(`Fetching scripts from: ${url}`);
        
        const headers = {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        };
        
        // Add CSRF token if available (though not needed for GET requests)
        const csrfToken = getCSRFToken();
        if (csrfToken) {
            headers['X-CSRFToken'] = csrfToken;
        }
        
        const response = await fetch(url, {
            method: 'GET',
            headers: headers,
            credentials: 'same-origin' // Include cookies for authentication
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        console.log(`Received ${data.scripts?.length || 0} scripts for type: ${taskType}`, data);
        return data.scripts || [];
    } catch (error) {
        console.error('Error fetching scripts:', error);
        throw error;
    }
}

/**
 * Fetch scripts by task type using jQuery (if available)
 * @param {string} taskType - The type of task to get scripts for
 * @returns {Promise<Array>} - jQuery promise that resolves to an array of script objects
 */
function getScriptsByTypeJQuery(taskType) {
    return $.ajax({
        url: `/scripts/${taskType}/`,
        method: 'GET',
        dataType: 'json',
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    }).then(function(data) {
        return data.scripts || [];
    }).fail(function(xhr, status, error) {
        console.error('Error fetching scripts:', error);
        throw error;
    });
}

/**
 * Update a select element with the fetched scripts
 * @param {string} taskType - The type of task to get scripts for
 * @param {string|Element} selectElement - The select element ID or DOM element to update
 */
async function updateScriptDropdown(taskType, selectElement) {
    try {
        const scripts = await getScriptsByType(taskType);
        const select = typeof selectElement === 'string' ? 
            document.getElementById(selectElement) : selectElement;
        
        if (!select) {
            console.error('Select element not found');
            return;
        }

        // Clear existing options except the first placeholder option
        while (select.children.length > 1) {
            select.removeChild(select.lastChild);
        }

        // Add new script options
        scripts.forEach(script => {
            const option = document.createElement('option');
            option.value = script.value;
            option.textContent = script.label;
            select.appendChild(option);
        });

    } catch (error) {
        console.error('Error updating script dropdown:', error);
    }
}

/**
 * jQuery version to update a select element with the fetched scripts
 * @param {string} taskType - The type of task to get scripts for
 * @param {string} selectElementId - The select element ID to update
 */
function updateScriptDropdownJQuery(taskType, selectElementId) {
    console.log(`Updating script dropdown for task type: ${taskType}`);
    getScriptsByTypeJQuery(taskType)
        .then(function(scripts) {
            const $select = $(`#${selectElementId}`);
            
            // Clear existing options except the first placeholder option
            $select.find('option:not(:first)').remove();
            
            // Add new script options
            scripts.forEach(function(script) {
                $select.append(`<option value="${script.value}">${script.label}</option>`);
            });
        })
        .catch(function(error) {
            console.error('Error updating script dropdown:', error);
        });
}

// Example usage:
/*
// Using async/await
async function handleTaskTypeChange() {
    const taskType = document.getElementById('task-type-select').value;
    if (taskType) {
        await updateScriptDropdown(taskType, 'script-type-select');
    }
}

// Using jQuery
$(document).on('change', '#task-type-select', function() {
    const taskType = $(this).val();
    if (taskType) {
        updateScriptDropdownJQuery(taskType, 'script-type-select');
    }
});

// Direct API call
getScriptsByType('extract').then(scripts => {
    console.log('Available scripts for extract tasks:', scripts);
});
*/