// Add this script to your create.html template
// This will dynamically update the script_type dropdown when the type field changes

document.addEventListener('DOMContentLoaded', function() {
    console.log('Task create form script loaded');
    
    const taskCategorySelect = document.getElementById('id_category');
    const scriptSelect = document.getElementById('id_script');
    const scriptFormContainer = document.getElementById('script-form-container');
    
    console.log('TaskCategorySelect found:', !!taskCategorySelect, taskCategorySelect?.id);
    console.log('ScriptSelect found:', !!scriptSelect, scriptSelect?.id);
    console.log('Script form container found:', !!scriptFormContainer);
    
    if (taskCategorySelect && scriptSelect) {
        console.log('Both elements found, setting up event listeners');
        
        // Handle task category change
        taskCategorySelect.addEventListener('change', async function() {
            console.log('Task category changed to:', this.value);
            const taskCategory = this.value;
            
            if (taskCategory) {
                try {
                    // Show loading state
                    scriptSelect.disabled = true;
                    scriptSelect.innerHTML = '<option value="">Loading scripts...</option>';
                    
                    // Clear script form
                    if (scriptFormContainer) {
                        scriptFormContainer.innerHTML = '';
                    }
                    
                    // Fetch scripts for the selected task category
                    const scripts = await getScriptsByType(taskCategory);
                    
                    // Clear dropdown
                    scriptSelect.innerHTML = '<option value="">Select a script type (optional)</option>';
                    
                    // Populate with new scripts
                    scripts.forEach(script => {
                        const option = document.createElement('option');
                        option.value = script.value;
                        option.textContent = script.label;
                        scriptSelect.appendChild(option);
                    });
                    
                    // Re-enable dropdown
                    scriptSelect.disabled = false;
                    
                    // Show success message in console for debugging
                    console.log(`Loaded ${scripts.length} scripts for task category: ${taskCategory}`);
                    
                } catch (error) {
                    console.error('Failed to load scripts:', error);
                    scriptSelect.innerHTML = '<option value="">Error loading scripts</option>';
                    scriptSelect.disabled = false;
                }
            } else {
                // Reset script dropdown if no task category selected
                scriptSelect.innerHTML = '<option value="">Select a script type (optional)</option>';
                scriptSelect.disabled = false;
                if (scriptFormContainer) {
                    scriptFormContainer.innerHTML = '';
                }
            }
        });
        
        // Handle script selection change
        scriptSelect.addEventListener('change', async function() {
            console.log('Script changed to:', this.value);
            const scriptClassName = this.value;
            
            if (scriptFormContainer) {
                if (scriptClassName) {
                    try {
                        // Show loading state
                        scriptFormContainer.innerHTML = '<div class="alert alert-info">Loading script configuration...</div>';
                        
                        // Fetch script form
                        const response = await fetch(`/script-form/${scriptClassName}/`, {
                            method: 'GET',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-Requested-With': 'XMLHttpRequest'
                            },
                            credentials: 'same-origin'
                        });
                        
                        if (!response.ok) {
                            throw new Error(`HTTP error! status: ${response.status}`);
                        }
                        
                        const data = await response.json();
                        
                        // Display script form
                        scriptFormContainer.innerHTML = `
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Script Configuration</h4>
                                </div>
                                <div class="card-body">
                                    ${data.form_html}
                                </div>
                            </div>
                        `;
                        
                        console.log('Script form loaded successfully');
                        
                    } catch (error) {
                        console.error('Failed to load script form:', error);
                        scriptFormContainer.innerHTML = '<div class="alert alert-danger">Error loading script configuration</div>';
                    }
                } else {
                    // Clear form when no script selected - but only if it doesn't have server-rendered validation errors
                    const hasValidationErrors = scriptFormContainer.querySelector('.invalid-feedback, .alert-danger');
                    if (!hasValidationErrors) {
                        scriptFormContainer.innerHTML = '';
                    }
                }
            }
        });
        
        // Trigger the change event on page load if there's already a selected value
        if (taskCategorySelect.value) {
            // Check if script form container already has server-rendered content with validation errors
            const hasServerRenderedForm = scriptFormContainer.innerHTML.trim() !== '' && 
                                         scriptFormContainer.querySelector('.card, .script-form-fields');
            
            if (hasServerRenderedForm) {
                console.log('Server-rendered script form detected, skipping JavaScript initialization');
                // Don't trigger any events - let the server-rendered form remain intact
                return;
            }
            
            // Store the currently selected script value before triggering category change
            const currentScriptValue = scriptSelect.value;
            
            taskCategorySelect.dispatchEvent(new Event('change'));
            
            // Wait a moment for the async operation to complete, then restore script selection
            setTimeout(() => {
                if (currentScriptValue && scriptSelect.querySelector(`option[value="${currentScriptValue}"]`)) {
                    scriptSelect.value = currentScriptValue;
                    // Trigger the script change event to load the form
                    scriptSelect.dispatchEvent(new Event('change'));
                }
            }, 100);
        }
    } else {
        console.warn('Task category or script select elements not found');
    }
});