/**
 * TaskDetailManager - Handles real-time updates for task detail page
 * Features:
 * - WebSocket connection for live log streaming
 * - Progress bar updates
 * - Auto-scroll functionality
 * - Task status updates
 */
class TaskDetailManager {
    constructor(options = {}) {
        // Configuration
        this.taskId = options.taskId;
        this.websocketUrl = options.websocketUrl;
        this.currentPage = options.currentPage || 1;
        
        // DOM elements
        this.elements = {
            logContainer: document.getElementById('log-container'),
            logBody: document.getElementById('log-body'),
            progressBar: document.getElementById('task-progress-bar'),
            progressText: document.getElementById('task-progress-text'),
            statusBadge: document.getElementById('task-status-badge'),
            autoScroll: document.getElementById('auto-scroll'),
            placeholder: document.getElementById('log-placeholder')
        };
        
        // WebSocket connection
        this.socket = null;
        
        // Log styling configuration
        this.logLevels = {
            INFO: { color: '#4A90E2', name: 'INFO' },
            WARNING: { color: '#F5A623', name: 'WARNING' },
            ERROR: { color: '#E57373', name: 'ERROR' }
        };
        
        // Initialize the manager
        this.init();
    }
    
    /**
     * Initialize the task detail manager
     */
    init() {
        this.setupWebSocket();
        this.setupEventListeners();
        this.handleInitialPageLoad();
        
        console.log('TaskDetailManager initialized for task:', this.taskId);
    }
    
    /**
     * Set up WebSocket connection for real-time updates
     */
    setupWebSocket() {
        if (!this.taskId || !this.websocketUrl) {
            console.warn('TaskDetailManager: Missing taskId or websocketUrl');
            return;
        }
        
        const wsUrl = `${this.websocketUrl}/ws/task/${this.taskId}/`;
        
        try {
            this.socket = new WebSocket(wsUrl);
            
            this.socket.onopen = () => {
                console.log('WebSocket connected successfully');
            };
            
            this.socket.onmessage = (event) => {
                this.handleWebSocketMessage(event);
            };
            
            this.socket.onclose = (event) => {
                console.log('WebSocket connection closed:', event.code, event.reason);
            };
            
            this.socket.onerror = (error) => {
                console.error('WebSocket error:', error);
            };
            
        } catch (error) {
            console.error('Failed to initialize WebSocket:', error);
        }
    }
    
    /**
     * Handle incoming WebSocket messages
     * @param {MessageEvent} event - WebSocket message event
     */
    handleWebSocketMessage(event) {
        try {
            const data = JSON.parse(event.data);
            console.log('WebSocket message received:', data);
            
            // Only process log updates on page 1 to avoid conflicts
            if (this.currentPage === 1) {
                switch (data.type) {
                    case 'log_line':
                        this.handleLogLine(data.line);
                        break;
                    case 'task_progress':
                        this.handleProgressUpdate(data);
                        break;
                    case 'task_status':
                        this.handleStatusUpdate(data);
                        break;
                    default:
                        console.log('Unknown message type:', data.type);
                }
            }
        } catch (error) {
            console.error('Error parsing WebSocket message:', error);
        }
    }
    
    /**
     * Handle new log line from WebSocket
     * @param {string} line - Log line text
     */
    handleLogLine(line) {
        if (!this.elements.logContainer) {
            console.warn('Log container not found');
            return;
        }
        
        // Remove placeholder on first log
        this.removePlaceholder();
        
        // Create and style log entry
        const logEntry = this.createLogEntry(line);
        
        // Append to container
        this.elements.logContainer.appendChild(logEntry);
        
        // Auto-scroll if enabled
        this.handleAutoScroll();
    }
    
    /**
     * Create a styled log entry element
     * @param {string} line - Raw log line
     * @returns {HTMLElement} Styled log entry element
     */
    createLogEntry(line) {
        const logEntry = document.createElement('div');
        logEntry.className = 'log-line';
        
        // Pattern to match: [timestamp] [LEVEL] message
        const logPattern = /(\[[^\]]*\])\s*(\[(INFO|WARNING|ERROR)\])\s*(.*)/;
        const match = line.match(logPattern);
        
        if (match) {
            const [, timestamp, levelBracket, level, message] = match;
            
            // Create structured log entry
            const timestampSpan = this.createLogElement('log-timestamp', timestamp);
            const levelSpan = this.createLogElement('log-level', ` ${levelBracket}`, level);
            const messageSpan = this.createLogElement('log-message', ` ${message}`);
            
            logEntry.appendChild(timestampSpan);
            logEntry.appendChild(levelSpan);
            logEntry.appendChild(messageSpan);
        } else {
            // Fallback for unmatched patterns
            logEntry.textContent = line;
            logEntry.className = 'log-line log-plain';
        }
        
        return logEntry;
    }
    
    /**
     * Create a styled log element
     * @param {string} className - CSS class name
     * @param {string} text - Element text content
     * @param {string} level - Log level for styling (optional)
     * @returns {HTMLElement} Styled element
     */
    createLogElement(className, text, level = null) {
        const element = document.createElement('span');
        element.className = className;
        element.textContent = text;
        
        // Apply level-specific styling
        if (level && this.logLevels[level]) {
            element.style.fontWeight = 'bold';
            element.style.color = this.logLevels[level].color;
        }
        
        return element;
    }
    
    /**
     * Handle progress update from WebSocket
     * @param {Object} data - Progress data
     */
    handleProgressUpdate(data) {
        const progress = Math.min(Math.max(data.progress || 0, 0), 100);
        console.log('Progress update received:', progress + '%');
        
        // Update progress bar
        if (this.elements.progressBar) {
            this.elements.progressBar.style.width = `${progress}%`;
            this.elements.progressBar.setAttribute('aria-valuenow', progress);
        }
        
        // Update progress text
        if (this.elements.progressText) {
            this.elements.progressText.textContent = `${progress}% Complete`;
        }
        
        // Update status badge if task is complete
        if (progress === 100 && data.status && this.elements.statusBadge) {
            this.elements.statusBadge.textContent = data.status;
        }
    }
    
    /**
     * Handle task status update from WebSocket
     * @param {Object} data - Status data
     */
    handleStatusUpdate(data) {
        console.log('Task status update received:', data);
        // Refresh the page to reflect all changes
        window.location.reload();
    }
    
    /**
     * Remove the log placeholder when first log arrives
     */
    removePlaceholder() {
        if (this.elements.placeholder) {
            this.elements.placeholder.remove();
            this.elements.placeholder = null;
        }
    }
    
    /**
     * Handle auto-scroll functionality
     */
    handleAutoScroll() {
        if (this.elements.autoScroll && 
            this.elements.autoScroll.checked && 
            this.elements.logBody) {
            this.elements.logBody.scrollTop = this.elements.logBody.scrollHeight;
        }
    }
    
    /**
     * Set up event listeners for UI interactions
     */
    setupEventListeners() {
        // Auto-scroll toggle
        if (this.elements.autoScroll) {
            this.elements.autoScroll.addEventListener('change', () => {
                if (this.elements.autoScroll.checked) {
                    this.handleAutoScroll();
                }
            });
        }
    }
    
    /**
     * Handle initial page load actions
     */
    handleInitialPageLoad() {
        // Scroll to filter form if GET params present
        const hasGetParams = window.location.search.length > 0;
        const filterForm = document.getElementById('issues-filter-form');
        
        if (hasGetParams && filterForm) {
            filterForm.scrollIntoView({ 
                behavior: 'smooth', 
                block: 'center' 
            });
        }
    }
    
    /**
     * Clean up resources
     */
    destroy() {
        if (this.socket) {
            this.socket.close();
            this.socket = null;
        }
        
        console.log('TaskDetailManager destroyed');
    }
}

// Export for use in modules or make globally available
if (typeof module !== 'undefined' && module.exports) {
    module.exports = TaskDetailManager;
} else {
    window.TaskDetailManager = TaskDetailManager;
}